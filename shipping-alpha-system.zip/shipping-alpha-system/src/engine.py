"""
Unified Signal Engine.

Orchestrates the calculation of all signals for the shipping universe.
"""

from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple

from loguru import logger
from sqlalchemy.orm import Session

from .signals import (
    LEPCalculator,
    FEPCalculator,
    EIEPCalculator,
    REDCalculator,
    INFCalculator,
    DISCalculator,
    TradeSignalGenerator,
    SignalResult,
)
from .risk import (
    MacroFilter,
    MacroSnapshot,
    CorrelationRegimeDetector,
    RiskRegime,
    RiskManager,
)
from .models import (
    Company,
    Vessel,
    Charter,
    Signal,
    FreightIndex,
    FFAPrice,
    EquityPrice,
    MacroIndicator,
)
from config import SignalParameters, SHIPPING_UNIVERSE, VESSEL_INDEX_MAPPING


class SignalEngine:
    """
    Main signal calculation engine.
    
    Calculates all signals for the shipping universe and generates trade recommendations.
    """
    
    def __init__(
        self,
        session: Session,
        lep_calculator: LEPCalculator = None,
        fep_calculator: FEPCalculator = None,
        eiep_calculator: EIEPCalculator = None,
        red_calculator: REDCalculator = None,
        inf_calculator: INFCalculator = None,
        dis_calculator: DISCalculator = None,
        risk_manager: RiskManager = None,
    ):
        self.session = session
        
        # Initialize calculators with defaults
        self.lep_calc = lep_calculator or LEPCalculator()
        self.fep_calc = fep_calculator or FEPCalculator(self.lep_calc)
        self.eiep_calc = eiep_calculator or EIEPCalculator()
        self.red_calc = red_calculator or REDCalculator()
        self.inf_calc = inf_calculator or INFCalculator()
        self.dis_calc = dis_calculator or DISCalculator()
        
        self.risk_manager = risk_manager or RiskManager()
        self.signal_generator = TradeSignalGenerator(self.inf_calc, self.dis_calc)
    
    def calculate_company_signals(
        self,
        company: Company,
        calculation_date: Optional[date] = None,
    ) -> SignalResult:
        """
        Calculate all signals for a single company.
        
        Args:
            company: Company to analyze
            calculation_date: Date for calculations
            
        Returns:
            SignalResult with all calculated signals
        """
        calc_date = calculation_date or date.today()
        
        # Load company data
        vessels = self.session.query(Vessel).filter(
            Vessel.company_id == company.id,
            Vessel.active == True
        ).all()
        
        charters = self.session.query(Charter).filter(
            Charter.company_id == company.id,
            Charter.start_date <= calc_date,
            (Charter.end_date == None) | (Charter.end_date >= calc_date)
        ).all()
        
        # Get current spot rates
        spot_rates = self._get_spot_rates(calc_date)
        
        # Get forward curves
        forward_curves = self._get_forward_curves(calc_date)
        
        # Get stock price
        stock_price = self._get_stock_price(company.ticker, calc_date)
        
        # Convert to dicts for calculators
        company_data = {
            "id": company.id,
            "shares_outstanding": company.shares_outstanding or 100_000_000,
            "annual_ga_expense": company.annual_ga_expense or 10_000_000,
            "annual_interest_expense": company.annual_interest_expense or 20_000_000,
            "depreciation": company.depreciation or 30_000_000,
        }
        
        vessels_data = [
            {
                "id": v.id,
                "vessel_type": v.vessel_type.value if hasattr(v.vessel_type, 'value') else v.vessel_type,
                "daily_opex": v.daily_opex or 6000,
                "active": v.active,
            }
            for v in vessels
        ]
        
        charters_data = [
            {
                "vessel_id": c.vessel_id,
                "charter_type": c.charter_type.value if hasattr(c.charter_type, 'value') else c.charter_type,
                "daily_rate": c.daily_rate,
                "start_date": c.start_date,
                "end_date": c.end_date,
            }
            for c in charters
        ]
        
        # Calculate LEP
        lep_earnings = self.lep_calc.calculate(
            company_data=company_data,
            vessels=vessels_data,
            charters=charters_data,
            spot_rates=spot_rates,
            calculation_date=calc_date,
        )
        lep_eps = self.lep_calc.to_eps(lep_earnings, company_data["shares_outstanding"])
        lep_ebitda = lep_earnings.annualized_ebitda()
        
        # Calculate FEP
        fep_earnings = self.fep_calc.calculate(
            company_data=company_data,
            vessels=vessels_data,
            charters=charters_data,
            forward_curves=forward_curves,
            calculation_date=calc_date,
        )
        fep_eps = self.fep_calc.to_eps(fep_earnings, company_data["shares_outstanding"])
        fep_ebitda = fep_earnings.annualized_ebitda()
        
        # Calculate EIEP
        pe_multiple = company.typical_pe_multiple or SignalParameters.DEFAULT_PE_MULTIPLE
        eiep_result = self.eiep_calc.calculate(
            stock_price=stock_price,
            shares_outstanding=company_data["shares_outstanding"],
            pe_multiple=pe_multiple,
        )
        eiep_eps = eiep_result["implied_eps"]
        
        # Calculate RED
        red_result = self.red_calc.calculate(
            vessels=vessels_data,
            charters=charters_data,
            calculation_date=calc_date,
        )
        
        # Get trailing EPS (from last reported)
        trailing_eps = self._get_trailing_eps(company.id)
        
        # Get consensus EPS
        consensus_eps = self._get_consensus_eps(company.ticker)
        
        # Calculate INF
        inf_score, inf_components = self.inf_calc.calculate(
            projected_eps=fep_eps,
            trailing_eps=trailing_eps,
            consensus_eps=consensus_eps,
            fleet_repricing_pct=red_result.get("fleet_spot_pct", 0.5) * 100,
            quarters_until_inflection=1.0,
        )
        
        # Calculate DIS
        dis_score, dis_details = self.dis_calc.calculate(
            lep=lep_eps,
            fep=fep_eps,
            eiep=eiep_eps,
        )
        
        # Get macro regime
        macro_regime = self._get_macro_regime(calc_date)
        
        # Generate trade signal
        trade_signal = self.signal_generator.generate_signal(
            inf_score=inf_score,
            dis_score=dis_score,
            macro_regime=macro_regime,
            earnings_days_away=self._days_to_earnings(company.ticker),
        )
        
        # Calculate correlations
        freight_corr, market_corr = self._calculate_correlations(company.ticker, calc_date)
        
        # Create result
        result = SignalResult(
            company_id=company.id,
            ticker=company.ticker,
            calculation_date=calc_date,
            lep=round(lep_eps, 2),
            lep_ebitda=round(lep_ebitda / 1_000_000, 2),  # In millions
            fep=round(fep_eps, 2),
            fep_ebitda=round(fep_ebitda / 1_000_000, 2),
            eiep=round(eiep_eps, 2),
            inf_score=round(inf_score, 1),
            dis_score=round(dis_score, 3),
            inf_components=inf_components.to_dict(),
            red_months=red_result.get("red_months", 0),
            fleet_spot_pct=red_result.get("fleet_spot_pct", 0),
            freight_correlation=round(freight_corr, 2),
            market_correlation=round(market_corr, 2),
            buy_signal=trade_signal["buy_signal"],
            sell_signal=trade_signal["sell_signal"],
            signal_strength=round(trade_signal["signal_strength"], 2),
            trade_type=trade_signal.get("trade_type"),
        )
        
        # Save to database
        self._save_signal(result)
        
        return result
    
    def calculate_universe_signals(
        self,
        calculation_date: Optional[date] = None,
        segment: Optional[str] = None,
    ) -> List[SignalResult]:
        """
        Calculate signals for entire universe or segment.
        
        Args:
            calculation_date: Date for calculations
            segment: Optional segment filter
            
        Returns:
            List of SignalResults
        """
        results = []
        
        # Get companies
        query = self.session.query(Company).filter(Company.active == True)
        if segment:
            query = query.filter(Company.segment == segment)
        
        companies = query.all()
        
        logger.info(f"Calculating signals for {len(companies)} companies")
        
        for company in companies:
            try:
                result = self.calculate_company_signals(company, calculation_date)
                results.append(result)
                logger.debug(f"{company.ticker}: LEP={result.lep:.2f}, FEP={result.fep:.2f}, DIS={result.dis_score:.1%}")
            except Exception as e:
                logger.error(f"Error calculating signals for {company.ticker}: {e}")
        
        return results
    
    def get_trade_candidates(
        self,
        results: List[SignalResult],
        min_signal_strength: float = 0.4,
    ) -> List[Dict[str, Any]]:
        """
        Filter results to get actionable trade candidates.
        
        Args:
            results: Signal results
            min_signal_strength: Minimum signal strength
            
        Returns:
            List of trade candidates
        """
        candidates = []
        
        for result in results:
            if result.buy_signal and result.signal_strength >= min_signal_strength:
                candidates.append({
                    "ticker": result.ticker,
                    "trade_type": result.trade_type,
                    "signal_strength": result.signal_strength,
                    "dis_score": result.dis_score,
                    "inf_score": result.inf_score,
                    "lep": result.lep,
                    "fep": result.fep,
                    "eiep": result.eiep,
                    "action": "BUY",
                })
        
        # Sort by signal strength
        candidates.sort(key=lambda x: x["signal_strength"], reverse=True)
        
        return candidates
    
    def _get_spot_rates(self, calc_date: date) -> Dict[str, float]:
        """Get current spot TCE rates by vessel type."""
        spot_rates = {}
        
        # Default rates if no data
        defaults = {
            "capesize": 20000,
            "panamax": 15000,
            "supramax": 12000,
            "handysize": 10000,
            "vlcc": 40000,
            "suezmax": 35000,
            "aframax": 30000,
            "mr_tanker": 20000,
        }
        
        for vessel_type, index_code in VESSEL_INDEX_MAPPING.items():
            # Try to get from database
            index_record = self.session.query(FreightIndex).filter(
                FreightIndex.index_code == index_code,
                FreightIndex.date <= calc_date
            ).order_by(FreightIndex.date.desc()).first()
            
            if index_record and index_record.tce_equivalent:
                spot_rates[vessel_type] = index_record.tce_equivalent
            else:
                spot_rates[vessel_type] = defaults.get(vessel_type, 15000)
        
        return spot_rates
    
    def _get_forward_curves(self, calc_date: date) -> Dict[str, List[Dict]]:
        """Get FFA forward curves by vessel type."""
        forward_curves = {}
        
        route_to_vessel = {
            "C5TC": "capesize",
            "P5TC": "panamax",
            "S10TC": "supramax",
            "TD3C": "vlcc",
        }
        
        for route_code, vessel_type in route_to_vessel.items():
            ffa_records = self.session.query(FFAPrice).filter(
                FFAPrice.route_code == route_code,
                FFAPrice.date == calc_date
            ).order_by(FFAPrice.contract_month).limit(12).all()
            
            if ffa_records:
                forward_curves[vessel_type] = [
                    {"settlement": r.settlement or 15000, "month": r.contract_month}
                    for r in ffa_records
                ]
            else:
                # Default flat curve
                forward_curves[vessel_type] = [{"settlement": 15000}] * 12
        
        return forward_curves
    
    def _get_stock_price(self, ticker: str, calc_date: date) -> float:
        """Get stock price for a ticker."""
        price_record = self.session.query(EquityPrice).filter(
            EquityPrice.ticker == ticker,
            EquityPrice.date <= calc_date
        ).order_by(EquityPrice.date.desc()).first()
        
        return price_record.close if price_record else 20.0  # Default
    
    def _get_trailing_eps(self, company_id: int) -> float:
        """Get trailing 12-month EPS."""
        # Would query Financial table for last 4 quarters
        # Placeholder return
        return 2.0
    
    def _get_consensus_eps(self, ticker: str) -> Optional[float]:
        """Get analyst consensus EPS estimate."""
        # Would integrate with consensus data source
        return None
    
    def _days_to_earnings(self, ticker: str) -> Optional[int]:
        """Get days until next earnings announcement."""
        # Would integrate with earnings calendar
        return 45  # Default assumption
    
    def _get_macro_regime(self, calc_date: date) -> str:
        """Get current macro regime."""
        vix_record = self.session.query(MacroIndicator).filter(
            MacroIndicator.indicator_code == "VIX",
            MacroIndicator.date <= calc_date
        ).order_by(MacroIndicator.date.desc()).first()
        
        if vix_record:
            vix = vix_record.value
            if vix >= 35:
                return "risk_off"
            elif vix >= 25:
                return "caution"
        
        return "normal"
    
    def _calculate_correlations(
        self,
        ticker: str,
        calc_date: date,
        window: int = 60
    ) -> Tuple[float, float]:
        """Calculate rolling correlations."""
        # Simplified - would calculate actual correlations
        return 0.5, 0.3  # freight_corr, market_corr
    
    def _save_signal(self, result: SignalResult):
        """Save signal to database."""
        existing = self.session.query(Signal).filter(
            Signal.company_id == result.company_id,
            Signal.date == result.calculation_date
        ).first()
        
        if existing:
            # Update existing
            existing.lep = result.lep
            existing.fep = result.fep
            existing.eiep = result.eiep
            existing.inf_score = result.inf_score
            existing.dis_score = result.dis_score
            existing.buy_signal = result.buy_signal
            existing.sell_signal = result.sell_signal
            existing.signal_strength = result.signal_strength
        else:
            # Create new
            signal = Signal(
                company_id=result.company_id,
                date=result.calculation_date,
                lep=result.lep,
                lep_ebitda=result.lep_ebitda,
                fep=result.fep,
                fep_ebitda=result.fep_ebitda,
                eiep=result.eiep,
                inf_score=result.inf_score,
                dis_score=result.dis_score,
                inf_components=str(result.inf_components),
                red_months=result.red_months,
                fleet_spot_pct=result.fleet_spot_pct,
                freight_correlation=result.freight_correlation,
                market_correlation=result.market_correlation,
                buy_signal=result.buy_signal,
                sell_signal=result.sell_signal,
                signal_strength=result.signal_strength,
                trade_type=result.trade_type,
            )
            self.session.add(signal)
        
        self.session.commit()
