"""
Shipping Equity Alpha System

A quantitative trading system that exploits freight-equity mispricings
in shipping markets.
"""

__version__ = "1.0.0"
__author__ = "Shipping Alpha Team"

from .signals import (
    LEPCalculator,
    FEPCalculator,
    EIEPCalculator,
    REDCalculator,
    INFCalculator,
    DISCalculator,
    SignalEngine,
)

from .risk import (
    RiskRegime,
    RiskManager,
    MacroFilter,
)

__all__ = [
    # Signals
    "LEPCalculator",
    "FEPCalculator",
    "EIEPCalculator",
    "REDCalculator",
    "INFCalculator",
    "DISCalculator",
    "SignalEngine",
    
    # Risk
    "RiskRegime",
    "RiskManager",
    "MacroFilter",
]
