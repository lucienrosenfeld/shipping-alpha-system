"""
Shipping Equity Alpha System - Monitoring Dashboard

A real-time monitoring dashboard built with Plotly Dash.

Features:
- Universe signal overview table
- Signal drill-down panels
- Freight index charts
- Portfolio tracking
- Risk regime indicators
"""

import json
from datetime import date, datetime, timedelta
from typing import Dict, List, Optional, Any

import dash
from dash import dcc, html, dash_table, callback, Input, Output, State
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots

# Use Bootstrap theme for styling
app = dash.Dash(
    __name__,
    external_stylesheets=[dbc.themes.DARKLY],
    suppress_callback_exceptions=True,
)


def create_header():
    """Create dashboard header."""
    return dbc.Navbar(
        dbc.Container([
            dbc.NavbarBrand([
                html.I(className="fas fa-ship me-2"),
                "Shipping Equity Alpha System"
            ], className="ms-2"),
            dbc.Nav([
                dbc.NavItem(dbc.NavLink("Signals", href="#signals")),
                dbc.NavItem(dbc.NavLink("Portfolio", href="#portfolio")),
                dbc.NavItem(dbc.NavLink("Freight", href="#freight")),
                dbc.NavItem(dbc.NavLink("Risk", href="#risk")),
            ], navbar=True),
            html.Div([
                html.Span(id="current-time", className="text-muted me-3"),
                dbc.Badge(id="risk-regime-badge", color="success", className="me-2"),
            ], className="d-flex align-items-center"),
        ], fluid=True),
        color="dark",
        dark=True,
        sticky="top",
    )


def create_signal_table():
    """Create the main signal universe table."""
    return dbc.Card([
        dbc.CardHeader([
            html.H5("Signal Universe", className="mb-0 d-inline"),
            dbc.Button(
                "Refresh",
                id="refresh-signals-btn",
                color="primary",
                size="sm",
                className="float-end",
            ),
        ]),
        dbc.CardBody([
            dash_table.DataTable(
                id="signal-table",
                columns=[
                    {"name": "Ticker", "id": "ticker"},
                    {"name": "Price", "id": "price", "type": "numeric", "format": {"specifier": "$.2f"}},
                    {"name": "LEP", "id": "lep", "type": "numeric", "format": {"specifier": "$.2f"}},
                    {"name": "FEP", "id": "fep", "type": "numeric", "format": {"specifier": "$.2f"}},
                    {"name": "EIEP", "id": "eiep", "type": "numeric", "format": {"specifier": "$.2f"}},
                    {"name": "INF", "id": "inf", "type": "numeric", "format": {"specifier": ".0f"}},
                    {"name": "DIS", "id": "dis", "type": "numeric", "format": {"specifier": ".1%"}},
                    {"name": "Signal", "id": "signal"},
                    {"name": "Strength", "id": "strength", "type": "numeric", "format": {"specifier": ".2f"}},
                    {"name": "Type", "id": "trade_type"},
                ],
                data=[],  # Will be populated by callback
                style_table={"overflowX": "auto"},
                style_cell={
                    "textAlign": "left",
                    "padding": "10px",
                    "backgroundColor": "#303030",
                    "color": "white",
                },
                style_header={
                    "backgroundColor": "#404040",
                    "fontWeight": "bold",
                },
                style_data_conditional=[
                    {
                        "if": {"filter_query": "{signal} = 'BUY'"},
                        "backgroundColor": "rgba(0, 200, 100, 0.3)",
                    },
                    {
                        "if": {"filter_query": "{signal} = 'SELL'"},
                        "backgroundColor": "rgba(255, 100, 100, 0.3)",
                    },
                    {
                        "if": {"filter_query": "{dis} > 0.4"},
                        "color": "#00ff88",
                        "fontWeight": "bold",
                    },
                ],
                sort_action="native",
                filter_action="native",
                row_selectable="single",
                selected_rows=[],
                page_size=15,
            ),
        ]),
    ], className="mb-4")


def create_drill_down_panel():
    """Create the signal drill-down panel."""
    return dbc.Card([
        dbc.CardHeader(html.H5("Signal Details", className="mb-0")),
        dbc.CardBody([
            dbc.Row([
                dbc.Col([
                    html.H3(id="selected-ticker", className="text-primary"),
                    html.H6(id="selected-company-name", className="text-muted"),
                ], md=6),
                dbc.Col([
                    html.Div(id="signal-badge-container"),
                ], md=6, className="text-end"),
            ]),
            html.Hr(),
            dbc.Row([
                dbc.Col([
                    html.H6("Earnings Power", className="text-muted"),
                    html.Div(id="earnings-metrics"),
                ], md=4),
                dbc.Col([
                    html.H6("Signal Scores", className="text-muted"),
                    html.Div(id="signal-scores"),
                ], md=4),
                dbc.Col([
                    html.H6("Trade Details", className="text-muted"),
                    html.Div(id="trade-details"),
                ], md=4),
            ]),
            html.Hr(),
            html.H6("INF Score Breakdown", className="text-muted"),
            dcc.Graph(id="inf-breakdown-chart", style={"height": "200px"}),
        ]),
    ], className="mb-4", id="drill-down-panel")


def create_freight_charts():
    """Create freight index monitoring charts."""
    return dbc.Card([
        dbc.CardHeader([
            html.H5("Freight Indices", className="mb-0 d-inline"),
            dbc.Select(
                id="freight-timeframe",
                options=[
                    {"label": "1 Week", "value": "1W"},
                    {"label": "1 Month", "value": "1M"},
                    {"label": "3 Months", "value": "3M"},
                    {"label": "1 Year", "value": "1Y"},
                ],
                value="1M",
                style={"width": "120px", "display": "inline-block"},
                className="float-end",
            ),
        ]),
        dbc.CardBody([
            dbc.Row([
                dbc.Col([
                    dcc.Graph(id="dry-bulk-chart", style={"height": "300px"}),
                ], md=6),
                dbc.Col([
                    dcc.Graph(id="tanker-chart", style={"height": "300px"}),
                ], md=6),
            ]),
        ]),
    ], className="mb-4")


def create_portfolio_panel():
    """Create portfolio monitoring panel."""
    return dbc.Card([
        dbc.CardHeader(html.H5("Portfolio", className="mb-0")),
        dbc.CardBody([
            dbc.Row([
                dbc.Col([
                    html.H4("$0.00", id="portfolio-value", className="text-primary mb-0"),
                    html.Small("Total Value", className="text-muted"),
                ], md=3),
                dbc.Col([
                    html.H4("0%", id="portfolio-return", className="text-success mb-0"),
                    html.Small("Total Return", className="text-muted"),
                ], md=3),
                dbc.Col([
                    html.H4("0", id="position-count", className="mb-0"),
                    html.Small("Positions", className="text-muted"),
                ], md=3),
                dbc.Col([
                    html.H4("0%", id="invested-pct", className="mb-0"),
                    html.Small("Invested", className="text-muted"),
                ], md=3),
            ]),
            html.Hr(),
            html.H6("Current Positions", className="text-muted"),
            dash_table.DataTable(
                id="positions-table",
                columns=[
                    {"name": "Ticker", "id": "ticker"},
                    {"name": "Entry", "id": "entry_price", "type": "numeric", "format": {"specifier": "$.2f"}},
                    {"name": "Current", "id": "current_price", "type": "numeric", "format": {"specifier": "$.2f"}},
                    {"name": "P&L", "id": "pnl", "type": "numeric", "format": {"specifier": ".1%"}},
                    {"name": "Stop", "id": "stop_loss", "type": "numeric", "format": {"specifier": "$.2f"}},
                    {"name": "Type", "id": "trade_type"},
                    {"name": "Days", "id": "holding_days"},
                ],
                data=[],
                style_table={"overflowX": "auto"},
                style_cell={
                    "textAlign": "left",
                    "padding": "8px",
                    "backgroundColor": "#303030",
                    "color": "white",
                },
                style_header={
                    "backgroundColor": "#404040",
                    "fontWeight": "bold",
                },
                page_size=10,
            ),
        ]),
    ], className="mb-4")


def create_risk_panel():
    """Create risk regime monitoring panel."""
    return dbc.Card([
        dbc.CardHeader(html.H5("Risk Regime", className="mb-0")),
        dbc.CardBody([
            dbc.Row([
                dbc.Col([
                    dbc.Card([
                        dbc.CardBody([
                            html.H6("VIX", className="text-muted mb-1"),
                            html.H3("--", id="vix-value"),
                            dbc.Progress(id="vix-gauge", value=0, max=100, className="mt-2"),
                        ]),
                    ]),
                ], md=3),
                dbc.Col([
                    dbc.Card([
                        dbc.CardBody([
                            html.H6("Freight-Equity Corr", className="text-muted mb-1"),
                            html.H3("--", id="freight-corr-value"),
                            dbc.Progress(id="corr-gauge", value=0, max=100, className="mt-2"),
                        ]),
                    ]),
                ], md=3),
                dbc.Col([
                    dbc.Card([
                        dbc.CardBody([
                            html.H6("S&P 500 1W", className="text-muted mb-1"),
                            html.H3("--", id="sp500-1w-value"),
                        ]),
                    ]),
                ], md=3),
                dbc.Col([
                    dbc.Card([
                        dbc.CardBody([
                            html.H6("Position Sizing", className="text-muted mb-1"),
                            html.H3("--", id="sizing-multiplier"),
                        ]),
                    ]),
                ], md=3),
            ]),
            html.Hr(),
            html.H6("Correlation Regime", className="text-muted"),
            html.P(id="correlation-regime-description"),
        ]),
    ], className="mb-4")


def create_layout():
    """Create the main dashboard layout."""
    return html.Div([
        create_header(),
        dbc.Container([
            # Time update interval
            dcc.Interval(id="interval-component", interval=60*1000, n_intervals=0),
            
            # Signal data store
            dcc.Store(id="signals-store"),
            
            # Main content
            dbc.Row([
                # Left column - Signal table
                dbc.Col([
                    create_signal_table(),
                    create_portfolio_panel(),
                ], md=8),
                
                # Right column - Details and monitoring
                dbc.Col([
                    create_drill_down_panel(),
                    create_risk_panel(),
                ], md=4),
            ]),
            
            # Freight charts row
            dbc.Row([
                dbc.Col([
                    create_freight_charts(),
                ]),
            ]),
            
        ], fluid=True, className="mt-4"),
    ])


# =============================================================================
# Callbacks
# =============================================================================

@callback(
    Output("current-time", "children"),
    Input("interval-component", "n_intervals")
)
def update_time(n):
    """Update current time display."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


@callback(
    Output("signals-store", "data"),
    Input("refresh-signals-btn", "n_clicks"),
    Input("interval-component", "n_intervals"),
)
def refresh_signals(n_clicks, n_intervals):
    """Refresh signal data from engine."""
    # In production, this would call the signal engine
    # For now, return mock data
    return get_mock_signal_data()


@callback(
    Output("signal-table", "data"),
    Input("signals-store", "data"),
)
def update_signal_table(signals_data):
    """Update signal table with latest data."""
    if not signals_data:
        return []
    return signals_data


@callback(
    [
        Output("selected-ticker", "children"),
        Output("selected-company-name", "children"),
        Output("signal-badge-container", "children"),
        Output("earnings-metrics", "children"),
        Output("signal-scores", "children"),
        Output("trade-details", "children"),
        Output("inf-breakdown-chart", "figure"),
    ],
    Input("signal-table", "selected_rows"),
    State("signals-store", "data"),
)
def update_drill_down(selected_rows, signals_data):
    """Update drill-down panel when row selected."""
    if not selected_rows or not signals_data:
        return "Select a row", "", "", "", "", "", go.Figure()
    
    row_idx = selected_rows[0]
    if row_idx >= len(signals_data):
        return "Select a row", "", "", "", "", "", go.Figure()
    
    signal = signals_data[row_idx]
    
    # Signal badge
    badge_color = "success" if signal["signal"] == "BUY" else "danger" if signal["signal"] == "SELL" else "secondary"
    badge = dbc.Badge(signal["signal"], color=badge_color, className="fs-5")
    
    # Earnings metrics
    earnings = html.Div([
        html.P([html.Strong("LEP: "), f"${signal['lep']:.2f}"]),
        html.P([html.Strong("FEP: "), f"${signal['fep']:.2f}"]),
        html.P([html.Strong("EIEP: "), f"${signal['eiep']:.2f}"]),
    ])
    
    # Signal scores
    scores = html.Div([
        html.P([html.Strong("INF Score: "), f"{signal['inf']:.0f}"]),
        html.P([html.Strong("DIS Score: "), f"{signal['dis']:.1%}"]),
        html.P([html.Strong("Strength: "), f"{signal['strength']:.2f}"]),
    ])
    
    # Trade details
    trade = html.Div([
        html.P([html.Strong("Type: "), signal.get("trade_type", "N/A")]),
        html.P([html.Strong("Target: "), f"${signal.get('target', 0):.2f}" if signal.get('target') else "N/A"]),
        html.P([html.Strong("Stop: "), f"${signal.get('stop', 0):.2f}" if signal.get('stop') else "N/A"]),
    ])
    
    # INF breakdown chart
    inf_fig = go.Figure(data=[
        go.Bar(
            x=["Earnings Δ", "Fleet Repricing", "Consensus Gap", "Breakeven"],
            y=[30, 25, 20, 15],  # Mock data
            marker_color=["#00cc88", "#00cc88", "#00cc88", "#00cc88"],
        )
    ])
    inf_fig.update_layout(
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=20, r=20, t=20, b=20),
        height=200,
    )
    
    return (
        signal["ticker"],
        f"{signal['ticker']} Corp",
        badge,
        earnings,
        scores,
        trade,
        inf_fig,
    )


@callback(
    [
        Output("dry-bulk-chart", "figure"),
        Output("tanker-chart", "figure"),
    ],
    Input("freight-timeframe", "value"),
)
def update_freight_charts(timeframe):
    """Update freight index charts."""
    # Mock data for charts
    import random
    from datetime import timedelta
    
    days = {"1W": 7, "1M": 30, "3M": 90, "1Y": 365}.get(timeframe, 30)
    dates = [date.today() - timedelta(days=i) for i in range(days, 0, -1)]
    
    # Dry bulk chart
    bdi = [1500 + random.uniform(-200, 200) for _ in dates]
    for i in range(1, len(bdi)):
        bdi[i] = bdi[i-1] * (1 + random.uniform(-0.03, 0.03))
    
    dry_fig = go.Figure()
    dry_fig.add_trace(go.Scatter(x=dates, y=bdi, name="BDI", line=dict(color="#00cc88")))
    dry_fig.update_layout(
        title="Baltic Dry Index (BDI)",
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=20, r=20, t=40, b=20),
        showlegend=False,
    )
    
    # Tanker chart
    bdti = [1000 + random.uniform(-150, 150) for _ in dates]
    for i in range(1, len(bdti)):
        bdti[i] = bdti[i-1] * (1 + random.uniform(-0.03, 0.03))
    
    tanker_fig = go.Figure()
    tanker_fig.add_trace(go.Scatter(x=dates, y=bdti, name="BDTI", line=dict(color="#ff6b6b")))
    tanker_fig.update_layout(
        title="Baltic Dirty Tanker Index (BDTI)",
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=20, r=20, t=40, b=20),
        showlegend=False,
    )
    
    return dry_fig, tanker_fig


@callback(
    Output("risk-regime-badge", "children"),
    Output("risk-regime-badge", "color"),
    Input("interval-component", "n_intervals"),
)
def update_risk_badge(n):
    """Update risk regime badge."""
    # Mock - would come from risk manager
    return "NORMAL", "success"


@callback(
    [
        Output("vix-value", "children"),
        Output("vix-gauge", "value"),
        Output("freight-corr-value", "children"),
        Output("corr-gauge", "value"),
        Output("sp500-1w-value", "children"),
        Output("sizing-multiplier", "children"),
        Output("correlation-regime-description", "children"),
    ],
    Input("interval-component", "n_intervals"),
)
def update_risk_panel(n):
    """Update risk panel metrics."""
    # Mock data
    import random
    vix = random.uniform(15, 25)
    corr = random.uniform(0.3, 0.7)
    sp500 = random.uniform(-0.02, 0.03)
    
    return (
        f"{vix:.1f}",
        min(100, vix * 3),
        f"{corr:.2f}",
        corr * 100,
        f"{sp500:.1%}",
        "1.0x",
        "Freight-driven: Stock prices primarily follow freight market fundamentals."
    )


# =============================================================================
# Mock Data
# =============================================================================

def get_mock_signal_data():
    """Generate mock signal data for testing."""
    import random
    
    tickers = [
        ("SBLK", "Star Bulk"), ("GOGL", "Golden Ocean"), ("GNK", "Genco"),
        ("FRO", "Frontline"), ("DHT", "DHT Holdings"), ("STNG", "Scorpio"),
        ("ZIM", "ZIM Shipping"), ("DAC", "Danaos"),
    ]
    
    data = []
    for ticker, name in tickers:
        lep = random.uniform(2, 8)
        fep = lep * random.uniform(0.8, 1.2)
        eiep = fep * random.uniform(0.5, 1.0)
        dis = (fep - eiep) / fep if fep > 0 else 0
        inf = random.uniform(30, 90)
        strength = random.uniform(0.3, 0.9)
        
        if dis > 0.35 and inf > 60:
            signal = "BUY"
            trade_type = "earnings_surprise" if inf > 70 else "re_rating"
        elif dis < -0.2:
            signal = "SELL"
            trade_type = "overvalued"
        else:
            signal = "HOLD"
            trade_type = None
        
        data.append({
            "ticker": ticker,
            "price": random.uniform(10, 60),
            "lep": lep,
            "fep": fep,
            "eiep": eiep,
            "inf": inf,
            "dis": dis,
            "signal": signal,
            "strength": strength if signal == "BUY" else 0,
            "trade_type": trade_type,
            "target": fep * 5 if signal == "BUY" else None,
            "stop": eiep * 5 * 0.85 if signal == "BUY" else None,
        })
    
    return sorted(data, key=lambda x: x["strength"], reverse=True)


# =============================================================================
# App Factory
# =============================================================================

def create_app():
    """Create and configure the Dash app."""
    app.layout = create_layout()
    return app


# Run directly
if __name__ == "__main__":
    app = create_app()
    app.run_server(debug=True, port=8050)
