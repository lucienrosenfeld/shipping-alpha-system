"""
Equity market data API client.

Fetches stock prices, fundamentals, and market data from:
- Yahoo Finance (via yfinance - no API key required)
- Alpha Vantage (free tier available)
- Polygon.io (optional)

Primary use is Yahoo Finance as it's free and reliable for shipping stocks.
"""

from datetime import date, datetime, timedelta
from typing import Dict, List, Optional, Any, Union
import random

from loguru import logger

try:
    import yfinance as yf
    YFINANCE_AVAILABLE = True
except ImportError:
    YFINANCE_AVAILABLE = False
    logger.warning("yfinance not installed - using mock data")

from .base import BaseAPIClient, APIError, MockDataMixin


class EquityDataClient(MockDataMixin):
    """
    Client for equity market data.
    
    Primary data source is Yahoo Finance (free, no API key).
    Falls back to Alpha Vantage or mock data if unavailable.
    """
    
    def __init__(
        self,
        alpha_vantage_key: Optional[str] = None,
        polygon_key: Optional[str] = None,
        use_cache: bool = True,
    ):
        self.alpha_vantage_key = alpha_vantage_key
        self.polygon_key = polygon_key
        self.use_cache = use_cache
        self._cache: Dict[str, Any] = {}
        
        logger.info(f"EquityDataClient initialized (yfinance available: {YFINANCE_AVAILABLE})")
    
    def get_price(
        self,
        ticker: str,
        as_of_date: Optional[date] = None,
    ) -> Dict[str, Any]:
        """
        Get current or historical stock price.
        
        Args:
            ticker: Stock ticker symbol
            as_of_date: Date for historical price (default: latest)
            
        Returns:
            Dict with price data
        """
        if YFINANCE_AVAILABLE:
            return self._get_price_yfinance(ticker, as_of_date)
        return self._generate_mock_price(ticker, as_of_date)
    
    def get_price_history(
        self,
        ticker: str,
        start_date: date,
        end_date: Optional[date] = None,
        interval: str = "1d",
    ) -> List[Dict[str, Any]]:
        """
        Get historical price data.
        
        Args:
            ticker: Stock ticker
            start_date: Start date
            end_date: End date (default: today)
            interval: Data interval ("1d", "1wk", "1mo")
            
        Returns:
            List of OHLCV data
        """
        if YFINANCE_AVAILABLE:
            return self._get_history_yfinance(ticker, start_date, end_date, interval)
        return self._generate_mock_history(ticker, start_date, end_date)
    
    def get_fundamentals(self, ticker: str) -> Dict[str, Any]:
        """
        Get company fundamental data.
        
        Args:
            ticker: Stock ticker
            
        Returns:
            Dict with fundamental metrics
        """
        if YFINANCE_AVAILABLE:
            return self._get_fundamentals_yfinance(ticker)
        return self._generate_mock_fundamentals(ticker)
    
    def get_bulk_prices(
        self,
        tickers: List[str],
        as_of_date: Optional[date] = None,
    ) -> Dict[str, Dict[str, Any]]:
        """
        Get prices for multiple tickers efficiently.
        
        Args:
            tickers: List of ticker symbols
            as_of_date: Date for prices
            
        Returns:
            Dict mapping ticker to price data
        """
        results = {}
        for ticker in tickers:
            try:
                results[ticker] = self.get_price(ticker, as_of_date)
            except Exception as e:
                logger.warning(f"Failed to get price for {ticker}: {e}")
        return results
    
    def calculate_returns(
        self,
        ticker: str,
        start_date: date,
        end_date: Optional[date] = None,
    ) -> Dict[str, float]:
        """
        Calculate return metrics for a stock.
        
        Args:
            ticker: Stock ticker
            start_date: Start date
            end_date: End date
            
        Returns:
            Dict with return metrics
        """
        history = self.get_price_history(ticker, start_date, end_date)
        
        if not history or len(history) < 2:
            return {"total_return": 0, "annualized_return": 0, "volatility": 0}
        
        prices = [h["close"] for h in history if h.get("close")]
        if len(prices) < 2:
            return {"total_return": 0, "annualized_return": 0, "volatility": 0}
        
        total_return = (prices[-1] - prices[0]) / prices[0]
        
        # Calculate daily returns for volatility
        daily_returns = []
        for i in range(1, len(prices)):
            daily_returns.append((prices[i] - prices[i-1]) / prices[i-1])
        
        import statistics
        volatility = statistics.stdev(daily_returns) * (252 ** 0.5) if len(daily_returns) > 1 else 0
        
        days = (history[-1]["date"] - history[0]["date"]).days if isinstance(history[0]["date"], date) else len(history)
        annualized_return = ((1 + total_return) ** (365 / max(days, 1))) - 1 if days > 0 else 0
        
        return {
            "total_return": total_return,
            "annualized_return": annualized_return,
            "volatility": volatility,
            "days": days,
        }
    
    # =========================================================================
    # Yahoo Finance Implementation
    # =========================================================================
    
    def _get_price_yfinance(
        self,
        ticker: str,
        as_of_date: Optional[date] = None,
    ) -> Dict[str, Any]:
        """Get price data via yfinance."""
        try:
            stock = yf.Ticker(ticker)
            
            if as_of_date:
                # Get historical data for the specific date
                end = as_of_date + timedelta(days=1)
                start = as_of_date - timedelta(days=5)  # Buffer for weekends
                hist = stock.history(start=start, end=end)
                
                if hist.empty:
                    raise APIError(f"No data for {ticker} on {as_of_date}")
                
                # Get the closest available date
                row = hist.iloc[-1]
                actual_date = hist.index[-1].date()
            else:
                # Get latest data
                hist = stock.history(period="1d")
                if hist.empty:
                    hist = stock.history(period="5d")
                
                if hist.empty:
                    raise APIError(f"No recent data for {ticker}")
                
                row = hist.iloc[-1]
                actual_date = hist.index[-1].date()
            
            return {
                "ticker": ticker,
                "date": actual_date.isoformat(),
                "open": float(row["Open"]),
                "high": float(row["High"]),
                "low": float(row["Low"]),
                "close": float(row["Close"]),
                "volume": int(row["Volume"]),
                "adjusted_close": float(row["Close"]),  # yfinance returns adjusted by default
            }
            
        except Exception as e:
            logger.error(f"yfinance error for {ticker}: {e}")
            raise APIError(f"Failed to fetch {ticker}: {e}")
    
    def _get_history_yfinance(
        self,
        ticker: str,
        start_date: date,
        end_date: Optional[date] = None,
        interval: str = "1d",
    ) -> List[Dict[str, Any]]:
        """Get historical data via yfinance."""
        try:
            stock = yf.Ticker(ticker)
            end = end_date or date.today()
            
            hist = stock.history(
                start=start_date,
                end=end + timedelta(days=1),
                interval=interval,
            )
            
            if hist.empty:
                return []
            
            results = []
            for idx, row in hist.iterrows():
                results.append({
                    "ticker": ticker,
                    "date": idx.date() if hasattr(idx, 'date') else idx,
                    "open": float(row["Open"]),
                    "high": float(row["High"]),
                    "low": float(row["Low"]),
                    "close": float(row["Close"]),
                    "volume": int(row["Volume"]),
                })
            
            return results
            
        except Exception as e:
            logger.error(f"yfinance history error for {ticker}: {e}")
            return []
    
    def _get_fundamentals_yfinance(self, ticker: str) -> Dict[str, Any]:
        """Get fundamentals via yfinance."""
        try:
            stock = yf.Ticker(ticker)
            info = stock.info
            
            return {
                "ticker": ticker,
                "name": info.get("longName", ticker),
                "sector": info.get("sector", "Unknown"),
                "industry": info.get("industry", "Unknown"),
                "market_cap": info.get("marketCap"),
                "enterprise_value": info.get("enterpriseValue"),
                "shares_outstanding": info.get("sharesOutstanding"),
                "float_shares": info.get("floatShares"),
                "pe_ratio": info.get("trailingPE"),
                "forward_pe": info.get("forwardPE"),
                "price_to_book": info.get("priceToBook"),
                "ev_ebitda": info.get("enterpriseToEbitda"),
                "profit_margin": info.get("profitMargins"),
                "operating_margin": info.get("operatingMargins"),
                "revenue": info.get("totalRevenue"),
                "ebitda": info.get("ebitda"),
                "net_income": info.get("netIncomeToCommon"),
                "total_debt": info.get("totalDebt"),
                "total_cash": info.get("totalCash"),
                "dividend_yield": info.get("dividendYield"),
                "beta": info.get("beta"),
                "52_week_high": info.get("fiftyTwoWeekHigh"),
                "52_week_low": info.get("fiftyTwoWeekLow"),
            }
            
        except Exception as e:
            logger.error(f"yfinance fundamentals error for {ticker}: {e}")
            return {"ticker": ticker, "error": str(e)}
    
    # =========================================================================
    # Mock Data Generation
    # =========================================================================
    
    def _generate_mock_price(
        self,
        ticker: str,
        as_of_date: Optional[date] = None,
    ) -> Dict[str, Any]:
        """Generate mock price data."""
        # Typical shipping stock prices
        base_prices = {
            "SBLK": 20, "GOGL": 12, "GNK": 18, "EGLE": 45, "DSX": 4,
            "FRO": 25, "DHT": 12, "STNG": 60, "TNK": 55, "NAT": 3,
            "ZIM": 15, "DAC": 80, "GSL": 25,
        }
        
        base = base_prices.get(ticker, 20)
        price = base * random.uniform(0.8, 1.2)
        
        return {
            "ticker": ticker,
            "date": (as_of_date or date.today()).isoformat(),
            "open": round(price * 0.99, 2),
            "high": round(price * 1.02, 2),
            "low": round(price * 0.98, 2),
            "close": round(price, 2),
            "volume": random.randint(500000, 5000000),
            "_mock": True,
        }
    
    def _generate_mock_history(
        self,
        ticker: str,
        start_date: date,
        end_date: Optional[date] = None,
    ) -> List[Dict[str, Any]]:
        """Generate mock historical data."""
        end = end_date or date.today()
        
        base_prices = {"SBLK": 20, "GOGL": 12, "GNK": 18, "FRO": 25}
        base = base_prices.get(ticker, 20)
        
        history = []
        current_price = base
        current_date = start_date
        
        while current_date <= end:
            if current_date.weekday() < 5:  # Skip weekends
                drift = random.uniform(-0.03, 0.03)
                current_price = current_price * (1 + drift)
                current_price = max(1, current_price)  # Floor at $1
                
                history.append({
                    "ticker": ticker,
                    "date": current_date,
                    "open": round(current_price * 0.99, 2),
                    "high": round(current_price * 1.02, 2),
                    "low": round(current_price * 0.98, 2),
                    "close": round(current_price, 2),
                    "volume": random.randint(500000, 5000000),
                    "_mock": True,
                })
            
            current_date += timedelta(days=1)
        
        return history
    
    def _generate_mock_fundamentals(self, ticker: str) -> Dict[str, Any]:
        """Generate mock fundamental data."""
        return {
            "ticker": ticker,
            "name": f"{ticker} Corp",
            "market_cap": random.randint(500_000_000, 5_000_000_000),
            "enterprise_value": random.randint(600_000_000, 6_000_000_000),
            "shares_outstanding": random.randint(50_000_000, 200_000_000),
            "pe_ratio": random.uniform(3, 10),
            "ev_ebitda": random.uniform(2, 8),
            "total_debt": random.randint(100_000_000, 1_000_000_000),
            "total_cash": random.randint(50_000_000, 500_000_000),
            "dividend_yield": random.uniform(0.02, 0.15),
            "_mock": True,
        }


class MacroDataClient(MockDataMixin):
    """
    Client for macro economic data.
    
    Fetches:
    - VIX (volatility index)
    - S&P 500
    - Treasury yields
    - Credit spreads
    - Commodity prices
    """
    
    # Macro indicator tickers
    INDICATORS = {
        "VIX": {"ticker": "^VIX", "name": "CBOE Volatility Index"},
        "SPX": {"ticker": "^GSPC", "name": "S&P 500"},
        "DJI": {"ticker": "^DJI", "name": "Dow Jones"},
        "TNX": {"ticker": "^TNX", "name": "10-Year Treasury Yield"},
        "CL": {"ticker": "CL=F", "name": "Crude Oil Futures"},
        "HG": {"ticker": "HG=F", "name": "Copper Futures"},
        "DXY": {"ticker": "DX-Y.NYB", "name": "US Dollar Index"},
    }
    
    def __init__(self, fred_api_key: Optional[str] = None):
        self.fred_api_key = fred_api_key
        logger.info("MacroDataClient initialized")
    
    def get_indicator(
        self,
        indicator: str,
        as_of_date: Optional[date] = None,
    ) -> Dict[str, Any]:
        """Get a macro indicator value."""
        if indicator not in self.INDICATORS:
            raise ValueError(f"Unknown indicator: {indicator}")
        
        if YFINANCE_AVAILABLE:
            return self._get_indicator_yfinance(indicator, as_of_date)
        return self._generate_mock_indicator(indicator, as_of_date)
    
    def get_all_indicators(
        self,
        as_of_date: Optional[date] = None,
    ) -> Dict[str, Dict[str, Any]]:
        """Get all macro indicators."""
        results = {}
        for indicator in self.INDICATORS.keys():
            try:
                results[indicator] = self.get_indicator(indicator, as_of_date)
            except Exception as e:
                logger.warning(f"Failed to get {indicator}: {e}")
        return results
    
    def get_vix(self, as_of_date: Optional[date] = None) -> float:
        """Get VIX value."""
        data = self.get_indicator("VIX", as_of_date)
        return data.get("value", 20)
    
    def _get_indicator_yfinance(
        self,
        indicator: str,
        as_of_date: Optional[date] = None,
    ) -> Dict[str, Any]:
        """Get indicator via yfinance."""
        info = self.INDICATORS[indicator]
        ticker = info["ticker"]
        
        try:
            stock = yf.Ticker(ticker)
            
            if as_of_date:
                hist = stock.history(
                    start=as_of_date - timedelta(days=5),
                    end=as_of_date + timedelta(days=1)
                )
            else:
                hist = stock.history(period="1d")
                if hist.empty:
                    hist = stock.history(period="5d")
            
            if hist.empty:
                raise APIError(f"No data for {indicator}")
            
            row = hist.iloc[-1]
            actual_date = hist.index[-1].date() if hasattr(hist.index[-1], 'date') else hist.index[-1]
            
            return {
                "indicator": indicator,
                "name": info["name"],
                "date": actual_date.isoformat() if hasattr(actual_date, 'isoformat') else str(actual_date),
                "value": float(row["Close"]),
                "change": float(row["Close"] - row["Open"]),
            }
            
        except Exception as e:
            logger.error(f"Failed to fetch {indicator}: {e}")
            return self._generate_mock_indicator(indicator, as_of_date)
    
    def _generate_mock_indicator(
        self,
        indicator: str,
        as_of_date: Optional[date] = None,
    ) -> Dict[str, Any]:
        """Generate mock indicator data."""
        typical_values = {
            "VIX": (15, 35),
            "SPX": (4000, 5500),
            "DJI": (33000, 40000),
            "TNX": (3, 5),
            "CL": (60, 90),
            "HG": (3, 5),
            "DXY": (100, 110),
        }
        
        low, high = typical_values.get(indicator, (10, 100))
        value = random.uniform(low, high)
        
        return {
            "indicator": indicator,
            "name": self.INDICATORS.get(indicator, {}).get("name", indicator),
            "date": (as_of_date or date.today()).isoformat(),
            "value": round(value, 2),
            "_mock": True,
        }
