"""
Bunker fuel price API client.

Fetches marine fuel prices from various sources:
- Ship & Bunker
- Platts
- Bloomberg (via terminal)

Key fuel types:
- VLSFO: Very Low Sulfur Fuel Oil (0.5% sulfur) - IMO 2020 compliant
- MGO: Marine Gas Oil (distillate)
- HSFO: High Sulfur Fuel Oil (3.5% sulfur) - with scrubber
"""

from datetime import date, timedelta
from typing import Dict, List, Optional, Any
import random

from loguru import logger

from .base import BaseAPIClient, APIError, MockDataMixin


class BunkerPriceClient(BaseAPIClient, MockDataMixin):
    """
    Client for bunker fuel prices.
    
    Fetches prices for major bunkering ports:
    - Singapore (largest bunkering hub)
    - Rotterdam (Europe)
    - Fujairah (Middle East)
    - Houston (Americas)
    """
    
    # Major bunkering ports
    PORTS = {
        "SINGAPORE": {"region": "Asia", "weight": 0.35},
        "ROTTERDAM": {"region": "Europe", "weight": 0.20},
        "FUJAIRAH": {"region": "Middle East", "weight": 0.15},
        "HOUSTON": {"region": "Americas", "weight": 0.15},
        "HONG_KONG": {"region": "Asia", "weight": 0.10},
        "BUSAN": {"region": "Asia", "weight": 0.05},
    }
    
    # Fuel types
    FUEL_TYPES = {
        "VLSFO": {"description": "Very Low Sulfur Fuel Oil (0.5%)", "typical_range": (400, 700)},
        "MGO": {"description": "Marine Gas Oil", "typical_range": (600, 900)},
        "HSFO": {"description": "High Sulfur Fuel Oil (3.5%)", "typical_range": (300, 500)},
        "LSMGO": {"description": "Low Sulfur Marine Gas Oil", "typical_range": (650, 950)},
    }
    
    # Typical spreads
    TYPICAL_SPREADS = {
        "VLSFO_HSFO": 150,  # Scrubber economics
        "MGO_VLSFO": 100,
    }
    
    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.shipandbunker.com/v1",
    ):
        super().__init__(base_url=base_url, api_key=api_key, rate_limit=30)
        logger.info(f"BunkerPriceClient initialized (placeholder: {self.is_placeholder_key()})")
    
    def _add_auth_headers(self):
        """Add authentication headers."""
        self.session.headers.update({
            "Authorization": f"Bearer {self.api_key}",
        })
    
    def health_check(self) -> bool:
        """Check API connectivity."""
        if self.is_placeholder_key():
            return True
        try:
            self.get("/health")
            return True
        except APIError:
            return False
    
    def get_price(
        self,
        port: str,
        fuel_type: str = "VLSFO",
        as_of_date: Optional[date] = None,
    ) -> Dict[str, Any]:
        """
        Get bunker price for a specific port and fuel type.
        
        Args:
            port: Port code (e.g., "SINGAPORE")
            fuel_type: Fuel type (e.g., "VLSFO", "MGO")
            as_of_date: Date for price
            
        Returns:
            Price data in $/mt
        """
        if self.is_placeholder_key():
            return self._generate_mock_price(port, fuel_type, as_of_date)
        
        params = {
            "port": port,
            "fuel": fuel_type,
        }
        if as_of_date:
            params["date"] = as_of_date.isoformat()
        
        return self.get("/prices", params=params)
    
    def get_all_prices(
        self,
        fuel_type: str = "VLSFO",
        as_of_date: Optional[date] = None,
    ) -> Dict[str, Dict[str, Any]]:
        """
        Get prices across all major ports.
        
        Args:
            fuel_type: Fuel type
            as_of_date: Date for prices
            
        Returns:
            Dict mapping port to price data
        """
        results = {}
        for port in self.PORTS.keys():
            try:
                results[port] = self.get_price(port, fuel_type, as_of_date)
            except APIError as e:
                logger.warning(f"Failed to get {port} price: {e}")
        return results
    
    def get_global_average(
        self,
        fuel_type: str = "VLSFO",
        as_of_date: Optional[date] = None,
    ) -> float:
        """
        Calculate weighted global average bunker price.
        
        Uses port weights based on bunkering volume.
        
        Args:
            fuel_type: Fuel type
            as_of_date: Date
            
        Returns:
            Weighted average price in $/mt
        """
        prices = self.get_all_prices(fuel_type, as_of_date)
        
        total_weight = 0
        weighted_sum = 0
        
        for port, data in prices.items():
            weight = self.PORTS.get(port, {}).get("weight", 0.1)
            price = data.get("price", 0)
            if price > 0:
                weighted_sum += price * weight
                total_weight += weight
        
        return weighted_sum / total_weight if total_weight > 0 else 0
    
    def get_price_history(
        self,
        port: str,
        fuel_type: str,
        start_date: date,
        end_date: Optional[date] = None,
    ) -> List[Dict[str, Any]]:
        """
        Get historical bunker prices.
        
        Args:
            port: Port code
            fuel_type: Fuel type
            start_date: Start date
            end_date: End date
            
        Returns:
            List of daily prices
        """
        if self.is_placeholder_key():
            return self._generate_mock_history(port, fuel_type, start_date, end_date)
        
        params = {
            "port": port,
            "fuel": fuel_type,
            "start_date": start_date.isoformat(),
            "end_date": (end_date or date.today()).isoformat(),
        }
        
        return self.get("/prices/history", params=params)
    
    def calculate_voyage_fuel_cost(
        self,
        consumption_mt_day: float,
        voyage_days: int,
        fuel_type: str = "VLSFO",
        port: str = "SINGAPORE",
    ) -> Dict[str, float]:
        """
        Calculate estimated fuel cost for a voyage.
        
        Args:
            consumption_mt_day: Daily fuel consumption in metric tons
            voyage_days: Number of voyage days
            fuel_type: Fuel type
            port: Bunkering port
            
        Returns:
            Dict with cost breakdown
        """
        price_data = self.get_price(port, fuel_type)
        price_per_mt = price_data.get("price", 500)  # Default $500/mt
        
        total_consumption = consumption_mt_day * voyage_days
        total_cost = total_consumption * price_per_mt
        daily_cost = consumption_mt_day * price_per_mt
        
        return {
            "fuel_type": fuel_type,
            "price_per_mt": price_per_mt,
            "consumption_per_day": consumption_mt_day,
            "voyage_days": voyage_days,
            "total_consumption_mt": total_consumption,
            "total_cost_usd": total_cost,
            "daily_fuel_cost": daily_cost,
        }
    
    # =========================================================================
    # Mock Data Generation
    # =========================================================================
    
    def _generate_mock_price(
        self,
        port: str,
        fuel_type: str,
        as_of_date: Optional[date] = None,
    ) -> Dict[str, Any]:
        """Generate mock bunker price."""
        fuel_info = self.FUEL_TYPES.get(fuel_type, {"typical_range": (400, 700)})
        low, high = fuel_info["typical_range"]
        
        # Regional adjustments
        port_info = self.PORTS.get(port, {})
        region = port_info.get("region", "Global")
        
        regional_adjustment = {
            "Asia": 1.0,
            "Europe": 1.05,
            "Middle East": 0.95,
            "Americas": 1.10,
        }.get(region, 1.0)
        
        base_price = (low + high) / 2 * random.uniform(0.9, 1.1) * regional_adjustment
        
        return {
            "port": port,
            "fuel_type": fuel_type,
            "date": (as_of_date or date.today()).isoformat(),
            "price": round(base_price, 2),
            "unit": "$/mt",
            "region": region,
            "_mock": True,
        }
    
    def _generate_mock_history(
        self,
        port: str,
        fuel_type: str,
        start_date: date,
        end_date: Optional[date] = None,
    ) -> List[Dict[str, Any]]:
        """Generate mock historical prices."""
        end = end_date or date.today()
        fuel_info = self.FUEL_TYPES.get(fuel_type, {"typical_range": (400, 700)})
        low, high = fuel_info["typical_range"]
        
        history = []
        current_price = (low + high) / 2
        current_date = start_date
        
        while current_date <= end:
            if current_date.weekday() < 5:  # Skip weekends
                # Oil-like price movement
                drift = random.uniform(-0.02, 0.02)
                mean_reversion = ((low + high) / 2 - current_price) * 0.01
                current_price = current_price * (1 + drift) + mean_reversion
                current_price = max(low * 0.7, min(high * 1.3, current_price))
                
                history.append({
                    "port": port,
                    "fuel_type": fuel_type,
                    "date": current_date.isoformat(),
                    "price": round(current_price, 2),
                    "unit": "$/mt",
                    "_mock": True,
                })
            
            current_date += timedelta(days=1)
        
        return history
