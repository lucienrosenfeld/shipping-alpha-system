"""
Baltic Exchange API client for freight indices.

This client fetches Baltic Exchange freight indices including:
- BDI (Baltic Dry Index)
- BCI (Baltic Capesize Index)
- BPI (Baltic Panamax Index)
- BSI (Baltic Supramax Index)
- BHSI (Baltic Handysize Index)
- BDTI (Baltic Dirty Tanker Index)
- BCTI (Baltic Clean Tanker Index)

API Documentation: https://www.balticexchange.com/en/data-services/api.html
"""

from datetime import date, datetime, timedelta
from typing import Dict, List, Optional, Any
import random

from loguru import logger

from .base import BaseAPIClient, APIError, MockDataMixin


class BalticExchangeClient(BaseAPIClient, MockDataMixin):
    """
    Client for Baltic Exchange API.
    
    Provides access to:
    - Daily freight indices
    - Route assessments
    - TCE (Time Charter Equivalent) calculations
    - Historical data
    
    Note: Requires Baltic Exchange API subscription.
    Contact: https://www.balticexchange.com/en/data-services.html
    """
    
    # Index codes and their typical ranges
    INDEX_INFO = {
        "BDI": {"name": "Baltic Dry Index", "typical_range": (500, 5000)},
        "BCI": {"name": "Baltic Capesize Index", "typical_range": (500, 8000)},
        "BPI": {"name": "Baltic Panamax Index", "typical_range": (500, 5000)},
        "BSI": {"name": "Baltic Supramax Index", "typical_range": (500, 4000)},
        "BHSI": {"name": "Baltic Handysize Index", "typical_range": (300, 2500)},
        "BDTI": {"name": "Baltic Dirty Tanker Index", "typical_range": (500, 3000)},
        "BCTI": {"name": "Baltic Clean Tanker Index", "typical_range": (400, 2500)},
    }
    
    # TCE conversion factors (approximate $/day per index point)
    TCE_FACTORS = {
        "BCI": 150,   # ~$150/day per index point for Capesize
        "BPI": 100,   # ~$100/day per index point for Panamax
        "BSI": 80,    # ~$80/day per index point for Supramax
        "BHSI": 60,   # ~$60/day per index point for Handysize
    }
    
    def __init__(self, api_key: str, base_url: str = "https://api.balticexchange.com/v1"):
        super().__init__(base_url=base_url, api_key=api_key, rate_limit=30)
        logger.info(f"BalticExchangeClient initialized (placeholder: {self.is_placeholder_key()})")
    
    def _add_auth_headers(self):
        """Add Baltic Exchange authentication."""
        self.session.headers.update({
            "Authorization": f"Bearer {self.api_key}",
            "X-API-Key": self.api_key,
        })
    
    def health_check(self) -> bool:
        """Check API connectivity."""
        if self.is_placeholder_key():
            logger.warning("Using placeholder API key - returning mock health check")
            return True
        try:
            self.get("/health")
            return True
        except APIError:
            return False
    
    def get_index(self, index_code: str, as_of_date: Optional[date] = None) -> Dict[str, Any]:
        """
        Get a single freight index value.
        
        Args:
            index_code: Index code (e.g., "BDI", "BCI")
            as_of_date: Date for the index (default: latest)
            
        Returns:
            Dict with index value and metadata
        """
        if self.is_placeholder_key():
            return self._generate_mock_index(index_code, as_of_date)
        
        params = {"index": index_code}
        if as_of_date:
            params["date"] = as_of_date.isoformat()
        
        return self.get("/indices", params=params)
    
    def get_all_indices(self, as_of_date: Optional[date] = None) -> Dict[str, Dict[str, Any]]:
        """
        Get all freight indices.
        
        Args:
            as_of_date: Date for indices (default: latest)
            
        Returns:
            Dict mapping index code to value and metadata
        """
        results = {}
        for index_code in self.INDEX_INFO.keys():
            try:
                results[index_code] = self.get_index(index_code, as_of_date)
            except APIError as e:
                logger.warning(f"Failed to fetch {index_code}: {e}")
        return results
    
    def get_index_history(
        self,
        index_code: str,
        start_date: date,
        end_date: Optional[date] = None,
    ) -> List[Dict[str, Any]]:
        """
        Get historical index values.
        
        Args:
            index_code: Index code
            start_date: Start of date range
            end_date: End of date range (default: today)
            
        Returns:
            List of daily index values
        """
        if self.is_placeholder_key():
            return self._generate_mock_history(index_code, start_date, end_date)
        
        params = {
            "index": index_code,
            "start_date": start_date.isoformat(),
            "end_date": (end_date or date.today()).isoformat(),
        }
        
        return self.get("/indices/history", params=params)
    
    def get_route_assessments(
        self,
        route_codes: Optional[List[str]] = None,
        as_of_date: Optional[date] = None,
    ) -> Dict[str, Any]:
        """
        Get route-specific freight assessments.
        
        Args:
            route_codes: List of route codes (e.g., ["C5", "C3"])
            as_of_date: Date for assessments
            
        Returns:
            Route assessment data
        """
        if self.is_placeholder_key():
            return self._generate_mock_routes(route_codes, as_of_date)
        
        params = {}
        if route_codes:
            params["routes"] = ",".join(route_codes)
        if as_of_date:
            params["date"] = as_of_date.isoformat()
        
        return self.get("/routes", params=params)
    
    def index_to_tce(self, index_code: str, index_value: float) -> Optional[float]:
        """
        Convert index value to approximate TCE ($/day).
        
        Args:
            index_code: Index code (BCI, BPI, BSI, BHSI)
            index_value: Index value
            
        Returns:
            Approximate TCE in $/day, or None if not applicable
        """
        factor = self.TCE_FACTORS.get(index_code)
        if factor:
            return index_value * factor
        return None
    
    # =========================================================================
    # Mock Data Generation (for development/testing)
    # =========================================================================
    
    def _generate_mock_index(self, index_code: str, as_of_date: Optional[date] = None) -> Dict[str, Any]:
        """Generate mock index data."""
        info = self.INDEX_INFO.get(index_code, {"typical_range": (500, 2000)})
        low, high = info["typical_range"]
        
        # Generate a somewhat realistic value with some randomness
        base_value = (low + high) / 2
        variance = (high - low) * 0.3
        value = base_value + random.uniform(-variance, variance)
        
        # Previous day value for change calculation
        prev_value = base_value + random.uniform(-variance, variance)
        change = value - prev_value
        change_pct = (change / prev_value) * 100 if prev_value else 0
        
        return {
            "index_code": index_code,
            "name": info.get("name", index_code),
            "date": (as_of_date or date.today()).isoformat(),
            "value": round(value, 2),
            "change": round(change, 2),
            "change_pct": round(change_pct, 2),
            "tce_equivalent": self.index_to_tce(index_code, value),
            "_mock": True,
        }
    
    def _generate_mock_history(
        self,
        index_code: str,
        start_date: date,
        end_date: Optional[date] = None,
    ) -> List[Dict[str, Any]]:
        """Generate mock historical data."""
        end_date = end_date or date.today()
        info = self.INDEX_INFO.get(index_code, {"typical_range": (500, 2000)})
        low, high = info["typical_range"]
        
        history = []
        current_value = (low + high) / 2
        current_date = start_date
        
        while current_date <= end_date:
            # Skip weekends
            if current_date.weekday() < 5:
                # Random walk with mean reversion
                drift = random.uniform(-0.02, 0.02)
                mean_reversion = ((low + high) / 2 - current_value) * 0.01
                current_value = current_value * (1 + drift + mean_reversion)
                current_value = max(low * 0.5, min(high * 1.5, current_value))
                
                history.append({
                    "index_code": index_code,
                    "date": current_date.isoformat(),
                    "value": round(current_value, 2),
                    "tce_equivalent": self.index_to_tce(index_code, current_value),
                    "_mock": True,
                })
            
            current_date += timedelta(days=1)
        
        return history
    
    def _generate_mock_routes(
        self,
        route_codes: Optional[List[str]] = None,
        as_of_date: Optional[date] = None,
    ) -> Dict[str, Any]:
        """Generate mock route assessment data."""
        # Common dry bulk routes
        default_routes = {
            "C5": {"description": "W Australia to China", "segment": "capesize", "base_rate": 10.0},
            "C3": {"description": "Tubarao to Qingdao", "segment": "capesize", "base_rate": 25.0},
            "P1A": {"description": "Transatlantic RV", "segment": "panamax", "base_rate": 12000},
            "P3A": {"description": "Skaw-Gibraltar to Far East", "segment": "panamax", "base_rate": 20000},
            "S1B": {"description": "US Gulf to China-S Japan", "segment": "supramax", "base_rate": 35.0},
        }
        
        route_codes = route_codes or list(default_routes.keys())
        
        routes = {}
        for code in route_codes:
            info = default_routes.get(code, {"description": "Unknown", "segment": "unknown", "base_rate": 10000})
            base = info["base_rate"]
            value = base * random.uniform(0.7, 1.5)
            
            routes[code] = {
                "route_code": code,
                "description": info["description"],
                "segment": info["segment"],
                "date": (as_of_date or date.today()).isoformat(),
                "rate": round(value, 2),
                "unit": "$/mt" if value < 100 else "$/day",
                "_mock": True,
            }
        
        return {"routes": routes, "date": (as_of_date or date.today()).isoformat()}
