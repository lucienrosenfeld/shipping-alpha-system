"""
Risk management module for the Shipping Equity Alpha System.

Components:
- Macro Filter: VIX, credit spreads, market drawdown
- Correlation Regime Detection: Freight-equity correlation tracking
- Position Sizing: Kelly criterion and volatility-adjusted sizing
- Stop Loss Management: Fixed, trailing, and volatility-adjusted stops
"""

from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from enum import Enum
import statistics

from loguru import logger


class RiskRegime(Enum):
    """Market risk regime classification."""
    NORMAL = "normal"
    CAUTION = "caution"
    RISK_OFF = "risk_off"


@dataclass
class MacroSnapshot:
    """Snapshot of macro indicators."""
    date: date
    vix: float
    spx_level: float
    spx_change_1w: float  # Weekly % change
    spx_change_1m: float  # Monthly % change
    credit_spread: Optional[float] = None  # High yield spread
    treasury_10y: Optional[float] = None
    dxy: Optional[float] = None  # Dollar index
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "date": self.date.isoformat(),
            "vix": self.vix,
            "spx_level": self.spx_level,
            "spx_change_1w": self.spx_change_1w,
            "spx_change_1m": self.spx_change_1m,
            "credit_spread": self.credit_spread,
            "treasury_10y": self.treasury_10y,
            "dxy": self.dxy,
        }


@dataclass
class CorrelationMetrics:
    """Correlation metrics for a stock."""
    ticker: str
    calculation_date: date
    window_days: int
    
    freight_correlation: float  # Correlation to freight index
    market_correlation: float  # Correlation to S&P 500
    freight_beta: float  # Sensitivity to freight
    market_beta: float  # Sensitivity to market
    
    # Rolling metrics
    freight_corr_trend: float = 0  # Change in correlation
    correlation_regime: str = "normal"  # "normal", "decoupled", "macro_driven"


class MacroFilter:
    """
    Macro risk filter for position sizing and entry/exit decisions.
    
    Monitors:
    - VIX levels and spikes
    - Market drawdowns
    - Credit spreads
    - Currency moves
    """
    
    def __init__(
        self,
        vix_caution_threshold: float = 25.0,
        vix_risk_off_threshold: float = 35.0,
        drawdown_caution_threshold: float = -0.05,  # 5% weekly decline
        drawdown_risk_off_threshold: float = -0.10,  # 10% weekly decline
        credit_spread_threshold: float = 5.0,  # High yield spread in %
    ):
        self.vix_caution = vix_caution_threshold
        self.vix_risk_off = vix_risk_off_threshold
        self.drawdown_caution = drawdown_caution_threshold
        self.drawdown_risk_off = drawdown_risk_off_threshold
        self.credit_spread_threshold = credit_spread_threshold
    
    def assess_regime(self, snapshot: MacroSnapshot) -> Tuple[RiskRegime, Dict[str, Any]]:
        """
        Assess current risk regime from macro indicators.
        
        Args:
            snapshot: Current macro snapshot
            
        Returns:
            Tuple of (regime, details)
        """
        flags = {
            "vix_elevated": False,
            "vix_extreme": False,
            "market_stress": False,
            "market_crash": False,
            "credit_stress": False,
        }
        
        # VIX assessment
        if snapshot.vix >= self.vix_risk_off:
            flags["vix_extreme"] = True
        elif snapshot.vix >= self.vix_caution:
            flags["vix_elevated"] = True
        
        # Market drawdown assessment
        if snapshot.spx_change_1w <= self.drawdown_risk_off:
            flags["market_crash"] = True
        elif snapshot.spx_change_1w <= self.drawdown_caution:
            flags["market_stress"] = True
        
        # Credit spread assessment
        if snapshot.credit_spread and snapshot.credit_spread >= self.credit_spread_threshold:
            flags["credit_stress"] = True
        
        # Determine regime
        if flags["vix_extreme"] or flags["market_crash"]:
            regime = RiskRegime.RISK_OFF
        elif flags["vix_elevated"] or flags["market_stress"] or flags["credit_stress"]:
            regime = RiskRegime.CAUTION
        else:
            regime = RiskRegime.NORMAL
        
        details = {
            "regime": regime.value,
            "flags": flags,
            "vix": snapshot.vix,
            "spx_change_1w": snapshot.spx_change_1w,
            "recommendation": self._get_recommendation(regime, flags),
        }
        
        return regime, details
    
    def _get_recommendation(self, regime: RiskRegime, flags: Dict[str, bool]) -> str:
        """Generate actionable recommendation."""
        if regime == RiskRegime.RISK_OFF:
            return "Halt new positions. Consider reducing exposure. Wait for volatility to subside."
        elif regime == RiskRegime.CAUTION:
            parts = []
            if flags["vix_elevated"]:
                parts.append("elevated VIX")
            if flags["market_stress"]:
                parts.append("market weakness")
            if flags["credit_stress"]:
                parts.append("credit stress")
            reasons = ", ".join(parts)
            return f"Reduce position sizes by 30-50% due to {reasons}. Tighten stops."
        else:
            return "Normal conditions. Standard position sizing and risk parameters."
    
    def get_position_multiplier(self, regime: RiskRegime) -> float:
        """Get position size multiplier for regime."""
        return {
            RiskRegime.NORMAL: 1.0,
            RiskRegime.CAUTION: 0.6,
            RiskRegime.RISK_OFF: 0.0,
        }.get(regime, 1.0)


class CorrelationRegimeDetector:
    """
    Detects correlation regimes between shipping stocks, freight indices, and broader market.
    
    Key regimes:
    - Normal: Stocks track freight fundamentals
    - Decoupled: Stocks ignore freight (usually cheap)
    - Macro-driven: Stocks track S&P more than freight
    """
    
    def __init__(
        self,
        window_days: int = 60,
        low_freight_corr_threshold: float = 0.2,
        high_market_corr_threshold: float = 0.6,
    ):
        self.window_days = window_days
        self.low_freight_corr = low_freight_corr_threshold
        self.high_market_corr = high_market_corr_threshold
    
    def calculate_correlations(
        self,
        stock_returns: List[float],
        freight_returns: List[float],
        market_returns: List[float],
    ) -> Tuple[float, float]:
        """
        Calculate rolling correlations.
        
        Args:
            stock_returns: Daily stock returns
            freight_returns: Daily freight index returns
            market_returns: Daily S&P returns
            
        Returns:
            Tuple of (freight_correlation, market_correlation)
        """
        n = min(len(stock_returns), len(freight_returns), len(market_returns))
        if n < 10:
            return 0, 0
        
        stock = stock_returns[-n:]
        freight = freight_returns[-n:]
        market = market_returns[-n:]
        
        freight_corr = self._correlation(stock, freight)
        market_corr = self._correlation(stock, market)
        
        return freight_corr, market_corr
    
    def _correlation(self, x: List[float], y: List[float]) -> float:
        """Calculate Pearson correlation."""
        n = len(x)
        if n < 2:
            return 0
        
        mean_x = sum(x) / n
        mean_y = sum(y) / n
        
        cov = sum((x[i] - mean_x) * (y[i] - mean_y) for i in range(n)) / n
        std_x = (sum((xi - mean_x) ** 2 for xi in x) / n) ** 0.5
        std_y = (sum((yi - mean_y) ** 2 for yi in y) / n) ** 0.5
        
        if std_x * std_y == 0:
            return 0
        
        return cov / (std_x * std_y)
    
    def classify_regime(
        self,
        freight_correlation: float,
        market_correlation: float,
    ) -> str:
        """
        Classify correlation regime.
        
        Returns:
            "normal", "decoupled", or "macro_driven"
        """
        if freight_correlation < self.low_freight_corr:
            if market_correlation > self.high_market_corr:
                return "macro_driven"
            else:
                return "decoupled"
        else:
            return "normal"
    
    def get_signal_confidence_adjustment(self, regime: str) -> float:
        """
        Adjust signal confidence based on correlation regime.
        
        In macro-driven regimes, fundamental signals are less reliable.
        In decoupled regimes, potential for mean-reversion is higher.
        """
        return {
            "normal": 1.0,
            "decoupled": 1.1,  # Slightly higher - potential opportunity
            "macro_driven": 0.7,  # Lower - fundamentals less relevant
        }.get(regime, 1.0)


class PositionSizer:
    """
    Position sizing calculator.
    
    Methods:
    - Fixed percentage of equity
    - Volatility-adjusted (risk parity)
    - Kelly criterion (edge-based)
    """
    
    def __init__(
        self,
        max_position_pct: float = 0.15,  # 15% max single position
        max_sector_pct: float = 0.40,  # 40% max sector exposure
        target_volatility: float = 0.20,  # 20% annual portfolio vol target
        min_position_pct: float = 0.03,  # 3% minimum position
    ):
        self.max_position_pct = max_position_pct
        self.max_sector_pct = max_sector_pct
        self.target_volatility = target_volatility
        self.min_position_pct = min_position_pct
    
    def calculate_fixed_size(
        self,
        portfolio_value: float,
        stock_price: float,
        target_pct: float = 0.10,
    ) -> Dict[str, Any]:
        """
        Calculate fixed percentage position size.
        
        Args:
            portfolio_value: Total portfolio value
            stock_price: Current stock price
            target_pct: Target position as % of portfolio
            
        Returns:
            Position sizing details
        """
        target_pct = min(target_pct, self.max_position_pct)
        position_value = portfolio_value * target_pct
        shares = int(position_value / stock_price)
        actual_value = shares * stock_price
        actual_pct = actual_value / portfolio_value
        
        return {
            "method": "fixed_percentage",
            "shares": shares,
            "position_value": actual_value,
            "position_pct": actual_pct,
            "stock_price": stock_price,
        }
    
    def calculate_volatility_adjusted(
        self,
        portfolio_value: float,
        stock_price: float,
        stock_volatility: float,  # Annualized volatility
        portfolio_volatility: float = None,
    ) -> Dict[str, Any]:
        """
        Calculate volatility-adjusted position size.
        
        Higher volatility stocks get smaller positions.
        
        Args:
            portfolio_value: Total portfolio value
            stock_price: Current stock price
            stock_volatility: Stock's annualized volatility
            portfolio_volatility: Current portfolio volatility
            
        Returns:
            Position sizing details
        """
        if stock_volatility <= 0:
            stock_volatility = 0.40  # Default 40% volatility assumption
        
        # Risk contribution approach
        # Target: each position contributes similar risk
        vol_scalar = self.target_volatility / stock_volatility
        raw_pct = 0.10 * vol_scalar  # Base 10%, adjusted for vol
        
        # Apply limits
        target_pct = max(self.min_position_pct, min(self.max_position_pct, raw_pct))
        
        position_value = portfolio_value * target_pct
        shares = int(position_value / stock_price)
        actual_value = shares * stock_price
        
        return {
            "method": "volatility_adjusted",
            "shares": shares,
            "position_value": actual_value,
            "position_pct": actual_value / portfolio_value,
            "stock_volatility": stock_volatility,
            "vol_scalar": vol_scalar,
        }
    
    def calculate_kelly(
        self,
        portfolio_value: float,
        stock_price: float,
        win_probability: float,
        win_loss_ratio: float,  # Average win / average loss
        kelly_fraction: float = 0.25,  # Use 25% of full Kelly
    ) -> Dict[str, Any]:
        """
        Calculate Kelly criterion position size.
        
        Args:
            portfolio_value: Total portfolio value
            stock_price: Current stock price
            win_probability: Estimated probability of profit
            win_loss_ratio: Average win / average loss
            kelly_fraction: Fraction of Kelly to use (default 0.25)
            
        Returns:
            Position sizing details
        """
        # Kelly formula: f* = (bp - q) / b
        # Where b = win/loss ratio, p = win prob, q = loss prob
        b = win_loss_ratio
        p = win_probability
        q = 1 - p
        
        full_kelly = (b * p - q) / b if b > 0 else 0
        
        # Apply fraction and limits
        kelly_pct = full_kelly * kelly_fraction
        kelly_pct = max(0, min(self.max_position_pct, kelly_pct))
        
        position_value = portfolio_value * kelly_pct
        shares = int(position_value / stock_price)
        actual_value = shares * stock_price
        
        return {
            "method": "kelly_criterion",
            "shares": shares,
            "position_value": actual_value,
            "position_pct": actual_value / portfolio_value,
            "full_kelly": full_kelly,
            "kelly_fraction_used": kelly_fraction,
            "win_probability": win_probability,
            "win_loss_ratio": win_loss_ratio,
        }
    
    def check_sector_limit(
        self,
        proposed_position_pct: float,
        current_sector_exposure: float,
    ) -> Tuple[bool, float]:
        """
        Check if position would exceed sector limits.
        
        Returns:
            Tuple of (allowed, adjusted_pct)
        """
        new_exposure = current_sector_exposure + proposed_position_pct
        
        if new_exposure <= self.max_sector_pct:
            return True, proposed_position_pct
        else:
            # Reduce to fit within limit
            available = max(0, self.max_sector_pct - current_sector_exposure)
            return available > self.min_position_pct, available


class StopLossManager:
    """
    Stop loss calculation and management.
    
    Types:
    - Fixed percentage stop
    - Volatility-adjusted stop (ATR-based)
    - Trailing stop
    """
    
    def __init__(
        self,
        default_stop_pct: float = 0.15,  # 15% default stop
        atr_multiplier: float = 2.0,  # 2x ATR for vol-adjusted stop
        trailing_activation_pct: float = 0.10,  # Activate trailing after 10% gain
        trailing_distance_pct: float = 0.08,  # Trail 8% below high
    ):
        self.default_stop_pct = default_stop_pct
        self.atr_multiplier = atr_multiplier
        self.trailing_activation_pct = trailing_activation_pct
        self.trailing_distance_pct = trailing_distance_pct
    
    def calculate_initial_stop(
        self,
        entry_price: float,
        method: str = "fixed",
        atr: Optional[float] = None,
    ) -> Dict[str, Any]:
        """
        Calculate initial stop loss price.
        
        Args:
            entry_price: Entry price
            method: "fixed" or "volatility"
            atr: Average True Range (for volatility method)
            
        Returns:
            Stop loss details
        """
        if method == "volatility" and atr:
            stop_distance = atr * self.atr_multiplier
            stop_price = entry_price - stop_distance
            stop_pct = stop_distance / entry_price
        else:
            stop_pct = self.default_stop_pct
            stop_price = entry_price * (1 - stop_pct)
        
        return {
            "entry_price": entry_price,
            "stop_price": round(stop_price, 2),
            "stop_pct": stop_pct,
            "method": method,
            "risk_per_share": entry_price - stop_price,
        }
    
    def update_trailing_stop(
        self,
        entry_price: float,
        current_price: float,
        highest_price: float,
        current_stop: float,
    ) -> Dict[str, Any]:
        """
        Update trailing stop based on price movement.
        
        Args:
            entry_price: Original entry price
            current_price: Current price
            highest_price: Highest price since entry
            current_stop: Current stop price
            
        Returns:
            Updated stop details
        """
        gain_pct = (highest_price - entry_price) / entry_price
        
        # Check if trailing stop should activate
        if gain_pct >= self.trailing_activation_pct:
            trailing_stop = highest_price * (1 - self.trailing_distance_pct)
            new_stop = max(current_stop, trailing_stop)
        else:
            new_stop = current_stop
        
        return {
            "stop_price": round(new_stop, 2),
            "trailing_active": gain_pct >= self.trailing_activation_pct,
            "gain_from_entry": gain_pct,
            "highest_price": highest_price,
            "current_price": current_price,
            "distance_from_high": (highest_price - current_price) / highest_price,
        }
    
    def check_stop_triggered(
        self,
        current_price: float,
        stop_price: float,
        current_low: Optional[float] = None,
    ) -> Tuple[bool, str]:
        """
        Check if stop loss has been triggered.
        
        Args:
            current_price: Current price
            stop_price: Stop loss price
            current_low: Intraday low (optional)
            
        Returns:
            Tuple of (triggered, reason)
        """
        check_price = current_low if current_low else current_price
        
        if check_price <= stop_price:
            return True, f"Stop triggered at {stop_price:.2f} (price: {check_price:.2f})"
        
        return False, ""


@dataclass
class RiskAssessment:
    """Complete risk assessment for a trade."""
    ticker: str
    assessment_date: date
    
    # Regime
    macro_regime: RiskRegime
    correlation_regime: str
    
    # Position sizing
    recommended_size_pct: float
    max_size_pct: float
    sizing_method: str
    
    # Stops
    initial_stop_pct: float
    stop_price: float
    
    # Risk metrics
    position_risk_pct: float  # Portfolio % at risk
    expected_loss_if_stopped: float
    
    # Adjustments
    regime_multiplier: float
    correlation_adjustment: float
    
    # Recommendation
    proceed: bool
    notes: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "ticker": self.ticker,
            "date": self.assessment_date.isoformat(),
            "macro_regime": self.macro_regime.value,
            "correlation_regime": self.correlation_regime,
            "recommended_size_pct": self.recommended_size_pct,
            "initial_stop_pct": self.initial_stop_pct,
            "stop_price": self.stop_price,
            "position_risk_pct": self.position_risk_pct,
            "proceed": self.proceed,
            "notes": self.notes,
        }


class RiskManager:
    """
    Unified risk management interface.
    
    Combines macro filtering, correlation regime, position sizing, and stop management.
    """
    
    def __init__(
        self,
        macro_filter: MacroFilter = None,
        correlation_detector: CorrelationRegimeDetector = None,
        position_sizer: PositionSizer = None,
        stop_manager: StopLossManager = None,
    ):
        self.macro_filter = macro_filter or MacroFilter()
        self.correlation_detector = correlation_detector or CorrelationRegimeDetector()
        self.position_sizer = position_sizer or PositionSizer()
        self.stop_manager = stop_manager or StopLossManager()
    
    def assess_trade(
        self,
        ticker: str,
        stock_price: float,
        portfolio_value: float,
        macro_snapshot: MacroSnapshot,
        stock_volatility: float,
        freight_correlation: float,
        market_correlation: float,
        signal_strength: float,
        current_sector_exposure: float = 0,
    ) -> RiskAssessment:
        """
        Complete risk assessment for a potential trade.
        
        Args:
            ticker: Stock ticker
            stock_price: Current price
            portfolio_value: Total portfolio value
            macro_snapshot: Current macro indicators
            stock_volatility: Stock's annualized volatility
            freight_correlation: Correlation to freight index
            market_correlation: Correlation to S&P
            signal_strength: Signal strength (0-1)
            current_sector_exposure: Current exposure to this sector
            
        Returns:
            Complete risk assessment
        """
        notes = []
        
        # 1. Assess macro regime
        macro_regime, macro_details = self.macro_filter.assess_regime(macro_snapshot)
        regime_multiplier = self.macro_filter.get_position_multiplier(macro_regime)
        notes.append(macro_details["recommendation"])
        
        # 2. Assess correlation regime
        corr_regime = self.correlation_detector.classify_regime(
            freight_correlation, market_correlation
        )
        corr_adjustment = self.correlation_detector.get_signal_confidence_adjustment(corr_regime)
        
        if corr_regime == "macro_driven":
            notes.append("Correlation regime: macro-driven. Fundamental signals less reliable.")
        elif corr_regime == "decoupled":
            notes.append("Correlation regime: decoupled. Potential mean-reversion opportunity.")
        
        # 3. Calculate position size
        vol_sizing = self.position_sizer.calculate_volatility_adjusted(
            portfolio_value, stock_price, stock_volatility
        )
        
        # Adjust for regime and signal strength
        base_pct = vol_sizing["position_pct"]
        adjusted_pct = base_pct * regime_multiplier * corr_adjustment * signal_strength
        
        # Check sector limits
        allowed, final_pct = self.position_sizer.check_sector_limit(
            adjusted_pct, current_sector_exposure
        )
        
        if not allowed:
            notes.append(f"Position reduced due to sector limit. Current exposure: {current_sector_exposure:.1%}")
        
        # 4. Calculate stop loss
        stop_details = self.stop_manager.calculate_initial_stop(
            stock_price, method="volatility", atr=stock_price * stock_volatility / 16
        )
        
        # 5. Calculate risk metrics
        position_value = portfolio_value * final_pct
        shares = int(position_value / stock_price)
        risk_per_share = stock_price - stop_details["stop_price"]
        total_risk = shares * risk_per_share
        portfolio_risk_pct = total_risk / portfolio_value
        
        # 6. Final decision
        proceed = (
            macro_regime != RiskRegime.RISK_OFF and
            final_pct >= self.position_sizer.min_position_pct and
            signal_strength >= 0.3
        )
        
        if not proceed:
            if macro_regime == RiskRegime.RISK_OFF:
                notes.append("Trade blocked: Risk-off regime")
            elif final_pct < self.position_sizer.min_position_pct:
                notes.append("Trade blocked: Position too small after adjustments")
            elif signal_strength < 0.3:
                notes.append("Trade blocked: Signal too weak")
        
        return RiskAssessment(
            ticker=ticker,
            assessment_date=macro_snapshot.date,
            macro_regime=macro_regime,
            correlation_regime=corr_regime,
            recommended_size_pct=final_pct,
            max_size_pct=self.position_sizer.max_position_pct,
            sizing_method="volatility_adjusted",
            initial_stop_pct=stop_details["stop_pct"],
            stop_price=stop_details["stop_price"],
            position_risk_pct=portfolio_risk_pct,
            expected_loss_if_stopped=total_risk,
            regime_multiplier=regime_multiplier,
            correlation_adjustment=corr_adjustment,
            proceed=proceed,
            notes=notes,
        )
