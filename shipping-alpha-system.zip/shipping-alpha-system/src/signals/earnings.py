"""
Signal calculation engine for the Shipping Equity Alpha System.

Core signals:
- LEP: Live Earnings Power
- FEP: Forward Earnings Power
- EIEP: Equity-Implied Earnings Power
- INF: Inflection Score
- DIS: Disbelief Score

This module contains the calculation logic for each signal.
"""

from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from enum import Enum
import json

from loguru import logger


@dataclass
class VesselEarnings:
    """Earnings breakdown for a single vessel."""
    vessel_id: int
    vessel_type: str
    charter_type: str  # "spot" or "time_charter"
    daily_rate: float  # $/day
    days_at_rate: int
    daily_opex: float  # $/day operating cost
    
    @property
    def gross_revenue(self) -> float:
        return self.daily_rate * self.days_at_rate
    
    @property
    def operating_cost(self) -> float:
        return self.daily_opex * self.days_at_rate
    
    @property
    def net_earnings(self) -> float:
        return self.gross_revenue - self.operating_cost


@dataclass
class FleetEarnings:
    """Aggregated fleet earnings calculation."""
    company_id: int
    calculation_date: date
    projection_period_days: int
    
    vessel_earnings: List[VesselEarnings] = field(default_factory=list)
    
    # Cost overheads
    ga_expense: float = 0  # General & Administrative
    interest_expense: float = 0
    depreciation: float = 0
    
    @property
    def total_gross_revenue(self) -> float:
        return sum(ve.gross_revenue for ve in self.vessel_earnings)
    
    @property
    def total_operating_cost(self) -> float:
        return sum(ve.operating_cost for ve in self.vessel_earnings)
    
    @property
    def gross_profit(self) -> float:
        return self.total_gross_revenue - self.total_operating_cost
    
    @property
    def ebitda(self) -> float:
        return self.gross_profit - self.ga_expense
    
    @property
    def operating_income(self) -> float:
        return self.ebitda - self.depreciation
    
    @property
    def net_income(self) -> float:
        return self.operating_income - self.interest_expense
    
    def annualized_ebitda(self) -> float:
        """Annualize EBITDA based on projection period."""
        return self.ebitda * (365 / self.projection_period_days)
    
    def annualized_net_income(self) -> float:
        """Annualize net income."""
        return self.net_income * (365 / self.projection_period_days)


@dataclass 
class SignalResult:
    """Container for calculated signals."""
    company_id: int
    ticker: str
    calculation_date: date
    
    # Core signals
    lep: float  # Live Earnings Power (EPS)
    lep_ebitda: float  # LEP as EBITDA
    fep: float  # Forward Earnings Power (EPS)
    fep_ebitda: float  # FEP as EBITDA
    eiep: float  # Equity-Implied Earnings Power
    
    inf_score: float  # Inflection Score (0-100)
    dis_score: float  # Disbelief Score (ratio)
    
    # Components
    inf_components: Dict[str, float] = field(default_factory=dict)
    
    # Supporting metrics
    red_months: float = 0  # Realized Earnings Delay
    fleet_spot_pct: float = 0  # % of fleet on spot
    freight_correlation: float = 0
    market_correlation: float = 0
    
    # Trade signals
    buy_signal: bool = False
    sell_signal: bool = False
    signal_strength: float = 0
    trade_type: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "company_id": self.company_id,
            "ticker": self.ticker,
            "date": self.calculation_date.isoformat(),
            "lep": self.lep,
            "lep_ebitda": self.lep_ebitda,
            "fep": self.fep,
            "fep_ebitda": self.fep_ebitda,
            "eiep": self.eiep,
            "inf_score": self.inf_score,
            "dis_score": self.dis_score,
            "inf_components": self.inf_components,
            "red_months": self.red_months,
            "fleet_spot_pct": self.fleet_spot_pct,
            "buy_signal": self.buy_signal,
            "sell_signal": self.sell_signal,
            "signal_strength": self.signal_strength,
            "trade_type": self.trade_type,
        }


class LEPCalculator:
    """
    Live Earnings Power (LEP) Calculator.
    
    Calculates the annualized earnings run-rate based on current spot market
    conditions. Answers: "If today's freight rates and costs persisted, 
    how much would this company earn in a year?"
    """
    
    def __init__(
        self,
        spot_rate_smoothing_days: int = 7,
        utilization_rate: float = 0.95,
    ):
        self.spot_rate_smoothing_days = spot_rate_smoothing_days
        self.utilization_rate = utilization_rate
    
    def calculate(
        self,
        company_data: Dict[str, Any],
        vessels: List[Dict[str, Any]],
        charters: List[Dict[str, Any]],
        spot_rates: Dict[str, float],  # vessel_type -> $/day
        calculation_date: date,
        projection_days: int = 365,
    ) -> FleetEarnings:
        """
        Calculate LEP for a company.
        
        Args:
            company_data: Company financial data
            vessels: List of vessel records
            charters: List of active charter contracts
            spot_rates: Current spot TCE rates by vessel type
            calculation_date: Date of calculation
            projection_days: Days to project forward
            
        Returns:
            FleetEarnings with breakdown
        """
        fleet_earnings = FleetEarnings(
            company_id=company_data.get("id", 0),
            calculation_date=calculation_date,
            projection_period_days=projection_days,
        )
        
        # Build charter lookup by vessel
        charter_by_vessel = {}
        for charter in charters:
            if charter.get("vessel_id"):
                charter_by_vessel[charter["vessel_id"]] = charter
        
        # Calculate earnings for each vessel
        for vessel in vessels:
            if not vessel.get("active", True):
                continue
            
            vessel_id = vessel.get("id", 0)
            vessel_type = vessel.get("vessel_type", "unknown")
            daily_opex = vessel.get("daily_opex", 5000)  # Default $5k/day
            
            charter = charter_by_vessel.get(vessel_id)
            
            if charter and charter.get("charter_type") == "time_charter":
                # Vessel on time charter
                charter_end = charter.get("end_date")
                if charter_end:
                    if isinstance(charter_end, str):
                        charter_end = datetime.fromisoformat(charter_end).date()
                    
                    # Days remaining on charter
                    days_on_charter = min(
                        projection_days,
                        max(0, (charter_end - calculation_date).days)
                    )
                    days_on_spot = projection_days - days_on_charter
                else:
                    # Open-ended charter
                    days_on_charter = projection_days
                    days_on_spot = 0
                
                charter_rate = charter.get("daily_rate", 0)
                
                # Add charter earnings
                if days_on_charter > 0:
                    fleet_earnings.vessel_earnings.append(VesselEarnings(
                        vessel_id=vessel_id,
                        vessel_type=vessel_type,
                        charter_type="time_charter",
                        daily_rate=charter_rate,
                        days_at_rate=int(days_on_charter * self.utilization_rate),
                        daily_opex=daily_opex,
                    ))
                
                # Add spot earnings after charter ends
                if days_on_spot > 0:
                    spot_rate = spot_rates.get(vessel_type, 15000)
                    fleet_earnings.vessel_earnings.append(VesselEarnings(
                        vessel_id=vessel_id,
                        vessel_type=vessel_type,
                        charter_type="spot",
                        daily_rate=spot_rate,
                        days_at_rate=int(days_on_spot * self.utilization_rate),
                        daily_opex=daily_opex,
                    ))
            else:
                # Vessel on spot market
                spot_rate = spot_rates.get(vessel_type, 15000)
                fleet_earnings.vessel_earnings.append(VesselEarnings(
                    vessel_id=vessel_id,
                    vessel_type=vessel_type,
                    charter_type="spot",
                    daily_rate=spot_rate,
                    days_at_rate=int(projection_days * self.utilization_rate),
                    daily_opex=daily_opex,
                ))
        
        # Add company overhead costs
        fleet_earnings.ga_expense = company_data.get("annual_ga_expense", 0) * (projection_days / 365)
        fleet_earnings.interest_expense = company_data.get("annual_interest_expense", 0) * (projection_days / 365)
        fleet_earnings.depreciation = company_data.get("depreciation", 0) * (projection_days / 365)
        
        return fleet_earnings
    
    def to_eps(
        self,
        fleet_earnings: FleetEarnings,
        shares_outstanding: float,
    ) -> float:
        """Convert fleet earnings to EPS."""
        if shares_outstanding <= 0:
            return 0
        return fleet_earnings.annualized_net_income() / shares_outstanding


class FEPCalculator:
    """
    Forward Earnings Power (FEP) Calculator.
    
    Projects earnings using FFA forward curves instead of spot rates.
    Answers: "If the currently implied forward freight curve plays out,
    how much will the company earn?"
    """
    
    def __init__(self, lep_calculator: LEPCalculator):
        self.lep_calculator = lep_calculator
    
    def calculate(
        self,
        company_data: Dict[str, Any],
        vessels: List[Dict[str, Any]],
        charters: List[Dict[str, Any]],
        forward_curves: Dict[str, List[Dict[str, float]]],  # vessel_type -> [(month, rate), ...]
        calculation_date: date,
        projection_quarters: int = 4,
    ) -> FleetEarnings:
        """
        Calculate FEP using forward freight curves.
        
        Args:
            company_data: Company data
            vessels: Fleet vessels
            charters: Active charters
            forward_curves: FFA forward curves by vessel type
            calculation_date: Calculation date
            projection_quarters: Number of quarters to project
            
        Returns:
            FleetEarnings projection
        """
        projection_days = projection_quarters * 91  # ~91 days per quarter
        
        # Calculate weighted average forward rate per vessel type
        avg_forward_rates = {}
        for vessel_type, curve in forward_curves.items():
            if not curve:
                avg_forward_rates[vessel_type] = 15000  # Default
                continue
            
            # Simple average of forward curve (could be weighted)
            rates = [point.get("settlement", point.get("rate", 0)) for point in curve[:projection_quarters * 3]]
            avg_forward_rates[vessel_type] = sum(rates) / len(rates) if rates else 15000
        
        # Use LEP calculator with forward rates instead of spot
        return self.lep_calculator.calculate(
            company_data=company_data,
            vessels=vessels,
            charters=charters,
            spot_rates=avg_forward_rates,
            calculation_date=calculation_date,
            projection_days=projection_days,
        )
    
    def to_eps(
        self,
        fleet_earnings: FleetEarnings,
        shares_outstanding: float,
    ) -> float:
        """Convert forward earnings to EPS."""
        if shares_outstanding <= 0:
            return 0
        return fleet_earnings.annualized_net_income() / shares_outstanding


class EIEPCalculator:
    """
    Equity-Implied Earnings Power (EIEP) Calculator.
    
    Estimates what earnings level the stock price is pricing in.
    Inverts valuation: given market value, what earnings would make it fair?
    """
    
    def __init__(
        self,
        default_pe: float = 5.0,
        pe_range: Tuple[float, float] = (3.0, 10.0),
    ):
        self.default_pe = default_pe
        self.pe_min, self.pe_max = pe_range
    
    def calculate(
        self,
        stock_price: float,
        shares_outstanding: float,
        enterprise_value: Optional[float] = None,
        pe_multiple: Optional[float] = None,
        ev_ebitda_multiple: Optional[float] = None,
    ) -> Dict[str, float]:
        """
        Calculate equity-implied earnings.
        
        Args:
            stock_price: Current stock price
            shares_outstanding: Shares outstanding
            enterprise_value: Enterprise value (optional)
            pe_multiple: P/E multiple to use (default: self.default_pe)
            ev_ebitda_multiple: EV/EBITDA multiple (optional)
            
        Returns:
            Dict with implied earnings metrics
        """
        pe = pe_multiple or self.default_pe
        market_cap = stock_price * shares_outstanding
        
        # Implied EPS from P/E
        implied_eps = stock_price / pe if pe > 0 else 0
        
        # Implied net income
        implied_net_income = implied_eps * shares_outstanding
        
        # Implied EBITDA from EV/EBITDA (if provided)
        implied_ebitda = None
        if enterprise_value and ev_ebitda_multiple:
            implied_ebitda = enterprise_value / ev_ebitda_multiple
        
        return {
            "implied_eps": implied_eps,
            "implied_net_income": implied_net_income,
            "implied_ebitda": implied_ebitda,
            "pe_used": pe,
            "market_cap": market_cap,
        }


class REDCalculator:
    """
    Realized Earnings Delay (RED) Calculator.
    
    Models when freight market conditions will transmit into reported earnings.
    Decomposes the charter book to map out revenue timing.
    """
    
    def calculate(
        self,
        vessels: List[Dict[str, Any]],
        charters: List[Dict[str, Any]],
        calculation_date: date,
        projection_quarters: int = 8,
    ) -> Dict[str, Any]:
        """
        Calculate Realized Earnings Delay metrics.
        
        Args:
            vessels: Fleet vessels
            charters: Active charters
            calculation_date: Calculation date
            projection_quarters: Number of quarters to project
            
        Returns:
            Dict with RED metrics and quarterly breakdown
        """
        total_vessels = len([v for v in vessels if v.get("active", True)])
        if total_vessels == 0:
            return {"red_months": 0, "fleet_spot_pct": 1.0, "quarterly_breakdown": []}
        
        # Build charter lookup
        charter_by_vessel = {}
        for charter in charters:
            vessel_id = charter.get("vessel_id")
            if vessel_id:
                charter_by_vessel[vessel_id] = charter
        
        # Calculate quarterly exposure
        quarterly_breakdown = []
        
        for q in range(projection_quarters):
            quarter_start = calculation_date + timedelta(days=q * 91)
            quarter_end = quarter_start + timedelta(days=91)
            
            fixed_days = 0
            spot_days = 0
            
            for vessel in vessels:
                if not vessel.get("active", True):
                    continue
                
                vessel_id = vessel.get("id")
                charter = charter_by_vessel.get(vessel_id)
                
                if charter and charter.get("charter_type") == "time_charter":
                    charter_end = charter.get("end_date")
                    if charter_end:
                        if isinstance(charter_end, str):
                            charter_end = datetime.fromisoformat(charter_end).date()
                        
                        # Days under charter in this quarter
                        charter_days_in_quarter = max(0, min(
                            91,
                            (charter_end - quarter_start).days
                        ))
                        fixed_days += charter_days_in_quarter
                        spot_days += (91 - charter_days_in_quarter)
                    else:
                        fixed_days += 91
                else:
                    spot_days += 91
            
            total_days = fixed_days + spot_days
            spot_pct = spot_days / total_days if total_days > 0 else 1.0
            
            quarterly_breakdown.append({
                "quarter": q + 1,
                "start_date": quarter_start.isoformat(),
                "fixed_days": fixed_days,
                "spot_days": spot_days,
                "spot_pct": spot_pct,
            })
        
        # Calculate overall metrics
        current_spot_pct = quarterly_breakdown[0]["spot_pct"] if quarterly_breakdown else 1.0
        
        # Time to 50% spot exposure
        cumulative_days = 0
        for q in quarterly_breakdown:
            cumulative_days += q["spot_days"]
            if cumulative_days >= (total_vessels * 91 / 2):
                red_months = (q["quarter"] - 1) * 3 + 1.5  # Approx mid-quarter
                break
        else:
            red_months = projection_quarters * 3  # Max
        
        return {
            "red_months": red_months,
            "fleet_spot_pct": current_spot_pct,
            "quarterly_breakdown": quarterly_breakdown,
            "total_vessels": total_vessels,
        }
