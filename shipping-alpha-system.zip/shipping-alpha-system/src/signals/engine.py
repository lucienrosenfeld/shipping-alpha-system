"""
Main Signal Engine - Orchestrates all signal calculations.

This is the primary entry point for calculating trading signals.
It coordinates data fetching, signal calculation, and output generation.
"""

from dataclasses import dataclass
from datetime import date, datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
import json

from loguru import logger

from .earnings import (
    LEPCalculator,
    FEPCalculator,
    EIEPCalculator,
    REDCalculator,
    FleetEarnings,
    SignalResult,
)
from .scores import (
    INFCalculator,
    DISCalculator,
    TradeSignalGenerator,
    INFComponents,
)


@dataclass
class CompanySignals:
    """Complete signal output for a company."""
    ticker: str
    company_name: str
    segment: str
    calculation_date: date
    
    # Price info
    stock_price: float
    market_cap: float
    
    # Core signals
    lep_eps: float
    lep_ebitda: float
    fep_eps: float
    fep_ebitda: float
    eiep_eps: float
    
    inf_score: float
    inf_class: str
    inf_components: Dict[str, float]
    
    dis_score: float
    dis_class: str
    
    # RED metrics
    red_months: float
    fleet_spot_pct: float
    
    # Trade signal
    signal: str  # "BUY", "SELL", "HOLD"
    trade_type: Optional[str]
    signal_strength: float
    rationale: List[str]
    
    # Targets
    target_price: Optional[float]
    stop_loss: Optional[float]
    expected_return: Optional[float]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "ticker": self.ticker,
            "company_name": self.company_name,
            "segment": self.segment,
            "date": self.calculation_date.isoformat(),
            "stock_price": self.stock_price,
            "market_cap": self.market_cap,
            "lep_eps": self.lep_eps,
            "lep_ebitda": self.lep_ebitda,
            "fep_eps": self.fep_eps,
            "fep_ebitda": self.fep_ebitda,
            "eiep_eps": self.eiep_eps,
            "inf_score": self.inf_score,
            "inf_class": self.inf_class,
            "dis_score": self.dis_score,
            "dis_class": self.dis_class,
            "red_months": self.red_months,
            "fleet_spot_pct": self.fleet_spot_pct,
            "signal": self.signal,
            "trade_type": self.trade_type,
            "signal_strength": self.signal_strength,
            "rationale": self.rationale,
            "target_price": self.target_price,
            "stop_loss": self.stop_loss,
            "expected_return": self.expected_return,
        }


class SignalEngine:
    """
    Main signal calculation engine.
    
    Orchestrates:
    1. Data collection from API clients
    2. LEP/FEP/EIEP calculations
    3. INF/DIS scoring
    4. Trade signal generation
    5. Output formatting
    """
    
    def __init__(
        self,
        api_clients: Dict[str, Any],
        db_session: Optional[Any] = None,
    ):
        """
        Initialize signal engine.
        
        Args:
            api_clients: Dict of API client instances
            db_session: Database session (optional)
        """
        self.api = api_clients
        self.db = db_session
        
        # Initialize calculators
        self.lep_calc = LEPCalculator()
        self.fep_calc = FEPCalculator(self.lep_calc)
        self.eiep_calc = EIEPCalculator()
        self.red_calc = REDCalculator()
        self.inf_calc = INFCalculator()
        self.dis_calc = DISCalculator()
        self.signal_gen = TradeSignalGenerator(self.inf_calc, self.dis_calc)
        
        # Cache for computed data
        self._cache: Dict[str, Any] = {}
        
        logger.info("SignalEngine initialized")
    
    def calculate_company_signals(
        self,
        ticker: str,
        company_data: Dict[str, Any],
        vessels: List[Dict[str, Any]],
        charters: List[Dict[str, Any]],
        calculation_date: Optional[date] = None,
        macro_regime: str = "normal",
    ) -> CompanySignals:
        """
        Calculate all signals for a single company.
        
        Args:
            ticker: Stock ticker
            company_data: Company master data
            vessels: Fleet vessel list
            charters: Active charter contracts
            calculation_date: Date of calculation
            macro_regime: Current risk regime
            
        Returns:
            CompanySignals with all calculated metrics
        """
        calc_date = calculation_date or date.today()
        
        # Get market data
        price_data = self._get_price_data(ticker, calc_date)
        stock_price = price_data.get("close", 0)
        shares = company_data.get("shares_outstanding", 1)
        market_cap = stock_price * shares
        
        # Get freight rates
        segment = company_data.get("segment", "dry_bulk")
        spot_rates = self._get_spot_rates(segment, vessels)
        forward_curves = self._get_forward_curves(segment, vessels)
        
        # Calculate LEP
        lep_earnings = self.lep_calc.calculate(
            company_data=company_data,
            vessels=vessels,
            charters=charters,
            spot_rates=spot_rates,
            calculation_date=calc_date,
        )
        lep_eps = self.lep_calc.to_eps(lep_earnings, shares)
        lep_ebitda = lep_earnings.annualized_ebitda()
        
        # Calculate FEP
        fep_earnings = self.fep_calc.calculate(
            company_data=company_data,
            vessels=vessels,
            charters=charters,
            forward_curves=forward_curves,
            calculation_date=calc_date,
        )
        fep_eps = self.fep_calc.to_eps(fep_earnings, shares)
        fep_ebitda = fep_earnings.annualized_ebitda()
        
        # Calculate EIEP
        eiep_result = self.eiep_calc.calculate(
            stock_price=stock_price,
            shares_outstanding=shares,
            pe_multiple=company_data.get("typical_pe_multiple", 5.0),
        )
        eiep_eps = eiep_result["implied_eps"]
        
        # Calculate RED
        red_result = self.red_calc.calculate(
            vessels=vessels,
            charters=charters,
            calculation_date=calc_date,
        )
        red_months = red_result["red_months"]
        fleet_spot_pct = red_result["fleet_spot_pct"]
        
        # Get trailing/consensus for INF
        trailing_eps = self._get_trailing_eps(ticker)
        consensus_eps = self._get_consensus_eps(ticker)
        
        # Calculate INF
        inf_score, inf_components = self.inf_calc.calculate(
            projected_eps=fep_eps,
            trailing_eps=trailing_eps,
            consensus_eps=consensus_eps,
            fleet_repricing_pct=fleet_spot_pct * 100,
            quarters_until_inflection=1.0,
        )
        inf_class = self.inf_calc.classify(inf_score)
        
        # Calculate DIS
        dis_score, dis_details = self.dis_calc.calculate(
            lep=lep_eps,
            fep=fep_eps,
            eiep=eiep_eps,
        )
        dis_class = self.dis_calc.classify(dis_score)
        
        # Generate trade signal
        earnings_days = self._get_days_until_earnings(ticker)
        trade_signal = self.signal_gen.generate_signal(
            inf_score=inf_score,
            dis_score=dis_score,
            macro_regime=macro_regime,
            earnings_days_away=earnings_days,
        )
        
        # Determine signal
        if trade_signal["buy_signal"]:
            signal = "BUY"
        elif trade_signal["sell_signal"]:
            signal = "SELL"
        else:
            signal = "HOLD"
        
        # Calculate targets
        target_price = None
        expected_return = None
        if signal == "BUY" and dis_score > 0:
            # Fair value = current / (1 - DIS)
            fair_value_multiple = 1 / (1 - min(dis_score, 0.9))
            target_price = stock_price * fair_value_multiple
            expected_return = self.dis_calc.expected_return(dis_score)
        
        stop_loss = stock_price * 0.85 if signal == "BUY" else None  # 15% stop
        
        return CompanySignals(
            ticker=ticker,
            company_name=company_data.get("name", ticker),
            segment=segment,
            calculation_date=calc_date,
            stock_price=stock_price,
            market_cap=market_cap,
            lep_eps=round(lep_eps, 2),
            lep_ebitda=round(lep_ebitda, 0),
            fep_eps=round(fep_eps, 2),
            fep_ebitda=round(fep_ebitda, 0),
            eiep_eps=round(eiep_eps, 2),
            inf_score=round(inf_score, 1),
            inf_class=inf_class,
            inf_components=inf_components.to_dict(),
            dis_score=round(dis_score, 3),
            dis_class=dis_class,
            red_months=round(red_months, 1),
            fleet_spot_pct=round(fleet_spot_pct, 2),
            signal=signal,
            trade_type=trade_signal.get("trade_type"),
            signal_strength=round(trade_signal.get("signal_strength", 0), 2),
            rationale=trade_signal.get("rationale", []),
            target_price=round(target_price, 2) if target_price else None,
            stop_loss=round(stop_loss, 2) if stop_loss else None,
            expected_return=round(expected_return, 3) if expected_return else None,
        )
    
    def calculate_universe_signals(
        self,
        universe: Dict[str, List[Dict[str, Any]]],
        calculation_date: Optional[date] = None,
        macro_regime: str = "normal",
    ) -> List[CompanySignals]:
        """
        Calculate signals for entire universe of companies.
        
        Args:
            universe: Dict mapping segment to list of company configs
            calculation_date: Calculation date
            macro_regime: Risk regime
            
        Returns:
            List of CompanySignals for all companies
        """
        calc_date = calculation_date or date.today()
        results = []
        
        for segment, companies in universe.items():
            for company_config in companies:
                ticker = company_config.get("ticker")
                if not ticker:
                    continue
                
                try:
                    # Load company data (from DB or API)
                    company_data = self._load_company_data(ticker, segment)
                    vessels = self._load_vessels(ticker)
                    charters = self._load_charters(ticker)
                    
                    signals = self.calculate_company_signals(
                        ticker=ticker,
                        company_data=company_data,
                        vessels=vessels,
                        charters=charters,
                        calculation_date=calc_date,
                        macro_regime=macro_regime,
                    )
                    results.append(signals)
                    
                except Exception as e:
                    logger.error(f"Failed to calculate signals for {ticker}: {e}")
        
        # Sort by signal strength (highest first)
        results.sort(key=lambda x: x.signal_strength, reverse=True)
        
        return results
    
    def get_top_opportunities(
        self,
        signals: List[CompanySignals],
        n: int = 5,
        signal_type: str = "BUY",
    ) -> List[CompanySignals]:
        """Get top N opportunities by signal strength."""
        filtered = [s for s in signals if s.signal == signal_type]
        filtered.sort(key=lambda x: x.signal_strength, reverse=True)
        return filtered[:n]
    
    def generate_signal_report(
        self,
        signals: List[CompanySignals],
    ) -> str:
        """Generate human-readable signal report."""
        lines = [
            "=" * 80,
            f"SHIPPING EQUITY ALPHA SIGNALS - {date.today().isoformat()}",
            "=" * 80,
            "",
        ]
        
        # Summary
        buy_signals = [s for s in signals if s.signal == "BUY"]
        sell_signals = [s for s in signals if s.signal == "SELL"]
        
        lines.append(f"Total Companies: {len(signals)}")
        lines.append(f"Buy Signals: {len(buy_signals)}")
        lines.append(f"Sell Signals: {len(sell_signals)}")
        lines.append("")
        
        # Top buys
        if buy_signals:
            lines.append("-" * 40)
            lines.append("TOP BUY OPPORTUNITIES")
            lines.append("-" * 40)
            
            for s in buy_signals[:5]:
                lines.append(f"\n{s.ticker} - {s.company_name}")
                lines.append(f"  Price: ${s.stock_price:.2f}")
                lines.append(f"  LEP: ${s.lep_eps:.2f}  FEP: ${s.fep_eps:.2f}  EIEP: ${s.eiep_eps:.2f}")
                lines.append(f"  INF: {s.inf_score:.0f} ({s.inf_class})  DIS: {s.dis_score*100:.0f}% ({s.dis_class})")
                lines.append(f"  Trade Type: {s.trade_type}  Strength: {s.signal_strength:.2f}")
                if s.target_price:
                    lines.append(f"  Target: ${s.target_price:.2f}  Stop: ${s.stop_loss:.2f}")
                if s.rationale:
                    lines.append(f"  Rationale: {'; '.join(s.rationale)}")
        
        lines.append("")
        lines.append("=" * 80)
        
        return "\n".join(lines)
    
    # =========================================================================
    # Data Loading Methods (override or implement with real data sources)
    # =========================================================================
    
    def _get_price_data(self, ticker: str, as_of_date: date) -> Dict[str, Any]:
        """Get stock price data."""
        if "equity" in self.api:
            try:
                return self.api["equity"].get_price(ticker, as_of_date)
            except Exception as e:
                logger.warning(f"Failed to get price for {ticker}: {e}")
        
        # Return mock data
        return {"close": 20.0, "volume": 1000000}
    
    def _get_spot_rates(
        self,
        segment: str,
        vessels: List[Dict[str, Any]],
    ) -> Dict[str, float]:
        """Get current spot TCE rates by vessel type."""
        rates = {}
        
        # Get vessel types in fleet
        vessel_types = set(v.get("vessel_type") for v in vessels)
        
        if "baltic" in self.api:
            try:
                indices = self.api["baltic"].get_all_indices()
                
                # Map vessel types to indices
                type_to_index = {
                    "capesize": "BCI",
                    "panamax": "BPI",
                    "supramax": "BSI",
                    "handysize": "BHSI",
                }
                
                for vtype in vessel_types:
                    if vtype in type_to_index:
                        index_code = type_to_index[vtype]
                        if index_code in indices:
                            tce = self.api["baltic"].index_to_tce(
                                index_code,
                                indices[index_code].get("value", 1000)
                            )
                            if tce:
                                rates[vtype] = tce
                
            except Exception as e:
                logger.warning(f"Failed to get Baltic indices: {e}")
        
        # Fill in defaults for any missing types
        defaults = {
            "capesize": 25000,
            "panamax": 15000,
            "supramax": 12000,
            "handysize": 10000,
            "vlcc": 40000,
            "suezmax": 35000,
            "aframax": 30000,
            "mr_tanker": 20000,
        }
        
        for vtype in vessel_types:
            if vtype not in rates:
                rates[vtype] = defaults.get(vtype, 15000)
        
        return rates
    
    def _get_forward_curves(
        self,
        segment: str,
        vessels: List[Dict[str, Any]],
    ) -> Dict[str, List[Dict[str, float]]]:
        """Get FFA forward curves by vessel type."""
        curves = {}
        
        # Map vessel types to FFA routes
        type_to_route = {
            "capesize": "C5TC",
            "panamax": "P5TC",
            "supramax": "S10TC",
            "vlcc": "TD3C",
        }
        
        vessel_types = set(v.get("vessel_type") for v in vessels)
        
        if "ffa" in self.api:
            try:
                for vtype in vessel_types:
                    route = type_to_route.get(vtype)
                    if route:
                        curve_data = self.api["ffa"].get_forward_curve(route)
                        curves[vtype] = curve_data.get("curve", [])
            except Exception as e:
                logger.warning(f"Failed to get FFA curves: {e}")
        
        return curves
    
    def _get_trailing_eps(self, ticker: str) -> float:
        """Get last reported EPS (would typically come from DB or API)."""
        # Placeholder - would query financials table
        return 1.50
    
    def _get_consensus_eps(self, ticker: str) -> Optional[float]:
        """Get analyst consensus EPS estimate."""
        # Placeholder - would come from data provider
        return None
    
    def _get_days_until_earnings(self, ticker: str) -> Optional[int]:
        """Get days until next earnings announcement."""
        # Placeholder - would come from calendar API
        return 45  # Default to ~6 weeks
    
    def _load_company_data(self, ticker: str, segment: str) -> Dict[str, Any]:
        """Load company master data."""
        # Would typically load from database
        # Return mock structure for now
        return {
            "id": hash(ticker) % 1000,
            "ticker": ticker,
            "name": f"{ticker} Corp",
            "segment": segment,
            "shares_outstanding": 100_000_000,
            "annual_ga_expense": 20_000_000,
            "annual_interest_expense": 15_000_000,
            "depreciation": 30_000_000,
            "typical_pe_multiple": 5.0,
        }
    
    def _load_vessels(self, ticker: str) -> List[Dict[str, Any]]:
        """Load fleet vessels."""
        # Would typically load from database
        # Return mock fleet
        segment_vessels = {
            "SBLK": [
                {"id": 1, "vessel_type": "capesize", "daily_opex": 7000, "active": True},
                {"id": 2, "vessel_type": "capesize", "daily_opex": 7000, "active": True},
                {"id": 3, "vessel_type": "panamax", "daily_opex": 6000, "active": True},
            ],
            "GOGL": [
                {"id": 1, "vessel_type": "capesize", "daily_opex": 7500, "active": True},
                {"id": 2, "vessel_type": "capesize", "daily_opex": 7500, "active": True},
            ],
        }
        return segment_vessels.get(ticker, [
            {"id": 1, "vessel_type": "panamax", "daily_opex": 6000, "active": True}
        ])
    
    def _load_charters(self, ticker: str) -> List[Dict[str, Any]]:
        """Load active charter contracts."""
        # Would typically load from database
        return []
