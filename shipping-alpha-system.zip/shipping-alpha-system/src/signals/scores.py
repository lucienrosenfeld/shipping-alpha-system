"""
Inflection Score (INF) and Disbelief Score (DIS) calculators.

INF: Measures imminence and magnitude of earnings inflection points
DIS: Measures market underpricing relative to fundamental earning power
"""

from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Dict, List, Optional, Any, Tuple
import math

from loguru import logger


@dataclass
class INFComponents:
    """Breakdown of INF score components."""
    earnings_change_score: float = 0  # vs trailing earnings
    fleet_repricing_score: float = 0  # charter roll-off impact
    consensus_surprise_score: float = 0  # vs analyst estimates
    breakeven_crossing_score: float = 0  # negative to positive
    timing_factor: float = 1.0  # decay for distant catalysts
    
    def total(self, weights: Dict[str, float]) -> float:
        """Calculate weighted total INF score."""
        raw_score = (
            self.earnings_change_score * weights.get("earnings_change", 0.35) +
            self.fleet_repricing_score * weights.get("fleet_repricing", 0.25) +
            self.consensus_surprise_score * weights.get("consensus_surprise", 0.25) +
            self.breakeven_crossing_score * weights.get("breakeven_crossing", 0.15)
        )
        return raw_score * self.timing_factor
    
    def to_dict(self) -> Dict[str, float]:
        return {
            "earnings_change": self.earnings_change_score,
            "fleet_repricing": self.fleet_repricing_score,
            "consensus_surprise": self.consensus_surprise_score,
            "breakeven_crossing": self.breakeven_crossing_score,
            "timing_factor": self.timing_factor,
        }


class INFCalculator:
    """
    Inflection Score (INF) Calculator.
    
    Measures the imminence and magnitude of a major earnings inflection point.
    High INF indicates a company's earnings trajectory is about to pivot sharply.
    
    Components:
    1. Earnings Change: Projected vs trailing earnings
    2. Fleet Repricing: Charter roll-off impact
    3. Consensus Surprise: Projected vs analyst estimates
    4. Breakeven Crossing: Transition from loss to profit
    """
    
    DEFAULT_WEIGHTS = {
        "earnings_change": 0.35,
        "fleet_repricing": 0.25,
        "consensus_surprise": 0.25,
        "breakeven_crossing": 0.15,
    }
    
    def __init__(
        self,
        weights: Optional[Dict[str, float]] = None,
        high_threshold: float = 70.0,
        medium_threshold: float = 40.0,
    ):
        self.weights = weights or self.DEFAULT_WEIGHTS
        self.high_threshold = high_threshold
        self.medium_threshold = medium_threshold
    
    def calculate(
        self,
        projected_eps: float,
        trailing_eps: float,
        consensus_eps: Optional[float],
        fleet_repricing_pct: float,  # % of fleet repricing in next 6 months
        quarters_until_inflection: float = 1.0,
    ) -> Tuple[float, INFComponents]:
        """
        Calculate INF score.
        
        Args:
            projected_eps: Our projected next quarter EPS
            trailing_eps: Last quarter actual EPS
            consensus_eps: Analyst consensus EPS (if available)
            fleet_repricing_pct: Percentage of fleet repricing soon
            quarters_until_inflection: Timing of expected inflection
            
        Returns:
            Tuple of (INF score 0-100, components breakdown)
        """
        components = INFComponents()
        
        # 1. Earnings Change Score (0-35 base)
        if trailing_eps != 0:
            eps_change_pct = (projected_eps - trailing_eps) / abs(trailing_eps)
        elif projected_eps > 0:
            eps_change_pct = 5.0  # Massive improvement from zero
        else:
            eps_change_pct = 0
        
        # Scale: 100% change = 50 points, capped at 100
        components.earnings_change_score = min(100, max(-100, eps_change_pct * 50))
        
        # 2. Fleet Repricing Score (0-25 base)
        # More repricing = more potential for earnings jump
        # 50%+ repricing = max score
        components.fleet_repricing_score = min(100, fleet_repricing_pct * 2)
        
        # 3. Consensus Surprise Score (0-25 base)
        if consensus_eps and consensus_eps != 0:
            surprise_pct = (projected_eps - consensus_eps) / abs(consensus_eps)
            # 50% beat = 50 points, capped at 100
            components.consensus_surprise_score = min(100, max(-100, surprise_pct * 100))
        else:
            components.consensus_surprise_score = 0
        
        # 4. Breakeven Crossing Score (0-15 base)
        if trailing_eps <= 0 and projected_eps > 0:
            # Going from loss to profit - major inflection
            components.breakeven_crossing_score = 100
        elif trailing_eps > 0 and projected_eps <= 0:
            # Going from profit to loss - negative inflection
            components.breakeven_crossing_score = -50
        else:
            components.breakeven_crossing_score = 0
        
        # 5. Timing Factor (decay for distant catalysts)
        # Full weight if < 1 quarter, decays to 0.5 at 4 quarters
        if quarters_until_inflection <= 1:
            components.timing_factor = 1.0
        elif quarters_until_inflection >= 4:
            components.timing_factor = 0.5
        else:
            components.timing_factor = 1.0 - (quarters_until_inflection - 1) * (0.5 / 3)
        
        # Calculate total score
        total_score = components.total(self.weights)
        
        # Normalize to 0-100 scale
        # Raw score can range from about -100 to +100
        normalized_score = (total_score + 100) / 2
        normalized_score = max(0, min(100, normalized_score))
        
        return normalized_score, components
    
    def classify(self, inf_score: float) -> str:
        """Classify INF score level."""
        if inf_score >= self.high_threshold:
            return "HIGH"
        elif inf_score >= self.medium_threshold:
            return "MEDIUM"
        else:
            return "LOW"


class DISCalculator:
    """
    Disbelief Score (DIS) Calculator.
    
    Measures the degree of mispricing between fundamental earning power
    and stock valuation. High DIS indicates market "disbelief" in earnings.
    
    Formula: DIS = (FEP - EIEP) / FEP
    
    Where:
    - FEP: Forward Earnings Power (what the company should earn)
    - EIEP: Equity-Implied Earnings Power (what the market prices in)
    """
    
    def __init__(
        self,
        high_threshold: float = 0.40,  # 40% undervaluation
        medium_threshold: float = 0.20,  # 20% undervaluation
        lep_weight: float = 0.3,  # Weight for current LEP vs FEP
    ):
        self.high_threshold = high_threshold
        self.medium_threshold = medium_threshold
        self.lep_weight = lep_weight
    
    def calculate(
        self,
        lep: float,
        fep: float,
        eiep: float,
        use_blended: bool = True,
    ) -> Tuple[float, Dict[str, Any]]:
        """
        Calculate DIS score.
        
        Args:
            lep: Live Earnings Power (EPS)
            fep: Forward Earnings Power (EPS)
            eiep: Equity-Implied Earnings Power (EPS)
            use_blended: Whether to blend LEP and FEP
            
        Returns:
            Tuple of (DIS score, calculation details)
        """
        if use_blended:
            # Weighted blend of LEP and FEP
            fundamental_eps = self.lep_weight * lep + (1 - self.lep_weight) * fep
        else:
            fundamental_eps = fep
        
        # Handle edge cases
        if fundamental_eps <= 0:
            # Can't calculate meaningful DIS if expected earnings are zero/negative
            return 0, {
                "fundamental_eps": fundamental_eps,
                "eiep": eiep,
                "gap": 0,
                "note": "Non-positive fundamental earnings"
            }
        
        # DIS = (Fundamental - Implied) / Fundamental
        dis_score = (fundamental_eps - eiep) / fundamental_eps
        
        # Gap in dollar terms
        earnings_gap = fundamental_eps - eiep
        
        details = {
            "fundamental_eps": fundamental_eps,
            "eiep": eiep,
            "lep": lep,
            "fep": fep,
            "earnings_gap": earnings_gap,
            "dis_ratio": dis_score,
            "undervalued": dis_score > 0,
            "overvalued": dis_score < 0,
        }
        
        return dis_score, details
    
    def classify(self, dis_score: float) -> str:
        """Classify DIS score level."""
        if dis_score >= self.high_threshold:
            return "HIGH_UNDERVALUED"
        elif dis_score >= self.medium_threshold:
            return "MODERATE_UNDERVALUED"
        elif dis_score > -self.medium_threshold:
            return "FAIRLY_VALUED"
        elif dis_score > -self.high_threshold:
            return "MODERATE_OVERVALUED"
        else:
            return "HIGH_OVERVALUED"
    
    def expected_return(self, dis_score: float, convergence_periods: int = 4) -> float:
        """
        Estimate expected return if mispricing corrects.
        
        Args:
            dis_score: DIS score (e.g., 0.4 = 40% undervalued)
            convergence_periods: Expected quarters to converge
            
        Returns:
            Expected annualized return
        """
        if dis_score <= 0:
            return 0
        
        # If stock is 40% undervalued, fair value is 1/(1-0.4) = 1.67x current
        fair_value_multiple = 1 / (1 - dis_score) if dis_score < 1 else 10
        
        # Total expected return
        total_return = fair_value_multiple - 1
        
        # Annualize based on convergence time
        years_to_converge = convergence_periods / 4
        if years_to_converge > 0 and total_return > -1:
            annualized = (1 + total_return) ** (1 / years_to_converge) - 1
        else:
            annualized = total_return
        
        return annualized


class TradeSignalGenerator:
    """
    Generate trade signals from INF and DIS scores.
    
    Trade Types:
    1. Earnings Surprise: High INF + Moderate DIS, short-term catalyst
    2. Re-Rating: High DIS + Any INF, medium-term value
    """
    
    def __init__(
        self,
        inf_calculator: INFCalculator,
        dis_calculator: DISCalculator,
    ):
        self.inf_calc = inf_calculator
        self.dis_calc = dis_calculator
    
    def generate_signal(
        self,
        inf_score: float,
        dis_score: float,
        macro_regime: str = "normal",  # "normal", "caution", "risk_off"
        earnings_days_away: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Generate trade signal from scores.
        
        Args:
            inf_score: INF score (0-100)
            dis_score: DIS score (ratio, e.g., 0.4)
            macro_regime: Current risk regime
            earnings_days_away: Days until next earnings
            
        Returns:
            Trade signal with type and strength
        """
        signal = {
            "buy_signal": False,
            "sell_signal": False,
            "trade_type": None,
            "signal_strength": 0,
            "rationale": [],
        }
        
        # Risk regime adjustments
        regime_multiplier = {
            "normal": 1.0,
            "caution": 0.7,
            "risk_off": 0.3,
        }.get(macro_regime, 1.0)
        
        # Classify scores
        inf_class = self.inf_calc.classify(inf_score)
        dis_class = self.dis_calc.classify(dis_score)
        
        # Earnings Surprise Trade
        # High INF + Not Overvalued + Near Earnings
        if inf_class == "HIGH" and dis_score > 0:
            if earnings_days_away is not None and earnings_days_away <= 60:
                signal["buy_signal"] = True
                signal["trade_type"] = "earnings_surprise"
                signal["signal_strength"] = min(1.0, (inf_score / 100) * (1 + dis_score)) * regime_multiplier
                signal["rationale"].append(f"High INF ({inf_score:.0f}) with earnings in {earnings_days_away} days")
                signal["rationale"].append(f"Stock appears {dis_score*100:.0f}% undervalued")
        
        # Re-Rating Trade
        # High DIS (regardless of INF)
        if dis_class in ["HIGH_UNDERVALUED", "MODERATE_UNDERVALUED"] and dis_score >= 0.25:
            signal["buy_signal"] = True
            if signal["trade_type"] != "earnings_surprise":
                signal["trade_type"] = "re_rating"
            signal["signal_strength"] = max(
                signal["signal_strength"],
                min(1.0, dis_score * 1.5) * regime_multiplier
            )
            signal["rationale"].append(f"High DIS - stock {dis_score*100:.0f}% below fundamental value")
        
        # Sell/Avoid Signal
        # Overvalued (negative DIS)
        if dis_class in ["HIGH_OVERVALUED", "MODERATE_OVERVALUED"]:
            signal["sell_signal"] = True
            signal["trade_type"] = "overvalued"
            signal["signal_strength"] = min(1.0, abs(dis_score) * 1.5)
            signal["rationale"].append(f"Stock appears {abs(dis_score)*100:.0f}% overvalued")
        
        # Negative INF (earnings collapse expected)
        if inf_score < 30 and inf_class == "LOW":
            # Check if this is actually negative inflection
            signal["rationale"].append("Low/negative INF - earnings pressure expected")
            if dis_score < 0:
                signal["sell_signal"] = True
                signal["signal_strength"] = max(signal["signal_strength"], 0.5)
        
        # No signal if regime is risk_off
        if macro_regime == "risk_off":
            signal["buy_signal"] = False
            signal["rationale"].append("Risk-off regime - no new longs")
        
        return signal
    
    def generate_exit_signal(
        self,
        entry_dis: float,
        current_dis: float,
        entry_price: float,
        current_price: float,
        holding_days: int,
        trade_type: str,
    ) -> Dict[str, Any]:
        """
        Generate exit signal for existing position.
        
        Args:
            entry_dis: DIS score at entry
            current_dis: Current DIS score
            entry_price: Entry price
            current_price: Current price
            holding_days: Days held
            trade_type: Original trade type
            
        Returns:
            Exit signal details
        """
        price_return = (current_price - entry_price) / entry_price
        dis_reduction = entry_dis - current_dis  # Gap closure
        
        exit_signal = {
            "exit_recommended": False,
            "exit_reason": None,
            "urgency": "low",
        }
        
        if trade_type == "earnings_surprise":
            # Exit after earnings catalyst or if gain target hit
            if holding_days > 90:  # Past typical catalyst window
                exit_signal["exit_recommended"] = True
                exit_signal["exit_reason"] = "Past catalyst window"
                exit_signal["urgency"] = "medium"
            elif price_return >= 0.20:  # 20% gain
                exit_signal["exit_recommended"] = True
                exit_signal["exit_reason"] = "Target gain achieved"
                exit_signal["urgency"] = "low"
        
        elif trade_type == "re_rating":
            # Exit when valuation gap closes
            if current_dis <= 0.10:  # Gap mostly closed
                exit_signal["exit_recommended"] = True
                exit_signal["exit_reason"] = "Valuation gap closed"
                exit_signal["urgency"] = "medium"
            elif price_return >= 0.50:  # 50% gain
                exit_signal["exit_recommended"] = True
                exit_signal["exit_reason"] = "Strong gain - consider profit taking"
                exit_signal["urgency"] = "low"
            elif holding_days > 365:  # Over a year
                exit_signal["exit_recommended"] = True
                exit_signal["exit_reason"] = "Extended holding period"
                exit_signal["urgency"] = "low"
        
        # Stop loss check
        if price_return <= -0.15:  # 15% loss
            exit_signal["exit_recommended"] = True
            exit_signal["exit_reason"] = "Stop loss triggered"
            exit_signal["urgency"] = "high"
        
        # DIS turned negative (now overvalued)
        if current_dis < -0.10:
            exit_signal["exit_recommended"] = True
            exit_signal["exit_reason"] = "Stock now appears overvalued"
            exit_signal["urgency"] = "high"
        
        return exit_signal
