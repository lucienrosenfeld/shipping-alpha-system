"""
Signal calculation module.

Core signals for the Shipping Equity Alpha System:
- LEP: Live Earnings Power
- FEP: Forward Earnings Power  
- EIEP: Equity-Implied Earnings Power
- INF: Inflection Score
- DIS: Disbelief Score
- RED: Realized Earnings Delay
"""

from .earnings import (
    VesselEarnings,
    FleetEarnings,
    SignalResult,
    LEPCalculator,
    FEPCalculator,
    EIEPCalculator,
    REDCalculator,
)

from .scores import (
    INFComponents,
    INFCalculator,
    DISCalculator,
    TradeSignalGenerator,
)

from .engine import (
    CompanySignals,
    SignalEngine,
)

__all__ = [
    # Data classes
    "VesselEarnings",
    "FleetEarnings",
    "SignalResult",
    "INFComponents",
    
    # Calculators
    "LEPCalculator",
    "FEPCalculator",
    "EIEPCalculator",
    "REDCalculator",
    "INFCalculator",
    "DISCalculator",
    "TradeSignalGenerator",
    
    # Engine
    "CompanySignals",
    "SignalEngine",
]
