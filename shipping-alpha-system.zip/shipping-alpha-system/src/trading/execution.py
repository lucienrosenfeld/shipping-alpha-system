"""
Trade execution and portfolio management module.

Handles:
- Trade execution (paper and live)
- Portfolio tracking
- P&L calculation
- Trade journaling
"""

from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from enum import Enum
import json

from loguru import logger
from sqlalchemy.orm import Session

from ..models import Trade, Portfolio, Alert, TradeStatus, TradeType


@dataclass
class TradeOrder:
    """Trade order specification."""
    ticker: str
    side: str  # "buy" or "sell"
    quantity: int
    order_type: str = "market"  # "market", "limit", "stop"
    limit_price: Optional[float] = None
    stop_price: Optional[float] = None
    
    # Metadata
    trade_type: str = "earnings_surprise"  # or "re_rating"
    thesis: str = ""
    entry_signals: Dict[str, float] = field(default_factory=dict)


@dataclass
class ExecutedTrade:
    """Executed trade details."""
    order: TradeOrder
    execution_price: float
    execution_time: datetime
    commission: float = 0
    status: str = "filled"
    
    @property
    def total_cost(self) -> float:
        return self.order.quantity * self.execution_price + self.commission


@dataclass
class Position:
    """Current position in a stock."""
    ticker: str
    shares: int
    avg_cost: float
    current_price: float
    
    # Entry details
    entry_date: date
    trade_type: str
    
    # Risk management
    stop_loss: float
    target_price: Optional[float] = None
    trailing_stop: Optional[float] = None
    highest_price: float = 0
    
    # Signal at entry
    entry_lep: float = 0
    entry_fep: float = 0
    entry_eiep: float = 0
    entry_inf: float = 0
    entry_dis: float = 0
    
    @property
    def market_value(self) -> float:
        return self.shares * self.current_price
    
    @property
    def cost_basis(self) -> float:
        return self.shares * self.avg_cost
    
    @property
    def unrealized_pnl(self) -> float:
        return self.market_value - self.cost_basis
    
    @property
    def unrealized_pnl_pct(self) -> float:
        return self.unrealized_pnl / self.cost_basis if self.cost_basis > 0 else 0
    
    @property
    def holding_days(self) -> int:
        return (date.today() - self.entry_date).days
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "ticker": self.ticker,
            "shares": self.shares,
            "avg_cost": self.avg_cost,
            "current_price": self.current_price,
            "market_value": self.market_value,
            "unrealized_pnl": self.unrealized_pnl,
            "unrealized_pnl_pct": self.unrealized_pnl_pct,
            "entry_date": self.entry_date.isoformat(),
            "holding_days": self.holding_days,
            "trade_type": self.trade_type,
            "stop_loss": self.stop_loss,
        }


class PaperBroker:
    """
    Paper trading broker for testing and simulation.
    
    Simulates order execution without real money.
    """
    
    def __init__(
        self,
        slippage_pct: float = 0.001,  # 0.1% slippage
        commission_per_share: float = 0.005,  # $0.005/share
        min_commission: float = 1.0,
    ):
        self.slippage_pct = slippage_pct
        self.commission_per_share = commission_per_share
        self.min_commission = min_commission
    
    def execute_order(
        self,
        order: TradeOrder,
        current_price: float,
    ) -> ExecutedTrade:
        """
        Execute a paper trade.
        
        Args:
            order: Trade order
            current_price: Current market price
            
        Returns:
            Executed trade details
        """
        # Apply slippage
        if order.side == "buy":
            execution_price = current_price * (1 + self.slippage_pct)
        else:
            execution_price = current_price * (1 - self.slippage_pct)
        
        # Handle limit orders
        if order.order_type == "limit" and order.limit_price:
            if order.side == "buy" and current_price > order.limit_price:
                return ExecutedTrade(
                    order=order,
                    execution_price=0,
                    execution_time=datetime.now(),
                    status="rejected_limit"
                )
            elif order.side == "sell" and current_price < order.limit_price:
                return ExecutedTrade(
                    order=order,
                    execution_price=0,
                    execution_time=datetime.now(),
                    status="rejected_limit"
                )
            execution_price = order.limit_price
        
        # Calculate commission
        commission = max(
            self.min_commission,
            order.quantity * self.commission_per_share
        )
        
        return ExecutedTrade(
            order=order,
            execution_price=round(execution_price, 2),
            execution_time=datetime.now(),
            commission=commission,
            status="filled"
        )


class LiveBroker:
    """
    Live trading broker interface.
    
    Placeholder for integration with real brokers like:
    - Interactive Brokers
    - Alpaca
    - TD Ameritrade
    """
    
    def __init__(self, api_key: str = None, api_secret: str = None, base_url: str = None):
        self.api_key = api_key or "PLACEHOLDER_BROKER_API_KEY"
        self.api_secret = api_secret or "PLACEHOLDER_BROKER_SECRET"
        self.base_url = base_url or "https://api.broker.example.com"
        
        logger.warning("LiveBroker initialized with placeholder credentials")
    
    def execute_order(
        self,
        order: TradeOrder,
        current_price: float,
    ) -> ExecutedTrade:
        """
        Execute a live trade.
        
        This is a placeholder that would integrate with a real broker API.
        """
        # Placeholder implementation
        if self.api_key.startswith("PLACEHOLDER"):
            logger.warning("Cannot execute live order with placeholder API key")
            raise ValueError("Live trading requires valid broker API credentials")
        
        # TODO: Implement actual broker API integration
        # Example for Alpaca:
        # response = self.alpaca_client.submit_order(
        #     symbol=order.ticker,
        #     qty=order.quantity,
        #     side=order.side,
        #     type=order.order_type,
        #     time_in_force='day'
        # )
        
        raise NotImplementedError("Live broker integration not yet implemented")
    
    def get_account(self) -> Dict[str, Any]:
        """Get account information."""
        raise NotImplementedError("Live broker integration not yet implemented")
    
    def get_positions(self) -> List[Dict[str, Any]]:
        """Get current positions."""
        raise NotImplementedError("Live broker integration not yet implemented")


class PortfolioManager:
    """
    Portfolio management and tracking.
    """
    
    def __init__(
        self,
        session: Session,
        broker: PaperBroker = None,
        initial_cash: float = 100000,
    ):
        self.session = session
        self.broker = broker or PaperBroker()
        self.cash = initial_cash
        self.positions: Dict[str, Position] = {}
        self.trade_history: List[ExecutedTrade] = []
    
    @property
    def total_value(self) -> float:
        """Total portfolio value (cash + positions)."""
        positions_value = sum(p.market_value for p in self.positions.values())
        return self.cash + positions_value
    
    @property
    def total_invested(self) -> float:
        """Total invested in positions."""
        return sum(p.market_value for p in self.positions.values())
    
    @property
    def total_pnl(self) -> float:
        """Total unrealized P&L."""
        return sum(p.unrealized_pnl for p in self.positions.values())
    
    def open_position(
        self,
        order: TradeOrder,
        current_price: float,
    ) -> Tuple[bool, str]:
        """
        Open a new position.
        
        Args:
            order: Trade order
            current_price: Current stock price
            
        Returns:
            Tuple of (success, message)
        """
        # Validate order
        if order.side != "buy":
            return False, "Open position requires buy order"
        
        if order.ticker in self.positions:
            return False, f"Position already exists for {order.ticker}"
        
        # Check cash
        estimated_cost = order.quantity * current_price * 1.01  # 1% buffer
        if estimated_cost > self.cash:
            return False, f"Insufficient cash. Need ${estimated_cost:.2f}, have ${self.cash:.2f}"
        
        # Execute order
        execution = self.broker.execute_order(order, current_price)
        
        if execution.status != "filled":
            return False, f"Order not filled: {execution.status}"
        
        # Update cash
        self.cash -= execution.total_cost
        
        # Create position
        position = Position(
            ticker=order.ticker,
            shares=order.quantity,
            avg_cost=execution.execution_price,
            current_price=execution.execution_price,
            entry_date=date.today(),
            trade_type=order.trade_type,
            stop_loss=execution.execution_price * 0.85,  # Default 15% stop
            highest_price=execution.execution_price,
            entry_lep=order.entry_signals.get("lep", 0),
            entry_fep=order.entry_signals.get("fep", 0),
            entry_eiep=order.entry_signals.get("eiep", 0),
            entry_inf=order.entry_signals.get("inf", 0),
            entry_dis=order.entry_signals.get("dis", 0),
        )
        
        self.positions[order.ticker] = position
        self.trade_history.append(execution)
        
        # Save to database
        self._save_trade(execution, position)
        
        logger.info(f"Opened position: {order.quantity} {order.ticker} @ ${execution.execution_price:.2f}")
        
        return True, f"Position opened: {order.quantity} shares @ ${execution.execution_price:.2f}"
    
    def close_position(
        self,
        ticker: str,
        current_price: float,
        reason: str = "manual",
    ) -> Tuple[bool, str, float]:
        """
        Close an existing position.
        
        Args:
            ticker: Stock ticker
            current_price: Current stock price
            reason: Reason for closing
            
        Returns:
            Tuple of (success, message, realized_pnl)
        """
        if ticker not in self.positions:
            return False, f"No position in {ticker}", 0
        
        position = self.positions[ticker]
        
        # Create sell order
        order = TradeOrder(
            ticker=ticker,
            side="sell",
            quantity=position.shares,
            order_type="market",
            trade_type=position.trade_type,
        )
        
        # Execute order
        execution = self.broker.execute_order(order, current_price)
        
        if execution.status != "filled":
            return False, f"Sell order not filled: {execution.status}", 0
        
        # Calculate P&L
        proceeds = execution.execution_price * position.shares - execution.commission
        realized_pnl = proceeds - position.cost_basis
        realized_pnl_pct = realized_pnl / position.cost_basis
        
        # Update cash
        self.cash += proceeds
        
        # Update trade record in database
        self._update_trade_close(ticker, execution, realized_pnl, reason)
        
        # Remove position
        del self.positions[ticker]
        self.trade_history.append(execution)
        
        logger.info(f"Closed position: {ticker} @ ${execution.execution_price:.2f}, P&L: ${realized_pnl:.2f} ({realized_pnl_pct:.1%})")
        
        return True, f"Position closed. P&L: ${realized_pnl:.2f} ({realized_pnl_pct:.1%})", realized_pnl
    
    def update_prices(self, prices: Dict[str, float]):
        """
        Update position prices.
        
        Args:
            prices: Dict mapping ticker to current price
        """
        for ticker, price in prices.items():
            if ticker in self.positions:
                position = self.positions[ticker]
                position.current_price = price
                position.highest_price = max(position.highest_price, price)
    
    def check_stops(self, prices: Dict[str, float]) -> List[Dict[str, Any]]:
        """
        Check if any positions have hit stop loss.
        
        Args:
            prices: Current prices
            
        Returns:
            List of triggered stops
        """
        triggered = []
        
        for ticker, position in list(self.positions.items()):
            current_price = prices.get(ticker, position.current_price)
            
            # Check fixed stop
            if current_price <= position.stop_loss:
                triggered.append({
                    "ticker": ticker,
                    "type": "stop_loss",
                    "trigger_price": position.stop_loss,
                    "current_price": current_price,
                })
            
            # Check trailing stop
            elif position.trailing_stop and current_price <= position.trailing_stop:
                triggered.append({
                    "ticker": ticker,
                    "type": "trailing_stop",
                    "trigger_price": position.trailing_stop,
                    "current_price": current_price,
                })
        
        return triggered
    
    def get_sector_exposure(self, sector_mapping: Dict[str, str]) -> Dict[str, float]:
        """
        Calculate exposure by sector.
        
        Args:
            sector_mapping: Dict mapping ticker to sector
            
        Returns:
            Dict of sector to exposure percentage
        """
        exposures: Dict[str, float] = {}
        
        for ticker, position in self.positions.items():
            sector = sector_mapping.get(ticker, "unknown")
            exposure = position.market_value / self.total_value
            exposures[sector] = exposures.get(sector, 0) + exposure
        
        return exposures
    
    def get_portfolio_snapshot(self) -> Dict[str, Any]:
        """Get current portfolio snapshot."""
        return {
            "date": date.today().isoformat(),
            "total_value": self.total_value,
            "cash": self.cash,
            "invested": self.total_invested,
            "unrealized_pnl": self.total_pnl,
            "position_count": len(self.positions),
            "positions": [p.to_dict() for p in self.positions.values()],
        }
    
    def _save_trade(self, execution: ExecutedTrade, position: Position):
        """Save trade to database."""
        trade = Trade(
            company_id=0,  # Would need company lookup
            trade_type=TradeType(position.trade_type) if position.trade_type in [t.value for t in TradeType] else TradeType.EARNINGS_SURPRISE,
            status=TradeStatus.OPEN,
            entry_date=date.today(),
            entry_price=execution.execution_price,
            shares=position.shares,
            position_value=position.market_value,
            stop_loss=position.stop_loss,
            entry_lep=position.entry_lep,
            entry_fep=position.entry_fep,
            entry_eiep=position.entry_eiep,
            entry_inf=position.entry_inf,
            entry_dis=position.entry_dis,
            thesis=execution.order.thesis,
        )
        self.session.add(trade)
        self.session.commit()
    
    def _update_trade_close(
        self,
        ticker: str,
        execution: ExecutedTrade,
        realized_pnl: float,
        reason: str,
    ):
        """Update trade record on close."""
        # Find open trade
        trade = self.session.query(Trade).filter(
            Trade.status == TradeStatus.OPEN
        ).order_by(Trade.id.desc()).first()
        
        if trade:
            trade.status = TradeStatus.CLOSED
            trade.exit_date = date.today()
            trade.exit_price = execution.execution_price
            trade.exit_reason = reason
            trade.realized_pnl = realized_pnl
            position = self.positions.get(ticker)
            if position:
                trade.realized_pnl_pct = realized_pnl / position.cost_basis
                trade.holding_days = (date.today() - position.entry_date).days
            self.session.commit()


class TradeJournal:
    """
    Trade journaling and analysis.
    """
    
    def __init__(self, session: Session):
        self.session = session
    
    def get_trade_stats(self) -> Dict[str, Any]:
        """Get overall trade statistics."""
        trades = self.session.query(Trade).filter(
            Trade.status == TradeStatus.CLOSED
        ).all()
        
        if not trades:
            return {"total_trades": 0}
        
        wins = [t for t in trades if t.realized_pnl and t.realized_pnl > 0]
        losses = [t for t in trades if t.realized_pnl and t.realized_pnl <= 0]
        
        total_profit = sum(t.realized_pnl for t in wins if t.realized_pnl)
        total_loss = abs(sum(t.realized_pnl for t in losses if t.realized_pnl))
        
        return {
            "total_trades": len(trades),
            "winning_trades": len(wins),
            "losing_trades": len(losses),
            "win_rate": len(wins) / len(trades) if trades else 0,
            "total_profit": total_profit,
            "total_loss": total_loss,
            "net_pnl": total_profit - total_loss,
            "profit_factor": total_profit / total_loss if total_loss > 0 else float('inf'),
            "avg_win": total_profit / len(wins) if wins else 0,
            "avg_loss": total_loss / len(losses) if losses else 0,
        }
    
    def get_trade_stats_by_type(self) -> Dict[str, Dict[str, Any]]:
        """Get statistics broken down by trade type."""
        stats = {}
        
        for trade_type in TradeType:
            trades = self.session.query(Trade).filter(
                Trade.status == TradeStatus.CLOSED,
                Trade.trade_type == trade_type
            ).all()
            
            if trades:
                wins = [t for t in trades if t.realized_pnl and t.realized_pnl > 0]
                stats[trade_type.value] = {
                    "count": len(trades),
                    "win_rate": len(wins) / len(trades),
                    "total_pnl": sum(t.realized_pnl for t in trades if t.realized_pnl),
                }
        
        return stats
    
    def analyze_signal_effectiveness(self) -> Dict[str, Any]:
        """Analyze how well signals predicted outcomes."""
        trades = self.session.query(Trade).filter(
            Trade.status == TradeStatus.CLOSED
        ).all()
        
        if not trades:
            return {}
        
        # Group by DIS score quintile
        dis_groups = {"low": [], "medium": [], "high": []}
        inf_groups = {"low": [], "medium": [], "high": []}
        
        for trade in trades:
            if trade.entry_dis and trade.realized_pnl_pct:
                if trade.entry_dis < 0.2:
                    dis_groups["low"].append(trade.realized_pnl_pct)
                elif trade.entry_dis < 0.4:
                    dis_groups["medium"].append(trade.realized_pnl_pct)
                else:
                    dis_groups["high"].append(trade.realized_pnl_pct)
            
            if trade.entry_inf and trade.realized_pnl_pct:
                if trade.entry_inf < 40:
                    inf_groups["low"].append(trade.realized_pnl_pct)
                elif trade.entry_inf < 70:
                    inf_groups["medium"].append(trade.realized_pnl_pct)
                else:
                    inf_groups["high"].append(trade.realized_pnl_pct)
        
        return {
            "dis_effectiveness": {
                group: {
                    "avg_return": sum(returns) / len(returns) if returns else 0,
                    "count": len(returns),
                }
                for group, returns in dis_groups.items()
            },
            "inf_effectiveness": {
                group: {
                    "avg_return": sum(returns) / len(returns) if returns else 0,
                    "count": len(returns),
                }
                for group, returns in inf_groups.items()
            },
        }
