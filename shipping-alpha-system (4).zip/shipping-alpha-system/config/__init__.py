"""Configuration module."""

from .settings import (
    settings,
    Settings,
    SignalParameters,
    SHIPPING_UNIVERSE,
    FREIGHT_INDEX_MAPPING,
    VESSEL_INDEX_MAPPING,
)

__all__ = [
    "settings",
    "Settings",
    "SignalParameters",
    "SHIPPING_UNIVERSE",
    "FREIGHT_INDEX_MAPPING",
    "VESSEL_INDEX_MAPPING",
]
