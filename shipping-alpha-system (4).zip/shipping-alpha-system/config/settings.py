"""
Configuration settings for the Shipping Equity Alpha System.
Uses Pydantic for validation and environment variable loading.
"""

from typing import Optional
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class DatabaseSettings(BaseSettings):
    """Database configuration."""
    model_config = SettingsConfigDict(env_prefix="", extra="ignore")
    
    database_url: str = Field(
        default="sqlite:///./shipping_alpha.db",
        alias="DATABASE_URL"
    )


class BalticExchangeSettings(BaseSettings):
    """Baltic Exchange API configuration."""
    model_config = SettingsConfigDict(env_prefix="BALTIC_EXCHANGE_", extra="ignore")
    
    api_key: str = Field(default="PLACEHOLDER_BALTIC_API_KEY")
    base_url: str = Field(default="https://api.balticexchange.com/v1")


class FFABrokerSettings(BaseSettings):
    """FFA Broker API configuration."""
    model_config = SettingsConfigDict(env_prefix="FFA_BROKER_", extra="ignore")
    
    api_key: str = Field(default="PLACEHOLDER_FFA_API_KEY")
    base_url: str = Field(default="https://api.ffabroker.example.com/v1")


class BunkerSettings(BaseSettings):
    """Bunker fuel price API configuration."""
    model_config = SettingsConfigDict(env_prefix="SHIP_BUNKER_", extra="ignore")
    
    api_key: str = Field(default="PLACEHOLDER_BUNKER_API_KEY")


class EquityDataSettings(BaseSettings):
    """Equity market data configuration."""
    model_config = SettingsConfigDict(env_prefix="", extra="ignore")
    
    alpha_vantage_api_key: str = Field(
        default="PLACEHOLDER_ALPHA_VANTAGE_KEY",
        alias="ALPHA_VANTAGE_API_KEY"
    )
    polygon_api_key: Optional[str] = Field(
        default=None,
        alias="POLYGON_API_KEY"
    )


class MacroDataSettings(BaseSettings):
    """Macro economic data configuration."""
    model_config = SettingsConfigDict(env_prefix="", extra="ignore")
    
    fred_api_key: str = Field(
        default="PLACEHOLDER_FRED_API_KEY",
        alias="FRED_API_KEY"
    )


class BrokerSettings(BaseSettings):
    """Trading broker configuration."""
    model_config = SettingsConfigDict(env_prefix="", extra="ignore")
    
    # Interactive Brokers
    ib_host: str = Field(default="127.0.0.1", alias="IB_HOST")
    ib_port: int = Field(default=7497, alias="IB_PORT")
    ib_client_id: int = Field(default=1, alias="IB_CLIENT_ID")
    
    # Alpaca
    alpaca_api_key: Optional[str] = Field(default=None, alias="ALPACA_API_KEY")
    alpaca_secret_key: Optional[str] = Field(default=None, alias="ALPACA_SECRET_KEY")
    alpaca_base_url: str = Field(
        default="https://paper-api.alpaca.markets",
        alias="ALPACA_BASE_URL"
    )


class RiskSettings(BaseSettings):
    """Risk management parameters."""
    model_config = SettingsConfigDict(env_prefix="", extra="ignore")
    
    max_position_size_pct: float = Field(
        default=15.0,
        alias="MAX_POSITION_SIZE_PCT"
    )
    max_sector_exposure_pct: float = Field(
        default=40.0,
        alias="MAX_SECTOR_EXPOSURE_PCT"
    )
    default_stop_loss_pct: float = Field(
        default=15.0,
        alias="DEFAULT_STOP_LOSS_PCT"
    )
    vix_threshold: float = Field(
        default=35.0,
        alias="VIX_THRESHOLD"
    )


class DashboardSettings(BaseSettings):
    """Dashboard configuration."""
    model_config = SettingsConfigDict(env_prefix="DASHBOARD_", extra="ignore")
    
    host: str = Field(default="0.0.0.0")
    port: int = Field(default=8050)
    debug: bool = Field(default=True)


class NotificationSettings(BaseSettings):
    """Notification configuration."""
    model_config = SettingsConfigDict(env_prefix="", extra="ignore")
    
    smtp_host: Optional[str] = Field(default=None, alias="SMTP_HOST")
    smtp_port: Optional[int] = Field(default=587, alias="SMTP_PORT")
    smtp_user: Optional[str] = Field(default=None, alias="SMTP_USER")
    smtp_password: Optional[str] = Field(default=None, alias="SMTP_PASSWORD")
    alert_email_to: Optional[str] = Field(default=None, alias="ALERT_EMAIL_TO")
    slack_webhook_url: Optional[str] = Field(default=None, alias="SLACK_WEBHOOK_URL")


class Settings(BaseSettings):
    """Main settings container."""
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore"
    )
    
    # Environment
    environment: str = Field(default="development", alias="ENVIRONMENT")
    log_level: str = Field(default="INFO", alias="LOG_LEVEL")
    signal_refresh_interval: int = Field(default=60, alias="SIGNAL_REFRESH_INTERVAL")
    
    # Sub-configurations
    database: DatabaseSettings = Field(default_factory=DatabaseSettings)
    baltic: BalticExchangeSettings = Field(default_factory=BalticExchangeSettings)
    ffa: FFABrokerSettings = Field(default_factory=FFABrokerSettings)
    bunker: BunkerSettings = Field(default_factory=BunkerSettings)
    equity: EquityDataSettings = Field(default_factory=EquityDataSettings)
    macro: MacroDataSettings = Field(default_factory=MacroDataSettings)
    broker: BrokerSettings = Field(default_factory=BrokerSettings)
    risk: RiskSettings = Field(default_factory=RiskSettings)
    dashboard: DashboardSettings = Field(default_factory=DashboardSettings)
    notifications: NotificationSettings = Field(default_factory=NotificationSettings)


# Global settings instance
settings = Settings()


# Signal thresholds and parameters
class SignalParameters:
    """Signal calculation parameters."""
    
    # LEP/FEP calculation
    DEFAULT_UTILIZATION_RATE: float = 0.95  # 95% utilization assumed
    SMOOTHING_WINDOW_DAYS: int = 7  # Moving average for spot rates
    
    # EIEP calculation
    DEFAULT_PE_MULTIPLE: float = 5.0  # Mid-cycle P/E for shipping
    PE_RANGE_LOW: float = 3.0
    PE_RANGE_HIGH: float = 10.0
    
    # INF score thresholds
    INF_HIGH_THRESHOLD: float = 70.0
    INF_MEDIUM_THRESHOLD: float = 40.0
    INF_WEIGHTS = {
        "earnings_change": 0.35,
        "fleet_repricing": 0.25,
        "consensus_surprise": 0.25,
        "breakeven_crossing": 0.15
    }
    
    # DIS score thresholds
    DIS_HIGH_THRESHOLD: float = 0.40  # 40% undervaluation
    DIS_MEDIUM_THRESHOLD: float = 0.20  # 20% undervaluation
    
    # RED model
    RED_PROJECTION_QUARTERS: int = 8  # 2 years forward
    
    # Risk regime
    CORRELATION_WINDOW_DAYS: int = 60
    LOW_CORRELATION_THRESHOLD: float = 0.2
    HIGH_CORRELATION_THRESHOLD: float = 0.6


# Company universe configuration
SHIPPING_UNIVERSE = {
    "dry_bulk": [
        {"ticker": "SBLK", "name": "Star Bulk Carriers", "segment": "dry_bulk"},
        {"ticker": "GOGL", "name": "Golden Ocean Group", "segment": "dry_bulk"},
        {"ticker": "GNK", "name": "Genco Shipping", "segment": "dry_bulk"},
        {"ticker": "EGLE", "name": "Eagle Bulk Shipping", "segment": "dry_bulk"},
        {"ticker": "DSX", "name": "Diana Shipping", "segment": "dry_bulk"},
        {"ticker": "NMM", "name": "Navios Maritime Partners", "segment": "dry_bulk"},
        {"ticker": "SB", "name": "Safe Bulkers", "segment": "dry_bulk"},
        {"ticker": "GRIN", "name": "Grindrod Shipping", "segment": "dry_bulk"},
    ],
    "tanker": [
        {"ticker": "FRO", "name": "Frontline", "segment": "tanker"},
        {"ticker": "DHT", "name": "DHT Holdings", "segment": "tanker"},
        {"ticker": "STNG", "name": "Scorpio Tankers", "segment": "tanker"},
        {"ticker": "TNK", "name": "Teekay Tankers", "segment": "tanker"},
        {"ticker": "INSW", "name": "International Seaways", "segment": "tanker"},
        {"ticker": "NAT", "name": "Nordic American Tankers", "segment": "tanker"},
        {"ticker": "EURN", "name": "Euronav", "segment": "tanker"},
        {"ticker": "ASC", "name": "Ardmore Shipping", "segment": "tanker"},
    ],
    "container": [
        {"ticker": "ZIM", "name": "ZIM Integrated Shipping", "segment": "container"},
        {"ticker": "DAC", "name": "Danaos Corporation", "segment": "container"},
        {"ticker": "GSL", "name": "Global Ship Lease", "segment": "container"},
        {"ticker": "CMRE", "name": "Costamare", "segment": "container"},
        {"ticker": "ESEA", "name": "Euroseas", "segment": "container"},
        {"ticker": "MATX", "name": "Matson", "segment": "container"},
    ],
    "lng": [
        {"ticker": "FLNG", "name": "Flex LNG", "segment": "lng"},
        {"ticker": "GLNG", "name": "Golar LNG", "segment": "lng"},
    ],
    "mixed": [
        {"ticker": "TRMD", "name": "TORM", "segment": "product_tanker"},
        {"ticker": "CPLP", "name": "Capital Product Partners", "segment": "mixed"},
    ]
}

# Freight index mappings
FREIGHT_INDEX_MAPPING = {
    # Dry Bulk
    "BDI": {"segment": "dry_bulk", "description": "Baltic Dry Index"},
    "BCI": {"segment": "capesize", "description": "Baltic Capesize Index"},
    "BPI": {"segment": "panamax", "description": "Baltic Panamax Index"},
    "BSI": {"segment": "supramax", "description": "Baltic Supramax Index"},
    "BHSI": {"segment": "handysize", "description": "Baltic Handysize Index"},
    
    # Tanker
    "BDTI": {"segment": "dirty_tanker", "description": "Baltic Dirty Tanker Index"},
    "BCTI": {"segment": "clean_tanker", "description": "Baltic Clean Tanker Index"},
    
    # Container
    "SCFI": {"segment": "container", "description": "Shanghai Containerized Freight Index"},
    "FBX": {"segment": "container", "description": "Freightos Baltic Index"},
    "HARPEX": {"segment": "container_charter", "description": "Harper Petersen Charter Rate Index"},
}

# Vessel type to index mapping
VESSEL_INDEX_MAPPING = {
    "capesize": "BCI",
    "panamax": "BPI",
    "supramax": "BSI",
    "handysize": "BHSI",
    "vlcc": "BDTI",
    "suezmax": "BDTI",
    "aframax": "BDTI",
    "mr_tanker": "BCTI",
    "lr1": "BCTI",
    "lr2": "BCTI",
    "container": "HARPEX",
}
