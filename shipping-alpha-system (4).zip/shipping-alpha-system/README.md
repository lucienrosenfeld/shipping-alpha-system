# Shipping Equity Alpha System

A systematic trading system that exploits the lag between real-time freight market profitability and delayed equity market recognition in shipping stocks.

## Core Strategy

The system identifies mispricings where shipping equities fail to reflect current freight market conditions due to:
- **TCE Recognition Lag**: Accounting delays between spot freight earnings and reported financials
- **Spot Earnings Convexity**: Nonlinear profit impact once fixed costs are covered
- **Investor Disbelief**: Market skepticism about sustainability of rate spikes

## Signal Architecture

| Signal | Description |
|--------|-------------|
| **LEP** | Live Earnings Power - Real-time annualized earnings based on current spot rates |
| **FEP** | Forward Earnings Power - Projected earnings using FFA forward curve |
| **EIEP** | Equity-Implied Earnings Power - What the stock price implies about earnings |
| **INF** | Inflection Score - Magnitude/imminence of earnings trajectory pivot |
| **DIS** | Disbelief Score - Degree of market underpricing vs fundamentals |

## Trade Archetypes

1. **Earnings Surprise**: Short-term positions ahead of quarterly results (high INF + moderate DIS)
2. **Re-Rating**: Medium-term positions for valuation normalization (high DIS)

## Project Structure

```
shipping-alpha-system/
├── src/
│   ├── api/              # External API clients (Baltic, FFAs, equities)
│   ├── data/             # Data ingestion and storage
│   ├── signals/          # Signal calculation engine
│   ├── models/           # Database models and schemas
│   ├── trading/          # Trade execution and management
│   ├── risk/             # Risk regime detection and filters
│   ├── utils/            # Utilities and helpers
│   └── dashboard/        # Monitoring dashboard
├── tests/                # Unit and integration tests
├── config/               # Configuration files
├── scripts/              # Utility scripts
└── docs/                 # Documentation
```

## Installation

```bash
# Clone repository
git clone https://github.com/yourusername/shipping-alpha-system.git
cd shipping-alpha-system

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Linux/Mac
# or: venv\Scripts\activate  # Windows

# Install dependencies
pip install -r requirements.txt

# Copy and configure environment
cp .env.example .env
# Edit .env with your API keys
```

## Configuration

Copy `.env.example` to `.env` and configure:

```bash
# Data APIs
BALTIC_EXCHANGE_API_KEY=your_key_here
FFA_BROKER_API_KEY=your_key_here
ALPHA_VANTAGE_API_KEY=your_key_here

# Database
DATABASE_URL=postgresql://user:pass@localhost/shipping_alpha

# Trading (optional - for live execution)
BROKER_API_KEY=your_key_here
```

## Usage

### Run Signal Engine
```bash
python -m src.main --mode signals
```

### Run Backtester
```bash
python -m src.main --mode backtest --start 2020-01-01 --end 2024-12-31
```

### Launch Dashboard
```bash
python -m src.dashboard.app
```

## API Data Sources

| Source | Data | Frequency |
|--------|------|-----------|
| Baltic Exchange | BDI, BDTI, BCTI indices | Daily |
| FFA Broker | Forward freight curves | Daily |
| Ship & Bunker | Bunker fuel prices | Daily |
| Alpha Vantage / Yahoo | Equity prices | Real-time |
| SEC EDGAR | Company filings | As filed |

## Risk Management

- **Macro Filter**: VIX, credit spreads, global PMI monitoring
- **Correlation Regime**: Freight-equity correlation tracking
- **Position Limits**: Per-stock and sector exposure caps
- **Dynamic Stops**: Volatility-adjusted stop-losses

## License

Proprietary - All Rights Reserved

## Disclaimer

This system is for educational and research purposes. Trading involves substantial risk of loss. Past performance does not guarantee future results.
