"""
Tests for risk management module.
"""

import pytest
from datetime import date

import sys
sys.path.insert(0, '/home/claude/shipping-alpha-system')

from src.risk.manager import (
    RiskRegime,
    CorrelationRegime,
    MacroSnapshot,
    RiskAssessment,
    MacroFilter,
    CorrelationTracker,
    PositionSizer,
    StopLossManager,
    RiskManager,
)


class TestMacroFilter:
    """Tests for macro regime filter."""
    
    def setup_method(self):
        self.filter = MacroFilter()
    
    def test_normal_regime(self):
        """Test normal market conditions."""
        macro = MacroSnapshot(
            date=date.today(),
            vix=18.0,
            sp500_price=5500,
            sp500_1w_return=0.01,
            credit_spread=3.0,
            treasury_10y=4.0,
            dxy=104.0,
            oil_price=75.0,
        )
        
        result = self.filter.assess(macro)
        
        assert result["regime"] == RiskRegime.NORMAL
        assert result["position_multiplier"] == 1.0
    
    def test_caution_regime_vix(self):
        """Test caution regime triggered by VIX."""
        macro = MacroSnapshot(
            date=date.today(),
            vix=28.0,  # Above warning threshold
            sp500_price=5500,
            sp500_1w_return=0.01,
            credit_spread=3.0,
            treasury_10y=4.0,
            dxy=104.0,
            oil_price=75.0,
        )
        
        result = self.filter.assess(macro)
        
        assert result["vix_elevated"] == True
    
    def test_risk_off_regime(self):
        """Test risk-off triggered by multiple critical flags."""
        macro = MacroSnapshot(
            date=date.today(),
            vix=45.0,  # Critical
            sp500_price=5000,
            sp500_1w_return=-0.12,  # Critical
            credit_spread=7.0,  # Critical
            treasury_10y=5.0,
            dxy=110.0,
            oil_price=90.0,
        )
        
        result = self.filter.assess(macro)
        
        assert result["regime"] == RiskRegime.RISK_OFF
        assert result["position_multiplier"] == 0.0


class TestCorrelationTracker:
    """Tests for correlation regime tracking."""
    
    def setup_method(self):
        self.tracker = CorrelationTracker()
    
    def test_calculate_correlation(self):
        """Test correlation calculation."""
        series_a = [1, 2, 3, 4, 5]
        series_b = [1, 2, 3, 4, 5]
        
        corr = self.tracker.calculate_correlation(series_a, series_b)
        
        # Perfectly correlated
        assert abs(corr - 1.0) < 0.01
    
    def test_negative_correlation(self):
        """Test negative correlation."""
        series_a = [1, 2, 3, 4, 5]
        series_b = [5, 4, 3, 2, 1]
        
        corr = self.tracker.calculate_correlation(series_a, series_b)
        
        assert abs(corr - (-1.0)) < 0.01
    
    def test_high_freight_regime(self):
        """Test high freight correlation regime."""
        # Stock moves with freight
        stock_returns = [0.01, -0.02, 0.03, -0.01, 0.02]
        freight_returns = [0.01, -0.02, 0.03, -0.01, 0.02]  # Same as stock
        market_returns = [-0.01, 0.01, -0.02, 0.02, -0.01]  # Opposite
        
        result = self.tracker.assess_correlation_regime(
            stock_returns, freight_returns, market_returns
        )
        
        assert result["regime"] == CorrelationRegime.HIGH_FREIGHT
        assert result["signal_effectiveness"] == 1.0


class TestPositionSizer:
    """Tests for position sizing."""
    
    def setup_method(self):
        self.sizer = PositionSizer()
    
    def test_basic_sizing(self):
        """Test basic position sizing."""
        result = self.sizer.calculate_position_size(
            portfolio_value=1_000_000,
            signal_strength=1.0,
            risk_multiplier=1.0,
        )
        
        # At full strength and risk, should get base position
        assert result["position_pct"] == self.sizer.base_position_pct
        assert result["position_value"] == 100_000  # 10% of $1M
    
    def test_weak_signal_sizing(self):
        """Test sizing with weak signal."""
        result = self.sizer.calculate_position_size(
            portfolio_value=1_000_000,
            signal_strength=0.5,
            risk_multiplier=1.0,
        )
        
        # Weak signal should reduce size
        assert result["position_pct"] < self.sizer.base_position_pct
    
    def test_risk_off_sizing(self):
        """Test sizing in risk-off regime."""
        result = self.sizer.calculate_position_size(
            portfolio_value=1_000_000,
            signal_strength=1.0,
            risk_multiplier=0.0,  # Risk off
        )
        
        # Should be zero or not viable
        assert result["position_pct"] == 0 or not result["viable"]
    
    def test_sector_limit(self):
        """Test sector exposure limit."""
        result = self.sizer.calculate_position_size(
            portfolio_value=1_000_000,
            signal_strength=1.0,
            risk_multiplier=1.0,
            sector_exposure=0.35,  # Already 35% in sector
        )
        
        # Should be capped by remaining sector allocation
        assert result["position_pct"] <= 0.05  # Only 5% remaining


class TestStopLossManager:
    """Tests for stop loss management."""
    
    def setup_method(self):
        self.manager = StopLossManager()
    
    def test_initial_stop(self):
        """Test initial stop calculation."""
        stop = self.manager.calculate_initial_stop(entry_price=100.0)
        
        # Default 15% stop
        assert stop == 85.0
    
    def test_trailing_stop_inactive(self):
        """Test trailing stop before activation."""
        result = self.manager.update_trailing_stop(
            entry_price=100.0,
            current_price=105.0,  # 5% gain
            highest_price=106.0,
            current_stop=85.0,
        )
        
        # Not activated yet (need 15% gain)
        assert result["trailing_active"] == False
        assert result["stop_price"] == 85.0
    
    def test_trailing_stop_active(self):
        """Test trailing stop after activation."""
        result = self.manager.update_trailing_stop(
            entry_price=100.0,
            current_price=120.0,  # 20% gain
            highest_price=125.0,  # Hit 25% at peak
            current_stop=85.0,
        )
        
        # Should be activated and trailing
        assert result["trailing_active"] == True
        # Trailing stop at 125 * 0.9 = 112.50
        assert result["stop_price"] == 112.5
    
    def test_stop_triggered(self):
        """Test stop trigger detection."""
        result = self.manager.update_trailing_stop(
            entry_price=100.0,
            current_price=84.0,  # Below stop
            highest_price=100.0,
            current_stop=85.0,
        )
        
        assert result["stop_triggered"] == True


class TestRiskManager:
    """Integration tests for full risk manager."""
    
    def setup_method(self):
        self.manager = RiskManager()
    
    def test_full_assessment(self):
        """Test complete risk assessment."""
        macro = MacroSnapshot(
            date=date.today(),
            vix=20.0,
            sp500_price=5500,
            sp500_1w_return=0.01,
            credit_spread=3.0,
            treasury_10y=4.0,
            dxy=104.0,
            oil_price=75.0,
        )
        
        result = self.manager.assess_risk(macro)
        
        assert isinstance(result, RiskAssessment)
        assert result.risk_regime == RiskRegime.NORMAL
        assert result.position_size_multiplier == 1.0
    
    def test_manual_override(self):
        """Test manual regime override."""
        self.manager.set_manual_override(
            regime=RiskRegime.CAUTION,
            reason="Geopolitical event"
        )
        
        macro = MacroSnapshot(
            date=date.today(),
            vix=15.0,  # Normal VIX
            sp500_price=5500,
            sp500_1w_return=0.02,
            credit_spread=2.5,
            treasury_10y=4.0,
            dxy=104.0,
            oil_price=75.0,
        )
        
        result = self.manager.assess_risk(macro)
        
        # Override should take effect
        assert result.risk_regime == RiskRegime.CAUTION
        assert result.manual_override == True
        
        # Clear and check
        self.manager.clear_manual_override()
        result2 = self.manager.assess_risk(macro)
        assert result2.risk_regime == RiskRegime.NORMAL
    
    def test_position_sizing_integration(self):
        """Test position sizing through risk manager."""
        macro = MacroSnapshot(
            date=date.today(),
            vix=20.0,
            sp500_price=5500,
            sp500_1w_return=0.01,
            credit_spread=3.0,
            treasury_10y=4.0,
            dxy=104.0,
            oil_price=75.0,
        )
        
        assessment = self.manager.assess_risk(macro)
        
        sizing = self.manager.size_position(
            portfolio_value=1_000_000,
            signal_strength=0.8,
            risk_assessment=assessment,
        )
        
        assert sizing["viable"] == True
        assert sizing["position_value"] > 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
