"""
Tests for signal calculation modules.
"""

import pytest
from datetime import date, timedelta
from typing import Dict, List

# Import modules to test
import sys
sys.path.insert(0, '/home/claude/shipping-alpha-system')

from src.signals.earnings import (
    VesselEarnings,
    FleetEarnings,
    LEPCalculator,
    FEPCalculator,
    EIEPCalculator,
    REDCalculator,
)
from src.signals.scores import (
    INFCalculator,
    DISCalculator,
    TradeSignalGenerator,
    INFComponents,
)


class TestVesselEarnings:
    """Tests for VesselEarnings dataclass."""
    
    def test_gross_revenue(self):
        vessel = VesselEarnings(
            vessel_id=1,
            vessel_type="capesize",
            charter_type="spot",
            daily_rate=25000,
            days_at_rate=90,
            daily_opex=7000,
        )
        assert vessel.gross_revenue == 25000 * 90
    
    def test_operating_cost(self):
        vessel = VesselEarnings(
            vessel_id=1,
            vessel_type="capesize",
            charter_type="spot",
            daily_rate=25000,
            days_at_rate=90,
            daily_opex=7000,
        )
        assert vessel.operating_cost == 7000 * 90
    
    def test_net_earnings(self):
        vessel = VesselEarnings(
            vessel_id=1,
            vessel_type="capesize",
            charter_type="spot",
            daily_rate=25000,
            days_at_rate=90,
            daily_opex=7000,
        )
        expected = (25000 - 7000) * 90
        assert vessel.net_earnings == expected


class TestFleetEarnings:
    """Tests for FleetEarnings aggregation."""
    
    def test_total_gross_revenue(self):
        fleet = FleetEarnings(
            company_id=1,
            calculation_date=date.today(),
            projection_period_days=365,
        )
        
        fleet.vessel_earnings = [
            VesselEarnings(1, "capesize", "spot", 25000, 90, 7000),
            VesselEarnings(2, "panamax", "spot", 18000, 90, 6000),
        ]
        
        expected = 25000 * 90 + 18000 * 90
        assert fleet.total_gross_revenue == expected
    
    def test_ebitda(self):
        fleet = FleetEarnings(
            company_id=1,
            calculation_date=date.today(),
            projection_period_days=365,
            ga_expense=1000000,
        )
        
        fleet.vessel_earnings = [
            VesselEarnings(1, "capesize", "spot", 25000, 365, 7000),
        ]
        
        gross_profit = (25000 - 7000) * 365
        expected_ebitda = gross_profit - 1000000
        assert fleet.ebitda == expected_ebitda


class TestLEPCalculator:
    """Tests for Live Earnings Power calculator."""
    
    def setup_method(self):
        self.calc = LEPCalculator()
    
    def test_simple_spot_fleet(self):
        """Test LEP for fleet entirely on spot."""
        company_data = {
            "id": 1,
            "annual_ga_expense": 5000000,
            "annual_interest_expense": 3000000,
            "depreciation": 10000000,
        }
        
        vessels = [
            {"id": 1, "vessel_type": "capesize", "daily_opex": 7000, "active": True},
            {"id": 2, "vessel_type": "capesize", "daily_opex": 7000, "active": True},
        ]
        
        charters = []  # All spot
        
        spot_rates = {"capesize": 30000}
        
        result = self.calc.calculate(
            company_data=company_data,
            vessels=vessels,
            charters=charters,
            spot_rates=spot_rates,
            calculation_date=date.today(),
            projection_days=365,
        )
        
        # Each vessel: (30000 - 7000) * 365 * 0.95 utilization
        expected_vessel_earnings = (30000 - 7000) * 365 * 0.95
        expected_gross_profit = expected_vessel_earnings * 2
        
        assert len(result.vessel_earnings) == 2
        assert result.gross_profit > 0
    
    def test_to_eps(self):
        """Test EPS conversion."""
        fleet = FleetEarnings(
            company_id=1,
            calculation_date=date.today(),
            projection_period_days=365,
        )
        fleet.vessel_earnings = [
            VesselEarnings(1, "capesize", "spot", 25000, 365, 7000),
        ]
        
        # Net income = gross - ga - interest
        # For a simple fleet, this should be positive
        eps = self.calc.to_eps(fleet, shares_outstanding=100_000_000)
        
        # Should get some positive EPS
        assert isinstance(eps, float)


class TestEIEPCalculator:
    """Tests for Equity-Implied Earnings Power calculator."""
    
    def setup_method(self):
        self.calc = EIEPCalculator(default_pe=5.0)
    
    def test_basic_calculation(self):
        """Test basic EIEP calculation."""
        result = self.calc.calculate(
            stock_price=25.0,
            shares_outstanding=100_000_000,
        )
        
        # At P/E of 5, $25 stock implies $5 EPS
        assert result["implied_eps"] == 5.0
        assert result["pe_used"] == 5.0
        assert result["market_cap"] == 25 * 100_000_000
    
    def test_custom_pe(self):
        """Test with custom P/E multiple."""
        result = self.calc.calculate(
            stock_price=25.0,
            shares_outstanding=100_000_000,
            pe_multiple=10.0,
        )
        
        # At P/E of 10, $25 stock implies $2.50 EPS
        assert result["implied_eps"] == 2.5


class TestREDCalculator:
    """Tests for Realized Earnings Delay calculator."""
    
    def setup_method(self):
        self.calc = REDCalculator()
    
    def test_all_spot_fleet(self):
        """All spot fleet should have minimal RED."""
        vessels = [
            {"id": 1, "vessel_type": "capesize", "active": True},
            {"id": 2, "vessel_type": "capesize", "active": True},
        ]
        
        charters = []  # All spot
        
        result = self.calc.calculate(
            vessels=vessels,
            charters=charters,
            calculation_date=date.today(),
        )
        
        assert result["fleet_spot_pct"] == 1.0
        assert result["quarterly_breakdown"][0]["spot_pct"] == 1.0


class TestINFCalculator:
    """Tests for Inflection Score calculator."""
    
    def setup_method(self):
        self.calc = INFCalculator()
    
    def test_positive_inflection(self):
        """Test positive earnings inflection."""
        score, components = self.calc.calculate(
            projected_eps=5.0,
            trailing_eps=2.0,
            consensus_eps=3.0,
            fleet_repricing_pct=50,
        )
        
        # Large earnings improvement should give high INF
        assert score > 50
        assert components.earnings_change_score > 0
    
    def test_breakeven_crossing(self):
        """Test breakeven crossing bonus."""
        score, components = self.calc.calculate(
            projected_eps=1.0,
            trailing_eps=-0.5,  # Was losing money
            consensus_eps=0.5,
            fleet_repricing_pct=30,
        )
        
        assert components.breakeven_crossing_score == 100  # Max bonus
    
    def test_classify(self):
        """Test INF classification."""
        assert self.calc.classify(80) == "HIGH"
        assert self.calc.classify(50) == "MEDIUM"
        assert self.calc.classify(30) == "LOW"


class TestDISCalculator:
    """Tests for Disbelief Score calculator."""
    
    def setup_method(self):
        self.calc = DISCalculator()
    
    def test_undervalued(self):
        """Test undervaluation detection."""
        dis, details = self.calc.calculate(
            lep=4.0,
            fep=5.0,
            eiep=2.5,  # Market only pricing in $2.50
        )
        
        # DIS = (fundamental - implied) / fundamental
        # Fundamental ≈ 0.3*4 + 0.7*5 = 4.7
        # DIS ≈ (4.7 - 2.5) / 4.7 ≈ 0.47
        assert dis > 0.4
        assert details["undervalued"] == True
    
    def test_overvalued(self):
        """Test overvaluation detection."""
        dis, details = self.calc.calculate(
            lep=2.0,
            fep=2.0,
            eiep=4.0,  # Market pricing in $4 when only $2 expected
        )
        
        assert dis < 0
        assert details["overvalued"] == True
    
    def test_classify(self):
        """Test DIS classification."""
        assert self.calc.classify(0.50) == "HIGH_UNDERVALUED"
        assert self.calc.classify(0.25) == "MODERATE_UNDERVALUED"
        assert self.calc.classify(0.05) == "FAIRLY_VALUED"
        assert self.calc.classify(-0.30) == "MODERATE_OVERVALUED"


class TestTradeSignalGenerator:
    """Tests for trade signal generation."""
    
    def setup_method(self):
        self.inf_calc = INFCalculator()
        self.dis_calc = DISCalculator()
        self.gen = TradeSignalGenerator(self.inf_calc, self.dis_calc)
    
    def test_buy_signal_earnings_surprise(self):
        """Test buy signal for earnings surprise setup."""
        signal = self.gen.generate_signal(
            inf_score=85,  # High INF
            dis_score=0.25,  # Moderate undervaluation
            macro_regime="normal",
            earnings_days_away=30,  # Near-term catalyst
        )
        
        assert signal["buy_signal"] == True
        assert signal["trade_type"] == "earnings_surprise"
    
    def test_buy_signal_rerating(self):
        """Test buy signal for re-rating setup."""
        signal = self.gen.generate_signal(
            inf_score=45,  # Moderate INF
            dis_score=0.50,  # High undervaluation
            macro_regime="normal",
            earnings_days_away=None,
        )
        
        assert signal["buy_signal"] == True
        assert "re_rating" in str(signal["trade_type"]) or signal["dis_score"] > 0.4
    
    def test_risk_off_blocks_buys(self):
        """Risk-off regime should block new buys."""
        signal = self.gen.generate_signal(
            inf_score=85,
            dis_score=0.50,
            macro_regime="risk_off",
            earnings_days_away=30,
        )
        
        assert signal["buy_signal"] == False


class TestIntegration:
    """Integration tests for the full signal pipeline."""
    
    def test_full_signal_calculation(self):
        """Test complete signal calculation flow."""
        # Setup
        lep_calc = LEPCalculator()
        eiep_calc = EIEPCalculator()
        inf_calc = INFCalculator()
        dis_calc = DISCalculator()
        
        # Company data
        company = {
            "id": 1,
            "annual_ga_expense": 5000000,
            "annual_interest_expense": 2000000,
            "depreciation": 8000000,
        }
        
        vessels = [
            {"id": 1, "vessel_type": "capesize", "daily_opex": 7000, "active": True},
        ]
        
        # Calculate LEP
        lep_earnings = lep_calc.calculate(
            company_data=company,
            vessels=vessels,
            charters=[],
            spot_rates={"capesize": 35000},
            calculation_date=date.today(),
        )
        
        shares = 100_000_000
        lep_eps = lep_calc.to_eps(lep_earnings, shares)
        
        # Calculate EIEP
        stock_price = 20.0
        eiep = eiep_calc.calculate(stock_price, shares)
        eiep_eps = eiep["implied_eps"]
        
        # Calculate DIS
        fep_eps = lep_eps * 0.9  # Assume FEP slightly lower
        dis_score, _ = dis_calc.calculate(lep_eps, fep_eps, eiep_eps)
        
        # Calculate INF
        inf_score, _ = inf_calc.calculate(
            projected_eps=fep_eps,
            trailing_eps=lep_eps * 0.7,
            consensus_eps=fep_eps * 0.8,
            fleet_repricing_pct=80,
        )
        
        # Verify we got reasonable values
        assert isinstance(lep_eps, float)
        assert isinstance(dis_score, float)
        assert isinstance(inf_score, float)
        assert 0 <= inf_score <= 100


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
