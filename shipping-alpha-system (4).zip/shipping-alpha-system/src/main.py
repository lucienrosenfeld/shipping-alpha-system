"""
Shipping Equity Alpha System - Main Entry Point

Usage:
    python -m src.main --mode signals
    python -m src.main --mode backtest --start 2020-01-01
    python -m src.main --mode dashboard
    python -m src.main --mode ingest
"""

import argparse
import sys
from datetime import date, datetime
from typing import Optional

from loguru import logger

# Configure logging
logger.remove()
logger.add(
    sys.stderr,
    format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>",
    level="INFO"
)
logger.add(
    "logs/shipping_alpha_{time}.log",
    rotation="1 day",
    retention="30 days",
    level="DEBUG"
)


def setup_database():
    """Initialize database connection and create tables."""
    from config import settings
    from src.models import init_db, get_session_factory
    
    engine = init_db(settings.database.database_url)
    Session = get_session_factory(engine)
    return Session()


def setup_api_clients():
    """Initialize API clients."""
    from config import settings
    from src.api import create_clients
    
    return create_clients(settings)


def run_signals(as_of_date: Optional[date] = None):
    """Run signal calculations for universe."""
    from config import SHIPPING_UNIVERSE
    from src.engine import SignalEngine
    
    logger.info("Starting signal calculation run")
    
    session = setup_database()
    
    try:
        engine = SignalEngine(session)
        
        # Calculate signals
        results = engine.calculate_universe_signals(as_of_date)
        
        # Get trade candidates
        candidates = engine.get_trade_candidates(results)
        
        # Print summary
        print("\n" + "=" * 80)
        print("SIGNAL CALCULATION SUMMARY")
        print("=" * 80)
        print(f"Date: {as_of_date or date.today()}")
        print(f"Companies analyzed: {len(results)}")
        print(f"Buy signals: {sum(1 for r in results if r.buy_signal)}")
        print(f"Sell signals: {sum(1 for r in results if r.sell_signal)}")
        
        if candidates:
            print("\n" + "-" * 80)
            print("TOP TRADE CANDIDATES")
            print("-" * 80)
            print(f"{'Ticker':<8} {'Type':<18} {'Strength':<10} {'DIS':<10} {'INF':<8} {'LEP':<8} {'FEP':<8}")
            print("-" * 80)
            for c in candidates[:10]:
                print(f"{c['ticker']:<8} {c['trade_type'] or 'N/A':<18} {c['signal_strength']:<10.2f} "
                      f"{c['dis_score']:<10.1%} {c['inf_score']:<8.0f} {c['lep']:<8.2f} {c['fep']:<8.2f}")
        
        print("\n" + "=" * 80)
        
    finally:
        session.close()


def run_ingest(as_of_date: Optional[date] = None, backfill_days: int = 0):
    """Run data ingestion."""
    from config import SHIPPING_UNIVERSE
    from src.data import DataIngestionService
    
    logger.info("Starting data ingestion")
    
    session = setup_database()
    clients = setup_api_clients()
    
    # Get all tickers
    tickers = []
    for segment, companies in SHIPPING_UNIVERSE.items():
        tickers.extend([c["ticker"] for c in companies])
    
    try:
        service = DataIngestionService(
            session=session,
            baltic_client=clients["baltic"],
            ffa_client=clients["ffa"],
            equity_client=clients["equity"],
            macro_client=clients["macro"],
            bunker_client=clients["bunker"],
        )
        
        if backfill_days > 0:
            start_date = date.today() - datetime.timedelta(days=backfill_days)
            results = service.backfill_history(tickers, start_date)
            logger.info(f"Backfill complete: {results}")
        else:
            results = service.ingest_all_daily(tickers, as_of_date)
            logger.info(f"Daily ingestion complete: {results}")
        
    finally:
        session.close()


def run_backtest(
    start_date: date,
    end_date: Optional[date] = None,
    initial_capital: float = 100000,
):
    """Run backtest simulation."""
    from src.engine import SignalEngine
    from src.trading import PortfolioManager, PaperBroker, TradeOrder
    from config import SHIPPING_UNIVERSE
    
    logger.info(f"Starting backtest from {start_date} to {end_date or date.today()}")
    
    session = setup_database()
    
    try:
        engine = SignalEngine(session)
        broker = PaperBroker()
        portfolio = PortfolioManager(session, broker, initial_capital)
        
        current_date = start_date
        end = end_date or date.today()
        
        while current_date <= end:
            # Skip weekends
            if current_date.weekday() >= 5:
                current_date += datetime.timedelta(days=1)
                continue
            
            # Calculate signals
            results = engine.calculate_universe_signals(current_date)
            candidates = engine.get_trade_candidates(results)
            
            # Update prices
            prices = {r.ticker: r.eiep * 5 for r in results}  # Approximate price
            portfolio.update_prices(prices)
            
            # Check stops
            triggered = portfolio.check_stops(prices)
            for stop in triggered:
                portfolio.close_position(
                    stop["ticker"],
                    stop["current_price"],
                    reason=stop["type"]
                )
            
            # Open new positions
            for candidate in candidates[:3]:  # Max 3 new positions
                if candidate["ticker"] not in portfolio.positions:
                    if len(portfolio.positions) < 5:  # Max 5 positions
                        price = prices.get(candidate["ticker"], 20)
                        shares = int(portfolio.total_value * 0.10 / price)  # 10% position
                        
                        if shares > 0:
                            order = TradeOrder(
                                ticker=candidate["ticker"],
                                side="buy",
                                quantity=shares,
                                trade_type=candidate["trade_type"],
                                entry_signals={
                                    "lep": candidate["lep"],
                                    "fep": candidate["fep"],
                                    "dis": candidate["dis_score"],
                                    "inf": candidate["inf_score"],
                                }
                            )
                            portfolio.open_position(order, price)
            
            current_date += datetime.timedelta(days=1)
        
        # Print results
        snapshot = portfolio.get_portfolio_snapshot()
        
        print("\n" + "=" * 80)
        print("BACKTEST RESULTS")
        print("=" * 80)
        print(f"Period: {start_date} to {end_date or date.today()}")
        print(f"Initial Capital: ${initial_capital:,.2f}")
        print(f"Final Value: ${snapshot['total_value']:,.2f}")
        print(f"Total Return: {(snapshot['total_value'] / initial_capital - 1) * 100:.2f}%")
        print(f"Open Positions: {snapshot['position_count']}")
        print("=" * 80)
        
    finally:
        session.close()


def run_dashboard():
    """Launch the monitoring dashboard."""
    logger.info("Starting dashboard server")
    
    # Import here to avoid loading dash if not needed
    from src.dashboard.app import create_app
    from config import settings
    
    app = create_app()
    app.run_server(
        host=settings.dashboard.host,
        port=settings.dashboard.port,
        debug=settings.dashboard.debug,
    )


def seed_universe():
    """Seed the database with shipping company universe."""
    from config import SHIPPING_UNIVERSE
    from src.models import Company, ShippingSegment
    
    logger.info("Seeding company universe")
    
    session = setup_database()
    
    try:
        for segment, companies in SHIPPING_UNIVERSE.items():
            for company_data in companies:
                existing = session.query(Company).filter(
                    Company.ticker == company_data["ticker"]
                ).first()
                
                if not existing:
                    company = Company(
                        ticker=company_data["ticker"],
                        name=company_data["name"],
                        segment=ShippingSegment(company_data["segment"]),
                        active=True,
                    )
                    session.add(company)
                    logger.debug(f"Added {company_data['ticker']}")
        
        session.commit()
        logger.info("Universe seeding complete")
        
    finally:
        session.close()


def main():
    parser = argparse.ArgumentParser(
        description="Shipping Equity Alpha System",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python -m src.main --mode signals
  python -m src.main --mode ingest --backfill 365
  python -m src.main --mode backtest --start 2023-01-01 --end 2024-12-31
  python -m src.main --mode dashboard
  python -m src.main --mode seed
        """
    )
    
    parser.add_argument(
        "--mode",
        choices=["signals", "ingest", "backtest", "dashboard", "seed"],
        required=True,
        help="Operation mode"
    )
    
    parser.add_argument(
        "--date",
        type=lambda s: datetime.strptime(s, "%Y-%m-%d").date(),
        default=None,
        help="Date for calculations (YYYY-MM-DD)"
    )
    
    parser.add_argument(
        "--start",
        type=lambda s: datetime.strptime(s, "%Y-%m-%d").date(),
        default=None,
        help="Backtest start date"
    )
    
    parser.add_argument(
        "--end",
        type=lambda s: datetime.strptime(s, "%Y-%m-%d").date(),
        default=None,
        help="Backtest end date"
    )
    
    parser.add_argument(
        "--capital",
        type=float,
        default=100000,
        help="Initial capital for backtest"
    )
    
    parser.add_argument(
        "--backfill",
        type=int,
        default=0,
        help="Number of days to backfill"
    )
    
    args = parser.parse_args()
    
    try:
        if args.mode == "signals":
            run_signals(args.date)
        
        elif args.mode == "ingest":
            run_ingest(args.date, args.backfill)
        
        elif args.mode == "backtest":
            if not args.start:
                parser.error("--start is required for backtest mode")
            run_backtest(args.start, args.end, args.capital)
        
        elif args.mode == "dashboard":
            run_dashboard()
        
        elif args.mode == "seed":
            seed_universe()
        
    except KeyboardInterrupt:
        logger.info("Interrupted by user")
        sys.exit(0)
    except Exception as e:
        logger.exception(f"Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
