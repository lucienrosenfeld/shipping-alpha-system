"""
Production Execution Layer

Handles real-world execution concerns:
1. Liquidity-aware position sizing (VWAP, participation rate)
2. Earnings-day trading rules and blackouts
3. Partial fill handling
4. Slippage estimation
5. Order routing
"""

from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, time
from typing import Dict, List, Optional, Any, Tuple
from enum import Enum
import math

from loguru import logger


class OrderType(Enum):
    """Order types."""
    MARKET = "market"
    LIMIT = "limit"
    VWAP = "vwap"
    TWAP = "twap"
    MOC = "market_on_close"
    LOC = "limit_on_close"


class OrderStatus(Enum):
    """Order execution status."""
    PENDING = "pending"
    SUBMITTED = "submitted"
    PARTIAL = "partial"
    FILLED = "filled"
    CANCELLED = "cancelled"
    REJECTED = "rejected"


class TradingRestriction(Enum):
    """Trading restriction types."""
    NONE = "none"
    EARNINGS_BLACKOUT = "earnings_blackout"
    CORPORATE_ACTION = "corporate_action"
    HALTED = "halted"
    LIQUIDITY = "liquidity"


@dataclass
class LiquidityProfile:
    """Stock liquidity profile."""
    ticker: str
    
    # Volume metrics
    avg_daily_volume: float  # ADV (shares)
    avg_daily_value: float  # ADV in dollars
    
    # Spread
    avg_spread_pct: float
    avg_spread_cents: float
    
    # Market impact estimates (bps per % of ADV)
    impact_coefficient: float = 30.0  # bps impact per 1% ADV
    
    # Intraday profile
    volume_by_hour: Dict[int, float] = field(default_factory=dict)  # Hour -> % of daily volume
    
    def estimate_impact(self, shares: int, current_price: float) -> float:
        """
        Estimate market impact for an order.
        
        Uses square-root model: Impact = coef * sqrt(shares / ADV)
        
        Returns:
            Estimated impact in basis points
        """
        if self.avg_daily_volume <= 0:
            return 100  # 1% impact if no volume data
        
        participation = shares / self.avg_daily_volume
        impact_bps = self.impact_coefficient * math.sqrt(participation)
        
        return impact_bps
    
    def max_position_shares(
        self,
        max_participation_pct: float = 0.10,
        days_to_accumulate: int = 5,
    ) -> int:
        """
        Calculate maximum position size based on liquidity.
        
        Args:
            max_participation_pct: Max % of daily volume per day
            days_to_accumulate: Days to build position
            
        Returns:
            Maximum shares
        """
        daily_max = self.avg_daily_volume * max_participation_pct
        return int(daily_max * days_to_accumulate)


@dataclass
class Order:
    """Trade order."""
    order_id: str
    ticker: str
    side: str  # "buy" or "sell"
    quantity: int
    order_type: OrderType = OrderType.MARKET
    
    # Limit price (for limit orders)
    limit_price: Optional[float] = None
    
    # Execution params
    time_in_force: str = "day"  # "day", "gtc", "ioc", "fok"
    max_participation_pct: float = 0.10  # Max % of volume
    
    # Status
    status: OrderStatus = OrderStatus.PENDING
    filled_quantity: int = 0
    avg_fill_price: float = 0
    
    # Execution details
    submitted_at: Optional[datetime] = None
    filled_at: Optional[datetime] = None
    fills: List[Dict[str, Any]] = field(default_factory=list)
    
    # Costs
    commission: float = 0
    estimated_impact: float = 0
    actual_impact: float = 0
    
    @property
    def remaining_quantity(self) -> int:
        return self.quantity - self.filled_quantity
    
    @property
    def is_complete(self) -> bool:
        return self.status in [OrderStatus.FILLED, OrderStatus.CANCELLED, OrderStatus.REJECTED]


@dataclass
class EarningsCalendarEntry:
    """Earnings announcement entry."""
    ticker: str
    earnings_date: date
    time_of_day: str  # "bmo" (before market open), "amc" (after market close), "unknown"
    
    # Estimates
    consensus_eps: Optional[float] = None
    whisper_number: Optional[float] = None
    
    # Actual (after announcement)
    actual_eps: Optional[float] = None
    surprise_pct: Optional[float] = None
    
    @property
    def blackout_start(self) -> date:
        """Start of pre-earnings blackout (typically 1 week before)."""
        return self.earnings_date - timedelta(days=7)
    
    @property
    def blackout_end(self) -> date:
        """End of post-earnings blackout (1 day after to absorb reaction)."""
        return self.earnings_date + timedelta(days=1)


class ExecutionEngine:
    """
    Production execution engine.
    
    Handles order routing, fill simulation, and execution analytics.
    """
    
    def __init__(
        self,
        broker_client=None,
        paper_mode: bool = True,
    ):
        self.broker = broker_client
        self.paper_mode = paper_mode
        self.pending_orders: Dict[str, Order] = {}
        self.completed_orders: List[Order] = []
    
    def submit_order(
        self,
        ticker: str,
        side: str,
        quantity: int,
        order_type: OrderType = OrderType.MARKET,
        limit_price: Optional[float] = None,
        liquidity_profile: Optional[LiquidityProfile] = None,
    ) -> Order:
        """
        Submit an order for execution.
        
        Args:
            ticker: Stock ticker
            side: "buy" or "sell"
            quantity: Number of shares
            order_type: Type of order
            limit_price: Limit price (for limit orders)
            liquidity_profile: Liquidity data for impact estimation
            
        Returns:
            Order object
        """
        order_id = f"ORD-{ticker}-{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
        
        order = Order(
            order_id=order_id,
            ticker=ticker,
            side=side,
            quantity=quantity,
            order_type=order_type,
            limit_price=limit_price,
        )
        
        # Estimate impact
        if liquidity_profile:
            order.estimated_impact = liquidity_profile.estimate_impact(quantity, limit_price or 0)
        
        if self.paper_mode:
            # Simulate immediate fill for paper trading
            order = self._simulate_fill(order, liquidity_profile)
        else:
            # Submit to actual broker
            order = self._submit_to_broker(order)
        
        if order.is_complete:
            self.completed_orders.append(order)
        else:
            self.pending_orders[order_id] = order
        
        return order
    
    def _simulate_fill(
        self,
        order: Order,
        liquidity_profile: Optional[LiquidityProfile],
    ) -> Order:
        """Simulate order fill for paper trading."""
        order.submitted_at = datetime.now()
        
        # Get current market price (would come from data feed)
        market_price = order.limit_price or 20.0  # Placeholder
        
        # Apply slippage based on impact estimate
        impact_pct = order.estimated_impact / 10000  # bps to decimal
        
        if order.side == "buy":
            fill_price = market_price * (1 + impact_pct)
        else:
            fill_price = market_price * (1 - impact_pct)
        
        # Add spread cost
        if liquidity_profile:
            spread_cost = liquidity_profile.avg_spread_pct / 2 / 100
            if order.side == "buy":
                fill_price *= (1 + spread_cost)
            else:
                fill_price *= (1 - spread_cost)
        
        order.filled_quantity = order.quantity
        order.avg_fill_price = fill_price
        order.status = OrderStatus.FILLED
        order.filled_at = datetime.now()
        
        order.fills.append({
            "quantity": order.quantity,
            "price": fill_price,
            "timestamp": datetime.now(),
        })
        
        logger.info(f"Paper fill: {order.side} {order.quantity} {order.ticker} @ ${fill_price:.2f}")
        
        return order
    
    def _submit_to_broker(self, order: Order) -> Order:
        """Submit order to actual broker."""
        if self.broker is None:
            raise ValueError("No broker client configured")
        
        # Would call broker API here
        # self.broker.submit_order(...)
        
        order.status = OrderStatus.SUBMITTED
        order.submitted_at = datetime.now()
        
        return order
    
    def cancel_order(self, order_id: str) -> bool:
        """Cancel a pending order."""
        if order_id not in self.pending_orders:
            return False
        
        order = self.pending_orders[order_id]
        
        if self.paper_mode:
            order.status = OrderStatus.CANCELLED
        else:
            # self.broker.cancel_order(order_id)
            pass
        
        del self.pending_orders[order_id]
        self.completed_orders.append(order)
        
        return True


class LiquidityManager:
    """
    Manages liquidity analysis and position sizing.
    """
    
    def __init__(self, data_provider):
        self.data = data_provider
        self.profiles: Dict[str, LiquidityProfile] = {}
    
    def get_liquidity_profile(self, ticker: str) -> LiquidityProfile:
        """Get or create liquidity profile for a ticker."""
        if ticker in self.profiles:
            return self.profiles[ticker]
        
        # Fetch volume data
        volume_data = self.data.get_volume_history(ticker, days=20)
        
        if volume_data:
            avg_volume = sum(v["volume"] for v in volume_data) / len(volume_data)
            avg_price = sum(v["close"] for v in volume_data) / len(volume_data)
            avg_value = avg_volume * avg_price
        else:
            avg_volume = 1_000_000  # Default
            avg_value = 20_000_000
        
        profile = LiquidityProfile(
            ticker=ticker,
            avg_daily_volume=avg_volume,
            avg_daily_value=avg_value,
            avg_spread_pct=0.10,  # 10 bps default
            avg_spread_cents=2.0,
        )
        
        self.profiles[ticker] = profile
        return profile
    
    def calculate_optimal_size(
        self,
        ticker: str,
        target_value: float,
        max_impact_bps: float = 25.0,
        max_participation_pct: float = 0.10,
    ) -> Dict[str, Any]:
        """
        Calculate optimal position size based on liquidity constraints.
        
        Args:
            ticker: Stock ticker
            target_value: Desired position value in dollars
            max_impact_bps: Maximum acceptable market impact
            max_participation_pct: Maximum % of ADV per day
            
        Returns:
            Sizing recommendation with execution schedule
        """
        profile = self.get_liquidity_profile(ticker)
        
        # Get current price
        current_price = self.data.get_price(ticker) or 20.0
        target_shares = int(target_value / current_price)
        
        # Check liquidity constraints
        
        # 1. Maximum shares based on participation rate
        max_daily_shares = int(profile.avg_daily_volume * max_participation_pct)
        days_needed = math.ceil(target_shares / max_daily_shares)
        
        # 2. Adjust for impact constraint
        impact = profile.estimate_impact(target_shares // days_needed, current_price)
        
        if impact > max_impact_bps:
            # Need more days to reduce impact
            while impact > max_impact_bps and days_needed < 20:
                days_needed += 1
                daily_shares = target_shares // days_needed
                impact = profile.estimate_impact(daily_shares, current_price)
        
        # 3. Maximum position based on liquidity
        max_shares = profile.max_position_shares(max_participation_pct, days=10)
        
        # Final sizing
        recommended_shares = min(target_shares, max_shares)
        recommended_value = recommended_shares * current_price
        
        # Execution schedule
        daily_shares = recommended_shares // max(days_needed, 1)
        schedule = []
        remaining = recommended_shares
        
        for day in range(days_needed):
            shares_today = min(daily_shares, remaining)
            schedule.append({
                "day": day + 1,
                "shares": shares_today,
                "pct_of_position": shares_today / recommended_shares if recommended_shares > 0 else 0,
                "expected_impact_bps": profile.estimate_impact(shares_today, current_price),
            })
            remaining -= shares_today
        
        return {
            "ticker": ticker,
            "target_shares": target_shares,
            "target_value": target_value,
            "recommended_shares": recommended_shares,
            "recommended_value": recommended_value,
            "reduction_reason": "liquidity" if recommended_shares < target_shares else None,
            "days_to_execute": days_needed,
            "daily_participation_pct": (daily_shares / profile.avg_daily_volume) * 100,
            "estimated_impact_bps": impact,
            "execution_schedule": schedule,
            "liquidity_profile": {
                "adv": profile.avg_daily_volume,
                "adv_value": profile.avg_daily_value,
                "spread_bps": profile.avg_spread_pct,
            },
        }


class EarningsCalendar:
    """
    Manages earnings calendar and trading blackouts.
    """
    
    def __init__(self, data_provider):
        self.data = data_provider
        self.calendar: Dict[str, List[EarningsCalendarEntry]] = {}
    
    def load_earnings_dates(self, tickers: List[str], lookahead_days: int = 90):
        """Load earnings dates for tickers."""
        for ticker in tickers:
            dates = self.data.get_earnings_dates(ticker, lookahead_days)
            
            entries = []
            for d in dates:
                entries.append(EarningsCalendarEntry(
                    ticker=ticker,
                    earnings_date=d.get("date", date.today()),
                    time_of_day=d.get("time", "unknown"),
                    consensus_eps=d.get("consensus"),
                ))
            
            self.calendar[ticker] = entries
    
    def get_next_earnings(self, ticker: str) -> Optional[EarningsCalendarEntry]:
        """Get next earnings date for a ticker."""
        if ticker not in self.calendar:
            return None
        
        today = date.today()
        for entry in self.calendar[ticker]:
            if entry.earnings_date >= today:
                return entry
        
        return None
    
    def days_until_earnings(self, ticker: str) -> Optional[int]:
        """Get days until next earnings."""
        next_earnings = self.get_next_earnings(ticker)
        if next_earnings:
            return (next_earnings.earnings_date - date.today()).days
        return None
    
    def is_in_blackout(self, ticker: str, trade_date: Optional[date] = None) -> bool:
        """Check if a ticker is in earnings blackout period."""
        trade_date = trade_date or date.today()
        next_earnings = self.get_next_earnings(ticker)
        
        if next_earnings:
            if next_earnings.blackout_start <= trade_date <= next_earnings.blackout_end:
                return True
        
        return False
    
    def get_trading_restriction(
        self,
        ticker: str,
        trade_date: Optional[date] = None,
    ) -> TradingRestriction:
        """Get current trading restriction for a ticker."""
        if self.is_in_blackout(ticker, trade_date):
            return TradingRestriction.EARNINGS_BLACKOUT
        
        return TradingRestriction.NONE


class EarningsTradingRules:
    """
    Earnings-specific trading rules.
    
    Implements:
    - Pre-earnings entry/exit windows
    - Post-earnings reaction handling
    - Gap risk management
    """
    
    def __init__(
        self,
        blackout_days_before: int = 3,
        blackout_days_after: int = 1,
        max_position_into_earnings: float = 0.5,  # Max 50% of normal size
    ):
        self.blackout_before = blackout_days_before
        self.blackout_after = blackout_days_after
        self.max_into_earnings = max_position_into_earnings
    
    def should_enter_position(
        self,
        ticker: str,
        trade_type: str,
        days_to_earnings: Optional[int],
        signal_strength: float,
    ) -> Tuple[bool, str]:
        """
        Determine if we should enter a position given earnings timing.
        
        Returns:
            Tuple of (should_trade, reason)
        """
        if days_to_earnings is None:
            return True, "no_earnings_scheduled"
        
        # Earnings surprise trades WANT to be in before earnings
        if trade_type == "earnings_surprise":
            if days_to_earnings <= 0:
                return False, "earnings_passed"
            if days_to_earnings <= self.blackout_before:
                # Too close - need to evaluate gap risk
                if signal_strength >= 0.8:
                    return True, "high_conviction_pre_earnings"
                return False, "too_close_to_earnings"
            if days_to_earnings <= 60:
                return True, "good_timing_for_earnings_play"
            return False, "too_far_from_earnings"
        
        # Re-rating trades should AVOID earnings gap risk
        elif trade_type == "re_rating":
            if days_to_earnings <= self.blackout_before:
                return False, "wait_until_after_earnings"
            return True, "ok_distance_from_earnings"
        
        return True, "no_specific_rule"
    
    def position_size_adjustment(
        self,
        days_to_earnings: Optional[int],
        trade_type: str,
    ) -> float:
        """
        Get position size multiplier based on earnings timing.
        
        Returns:
            Multiplier (0 to 1)
        """
        if days_to_earnings is None:
            return 1.0
        
        # Earnings surprise - full size into earnings
        if trade_type == "earnings_surprise":
            if 7 <= days_to_earnings <= 45:
                return 1.0  # Sweet spot
            elif days_to_earnings < 7:
                return 0.75  # Reduce size very close to earnings
            else:
                return 0.5  # Too far out
        
        # Re-rating - reduce size near earnings
        else:
            if days_to_earnings <= 7:
                return self.max_into_earnings
            elif days_to_earnings <= 14:
                return 0.75
            else:
                return 1.0
    
    def should_exit_after_earnings(
        self,
        trade_type: str,
        price_reaction_pct: float,
        eps_surprise_pct: Optional[float],
    ) -> Tuple[bool, str]:
        """
        Determine if we should exit after earnings announcement.
        
        Args:
            trade_type: Type of trade
            price_reaction_pct: Post-earnings price move
            eps_surprise_pct: Actual vs consensus surprise
            
        Returns:
            Tuple of (should_exit, reason)
        """
        # Earnings surprise trade
        if trade_type == "earnings_surprise":
            # Catalyst has played out - time to exit
            if price_reaction_pct > 0.15:
                return True, "target_achieved_post_earnings"
            if eps_surprise_pct and eps_surprise_pct < -0.10:
                return True, "earnings_disappointment"
            # Even if flat, catalyst is done
            return True, "catalyst_passed"
        
        # Re-rating trade - don't necessarily exit on earnings
        else:
            if price_reaction_pct < -0.15:
                return True, "large_negative_reaction"
            return False, "hold_through_earnings"


class ProductionOrderManager:
    """
    Production order management combining all execution components.
    """
    
    def __init__(
        self,
        execution_engine: ExecutionEngine,
        liquidity_manager: LiquidityManager,
        earnings_calendar: EarningsCalendar,
        earnings_rules: EarningsTradingRules,
    ):
        self.execution = execution_engine
        self.liquidity = liquidity_manager
        self.earnings = earnings_calendar
        self.rules = earnings_rules
    
    def prepare_order(
        self,
        ticker: str,
        side: str,
        target_value: float,
        trade_type: str,
        signal_strength: float,
    ) -> Dict[str, Any]:
        """
        Prepare an order with all production considerations.
        
        Returns:
            Order preparation result with sizing and schedule
        """
        result = {
            "ticker": ticker,
            "side": side,
            "approved": False,
            "sizing": None,
            "restrictions": [],
            "warnings": [],
        }
        
        # Check trading restrictions
        restriction = self.earnings.get_trading_restriction(ticker)
        if restriction != TradingRestriction.NONE:
            result["restrictions"].append(restriction.value)
        
        # Check earnings timing
        days_to_earnings = self.earnings.days_until_earnings(ticker)
        
        if side == "buy":
            should_enter, reason = self.rules.should_enter_position(
                ticker, trade_type, days_to_earnings, signal_strength
            )
            
            if not should_enter:
                result["restrictions"].append(f"earnings_timing: {reason}")
        
        # If we have blocking restrictions, don't approve
        if result["restrictions"]:
            return result
        
        # Get position sizing adjustment
        size_multiplier = self.rules.position_size_adjustment(days_to_earnings, trade_type)
        adjusted_target = target_value * size_multiplier
        
        if size_multiplier < 1.0:
            result["warnings"].append(f"Size reduced to {size_multiplier:.0%} due to earnings timing")
        
        # Calculate liquidity-aware sizing
        sizing = self.liquidity.calculate_optimal_size(
            ticker=ticker,
            target_value=adjusted_target,
        )
        
        result["sizing"] = sizing
        result["approved"] = True
        result["days_to_earnings"] = days_to_earnings
        
        return result
    
    def execute_order(
        self,
        preparation: Dict[str, Any],
        order_type: OrderType = OrderType.VWAP,
    ) -> Optional[Order]:
        """
        Execute a prepared order.
        
        Args:
            preparation: Result from prepare_order()
            order_type: Execution algorithm to use
            
        Returns:
            Executed order or None if not approved
        """
        if not preparation.get("approved"):
            logger.warning(f"Order not approved: {preparation.get('restrictions')}")
            return None
        
        sizing = preparation["sizing"]
        ticker = preparation["ticker"]
        
        # Get liquidity profile
        profile = self.liquidity.get_liquidity_profile(ticker)
        
        # Submit order
        order = self.execution.submit_order(
            ticker=ticker,
            side=preparation["side"],
            quantity=sizing["recommended_shares"],
            order_type=order_type,
            liquidity_profile=profile,
        )
        
        return order
