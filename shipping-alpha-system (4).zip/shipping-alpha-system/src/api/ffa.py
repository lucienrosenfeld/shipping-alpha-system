"""
Forward Freight Agreement (FFA) API client.

FFAs are derivatives that allow market participants to lock in or speculate
on future freight rates. This client fetches FFA forward curves for:
- Dry Bulk (Capesize, Panamax, Supramax)
- Tanker (VLCC, Suezmax, Aframax, Clean)

Data sources typically include:
- Clarkson Securities
- Freight Investor Services (FIS)
- SGX (Singapore Exchange)
- CME/NYMEX Freight Futures
"""

from datetime import date, datetime, timedelta
from typing import Dict, List, Optional, Any
from calendar import monthrange
import random

from loguru import logger

from .base import BaseAPIClient, APIError, MockDataMixin


class FFAClient(BaseAPIClient, MockDataMixin):
    """
    Client for Forward Freight Agreement data.
    
    Provides access to:
    - FFA forward curves
    - Settlement prices
    - Historical FFA data
    - Route-specific forwards
    
    Note: Requires broker/exchange API access.
    """
    
    # Route information for FFAs
    ROUTE_INFO = {
        # Dry Bulk - Capesize
        "C5TC": {
            "name": "Capesize 5TC Average",
            "segment": "capesize",
            "unit": "$/day",
            "typical_range": (5000, 50000),
        },
        "C3": {
            "name": "Tubarao to Qingdao",
            "segment": "capesize",
            "unit": "$/mt",
            "typical_range": (15, 40),
        },
        "C5": {
            "name": "W Australia to Qingdao",
            "segment": "capesize",
            "unit": "$/mt",
            "typical_range": (6, 15),
        },
        
        # Dry Bulk - Panamax
        "P5TC": {
            "name": "Panamax 5TC Average",
            "segment": "panamax",
            "unit": "$/day",
            "typical_range": (5000, 35000),
        },
        
        # Dry Bulk - Supramax
        "S10TC": {
            "name": "Supramax 10TC Average",
            "segment": "supramax",
            "unit": "$/day",
            "typical_range": (5000, 30000),
        },
        
        # Tanker - VLCC
        "TD3C": {
            "name": "AG to China VLCC",
            "segment": "vlcc",
            "unit": "$/mt",
            "typical_range": (5, 25),
        },
        
        # Tanker - Suezmax
        "TD20": {
            "name": "W Africa to UKC Suezmax",
            "segment": "suezmax",
            "unit": "WS",
            "typical_range": (50, 200),
        },
        
        # Tanker - Aframax
        "TD7": {
            "name": "North Sea to Cont Aframax",
            "segment": "aframax",
            "unit": "WS",
            "typical_range": (80, 250),
        },
        
        # Tanker - Clean (LR2/LR1)
        "TC1": {
            "name": "AG to Japan LR2",
            "segment": "lr2",
            "unit": "WS",
            "typical_range": (70, 220),
        },
    }
    
    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.ffabroker.example.com/v1",
    ):
        super().__init__(base_url=base_url, api_key=api_key, rate_limit=30)
        logger.info(f"FFAClient initialized (placeholder: {self.is_placeholder_key()})")
    
    def _add_auth_headers(self):
        """Add FFA broker authentication."""
        self.session.headers.update({
            "Authorization": f"Bearer {self.api_key}",
        })
    
    def health_check(self) -> bool:
        """Check API connectivity."""
        if self.is_placeholder_key():
            return True
        try:
            self.get("/health")
            return True
        except APIError:
            return False
    
    def get_forward_curve(
        self,
        route_code: str,
        as_of_date: Optional[date] = None,
        num_months: int = 12,
    ) -> Dict[str, Any]:
        """
        Get FFA forward curve for a route.
        
        Args:
            route_code: Route code (e.g., "C5TC", "TD3C")
            as_of_date: Valuation date (default: today)
            num_months: Number of forward months to retrieve
            
        Returns:
            Dict containing forward curve data
        """
        if self.is_placeholder_key():
            return self._generate_mock_curve(route_code, as_of_date, num_months)
        
        params = {
            "route": route_code,
            "months": num_months,
        }
        if as_of_date:
            params["date"] = as_of_date.isoformat()
        
        return self.get("/ffa/curve", params=params)
    
    def get_all_curves(
        self,
        segment: Optional[str] = None,
        as_of_date: Optional[date] = None,
        num_months: int = 12,
    ) -> Dict[str, Dict[str, Any]]:
        """
        Get forward curves for all routes (or filtered by segment).
        
        Args:
            segment: Optional segment filter ("capesize", "tanker", etc.)
            as_of_date: Valuation date
            num_months: Number of forward months
            
        Returns:
            Dict mapping route codes to their forward curves
        """
        results = {}
        
        for route_code, info in self.ROUTE_INFO.items():
            if segment and info["segment"] != segment:
                continue
            
            try:
                results[route_code] = self.get_forward_curve(route_code, as_of_date, num_months)
            except APIError as e:
                logger.warning(f"Failed to fetch {route_code}: {e}")
        
        return results
    
    def get_settlement(
        self,
        route_code: str,
        contract_month: date,
        as_of_date: Optional[date] = None,
    ) -> Dict[str, Any]:
        """
        Get FFA settlement price for a specific contract.
        
        Args:
            route_code: Route code
            contract_month: Contract settlement month (first of month)
            as_of_date: As-of date for the price
            
        Returns:
            Settlement price data
        """
        if self.is_placeholder_key():
            return self._generate_mock_settlement(route_code, contract_month, as_of_date)
        
        params = {
            "route": route_code,
            "contract": contract_month.isoformat()[:7],  # YYYY-MM format
        }
        if as_of_date:
            params["date"] = as_of_date.isoformat()
        
        return self.get("/ffa/settlement", params=params)
    
    def get_historical_curve(
        self,
        route_code: str,
        start_date: date,
        end_date: Optional[date] = None,
        contract_month: Optional[date] = None,
    ) -> List[Dict[str, Any]]:
        """
        Get historical FFA prices.
        
        Args:
            route_code: Route code
            start_date: Start of date range
            end_date: End of date range
            contract_month: Specific contract month to track
            
        Returns:
            List of historical prices
        """
        if self.is_placeholder_key():
            return self._generate_mock_history(route_code, start_date, end_date, contract_month)
        
        params = {
            "route": route_code,
            "start_date": start_date.isoformat(),
            "end_date": (end_date or date.today()).isoformat(),
        }
        if contract_month:
            params["contract"] = contract_month.isoformat()[:7]
        
        return self.get("/ffa/history", params=params)
    
    def calculate_fep_rate(
        self,
        route_code: str,
        periods: int = 4,
        as_of_date: Optional[date] = None,
    ) -> float:
        """
        Calculate Forward Earnings Power rate as weighted average of FFA curve.
        
        Args:
            route_code: Route code
            periods: Number of quarters to average
            as_of_date: Valuation date
            
        Returns:
            Weighted average forward rate
        """
        curve = self.get_forward_curve(route_code, as_of_date, periods * 3)
        
        if "curve" not in curve or not curve["curve"]:
            raise ValueError(f"No curve data available for {route_code}")
        
        # Weight front months more heavily
        total_weight = 0
        weighted_sum = 0
        
        for i, point in enumerate(curve["curve"]):
            # Declining weights: 1, 0.9, 0.8, ...
            weight = max(0.1, 1 - i * 0.1)
            weighted_sum += point["settlement"] * weight
            total_weight += weight
        
        return weighted_sum / total_weight if total_weight > 0 else 0
    
    # =========================================================================
    # Mock Data Generation
    # =========================================================================
    
    def _generate_mock_curve(
        self,
        route_code: str,
        as_of_date: Optional[date] = None,
        num_months: int = 12,
    ) -> Dict[str, Any]:
        """Generate mock forward curve."""
        info = self.ROUTE_INFO.get(route_code, {"typical_range": (5000, 20000), "unit": "$/day"})
        low, high = info["typical_range"]
        
        as_of = as_of_date or date.today()
        
        # Start with spot-ish value
        spot = (low + high) / 2 * random.uniform(0.8, 1.2)
        
        curve = []
        current_value = spot
        
        for i in range(num_months):
            # Calculate contract month (first of month)
            contract_month = date(as_of.year, as_of.month, 1)
            month_offset = i + 1
            year_add, new_month = divmod(contract_month.month + month_offset - 1, 12)
            new_month += 1
            contract_date = date(contract_month.year + year_add, new_month, 1)
            
            # Forward curve typically shows mean reversion
            mean = (low + high) / 2
            reversion = (mean - current_value) * 0.05  # 5% reversion per month
            drift = random.uniform(-0.02, 0.02) * current_value
            current_value = current_value + reversion + drift
            current_value = max(low * 0.5, min(high * 1.5, current_value))
            
            # Add some seasonality (rough approximation)
            seasonal_factor = 1.0
            if contract_date.month in [1, 2, 3]:  # Q1 often weaker for dry bulk
                seasonal_factor = 0.95
            elif contract_date.month in [9, 10, 11]:  # Q4 often stronger
                seasonal_factor = 1.05
            
            curve.append({
                "contract_month": contract_date.isoformat()[:7],
                "settlement": round(current_value * seasonal_factor, 2),
                "bid": round(current_value * seasonal_factor * 0.98, 2),
                "ask": round(current_value * seasonal_factor * 1.02, 2),
            })
        
        return {
            "route_code": route_code,
            "route_name": info.get("name", route_code),
            "segment": info.get("segment", "unknown"),
            "unit": info.get("unit", "$/day"),
            "as_of_date": as_of.isoformat(),
            "spot_rate": round(spot, 2),
            "curve": curve,
            "_mock": True,
        }
    
    def _generate_mock_settlement(
        self,
        route_code: str,
        contract_month: date,
        as_of_date: Optional[date] = None,
    ) -> Dict[str, Any]:
        """Generate mock settlement price."""
        info = self.ROUTE_INFO.get(route_code, {"typical_range": (5000, 20000), "unit": "$/day"})
        low, high = info["typical_range"]
        
        value = (low + high) / 2 * random.uniform(0.8, 1.2)
        
        return {
            "route_code": route_code,
            "contract_month": contract_month.isoformat()[:7],
            "as_of_date": (as_of_date or date.today()).isoformat(),
            "settlement": round(value, 2),
            "open_interest": random.randint(100, 5000),
            "volume": random.randint(10, 500),
            "_mock": True,
        }
    
    def _generate_mock_history(
        self,
        route_code: str,
        start_date: date,
        end_date: Optional[date] = None,
        contract_month: Optional[date] = None,
    ) -> List[Dict[str, Any]]:
        """Generate mock historical FFA prices."""
        end = end_date or date.today()
        info = self.ROUTE_INFO.get(route_code, {"typical_range": (5000, 20000)})
        low, high = info["typical_range"]
        
        history = []
        current_value = (low + high) / 2
        current_date = start_date
        
        while current_date <= end:
            if current_date.weekday() < 5:  # Skip weekends
                drift = random.uniform(-0.03, 0.03)
                mean_reversion = ((low + high) / 2 - current_value) * 0.02
                current_value = current_value * (1 + drift + mean_reversion)
                current_value = max(low * 0.5, min(high * 1.5, current_value))
                
                history.append({
                    "date": current_date.isoformat(),
                    "route_code": route_code,
                    "contract_month": (contract_month or date(current_date.year, current_date.month, 1)).isoformat()[:7],
                    "settlement": round(current_value, 2),
                    "_mock": True,
                })
            
            current_date += timedelta(days=1)
        
        return history
