"""
Base API client with common functionality.
"""

import time
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional
from datetime import datetime, date
import requests
from loguru import logger


class APIError(Exception):
    """Custom exception for API errors."""
    
    def __init__(self, message: str, status_code: Optional[int] = None, response: Optional[Dict] = None):
        self.message = message
        self.status_code = status_code
        self.response = response
        super().__init__(self.message)


class RateLimiter:
    """Simple rate limiter for API calls."""
    
    def __init__(self, calls_per_minute: int = 60):
        self.calls_per_minute = calls_per_minute
        self.min_interval = 60.0 / calls_per_minute
        self.last_call_time = 0.0
    
    def wait(self):
        """Wait if necessary to respect rate limit."""
        elapsed = time.time() - self.last_call_time
        if elapsed < self.min_interval:
            time.sleep(self.min_interval - elapsed)
        self.last_call_time = time.time()


class BaseAPIClient(ABC):
    """Base class for all API clients."""
    
    def __init__(
        self,
        base_url: str,
        api_key: Optional[str] = None,
        rate_limit: int = 60,
        timeout: int = 30,
    ):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout
        self.rate_limiter = RateLimiter(rate_limit)
        self.session = requests.Session()
        self._setup_session()
    
    def _setup_session(self):
        """Setup session with default headers."""
        self.session.headers.update({
            "Accept": "application/json",
            "Content-Type": "application/json",
        })
        if self.api_key:
            self._add_auth_headers()
    
    @abstractmethod
    def _add_auth_headers(self):
        """Add authentication headers. Override in subclasses."""
        pass
    
    def _make_request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict] = None,
        data: Optional[Dict] = None,
        **kwargs,
    ) -> Dict[str, Any]:
        """Make an API request with rate limiting and error handling."""
        
        self.rate_limiter.wait()
        
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        
        try:
            response = self.session.request(
                method=method,
                url=url,
                params=params,
                json=data,
                timeout=self.timeout,
                **kwargs,
            )
            
            if response.status_code >= 400:
                raise APIError(
                    message=f"API error: {response.status_code}",
                    status_code=response.status_code,
                    response=response.json() if response.content else None,
                )
            
            return response.json() if response.content else {}
            
        except requests.exceptions.Timeout:
            raise APIError(f"Request timeout for {url}")
        except requests.exceptions.ConnectionError:
            raise APIError(f"Connection error for {url}")
        except requests.exceptions.JSONDecodeError:
            raise APIError(f"Invalid JSON response from {url}")
    
    def get(self, endpoint: str, params: Optional[Dict] = None, **kwargs) -> Dict[str, Any]:
        """Make a GET request."""
        return self._make_request("GET", endpoint, params=params, **kwargs)
    
    def post(self, endpoint: str, data: Optional[Dict] = None, **kwargs) -> Dict[str, Any]:
        """Make a POST request."""
        return self._make_request("POST", endpoint, data=data, **kwargs)
    
    @abstractmethod
    def health_check(self) -> bool:
        """Check if the API is accessible."""
        pass
    
    def is_placeholder_key(self) -> bool:
        """Check if using placeholder API key."""
        return self.api_key is None or self.api_key.startswith("PLACEHOLDER")


class MockDataMixin:
    """Mixin to provide mock data when API is unavailable."""
    
    def _generate_mock_data(self, data_type: str, **kwargs) -> Any:
        """Generate mock data for testing. Override in subclasses."""
        raise NotImplementedError("Mock data generation not implemented")
