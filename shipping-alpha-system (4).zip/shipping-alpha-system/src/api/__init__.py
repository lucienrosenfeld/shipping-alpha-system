"""
API clients for external data sources.

This module provides clients for:
- Baltic Exchange: Freight indices (BDI, BDTI, etc.)
- FFA Broker: Forward freight agreements
- Equity Data: Stock prices and fundamentals
- Bunker Prices: Marine fuel prices
- Macro Data: VIX, S&P 500, etc.
"""

from .base import BaseAPIClient, APIError, RateLimiter, MockDataMixin
from .baltic import BalticExchangeClient
from .ffa import FFAClient
from .equity import EquityDataClient, MacroDataClient
from .bunker import BunkerPriceClient

__all__ = [
    # Base classes
    "BaseAPIClient",
    "APIError",
    "RateLimiter",
    "MockDataMixin",
    
    # Clients
    "BalticExchangeClient",
    "FFAClient",
    "EquityDataClient",
    "MacroDataClient",
    "BunkerPriceClient",
]


def create_clients(settings):
    """
    Factory function to create all API clients from settings.
    
    Args:
        settings: Application settings object
        
    Returns:
        Dict of initialized API clients
    """
    return {
        "baltic": BalticExchangeClient(
            api_key=settings.baltic.api_key,
            base_url=settings.baltic.base_url,
        ),
        "ffa": FFAClient(
            api_key=settings.ffa.api_key,
            base_url=settings.ffa.base_url,
        ),
        "equity": EquityDataClient(
            alpha_vantage_key=settings.equity.alpha_vantage_api_key,
            polygon_key=settings.equity.polygon_api_key,
        ),
        "macro": MacroDataClient(
            fred_api_key=settings.macro.fred_api_key,
        ),
        "bunker": BunkerPriceClient(
            api_key=settings.bunker.api_key,
        ),
    }
