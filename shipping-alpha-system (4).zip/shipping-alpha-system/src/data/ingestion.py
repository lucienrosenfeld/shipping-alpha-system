"""
Data ingestion and storage module.

Handles:
- Fetching data from APIs
- Storing in database
- Data validation and cleaning
- Scheduled updates
"""

from datetime import date, datetime, timedelta
from typing import Dict, List, Optional, Any
import json

from loguru import logger
from sqlalchemy.orm import Session

from ..api import (
    BalticExchangeClient,
    FFAClient,
    EquityDataClient,
    MacroDataClient,
    BunkerPriceClient,
)
from ..models import (
    Company,
    Vessel,
    Charter,
    FreightIndex,
    FFAPrice,
    BunkerPrice,
    EquityPrice,
    MacroIndicator,
    Financial,
)


class DataIngestionService:
    """
    Central service for ingesting data from all sources.
    """
    
    def __init__(
        self,
        session: Session,
        baltic_client: BalticExchangeClient,
        ffa_client: FFAClient,
        equity_client: EquityDataClient,
        macro_client: MacroDataClient,
        bunker_client: BunkerPriceClient,
    ):
        self.session = session
        self.baltic = baltic_client
        self.ffa = ffa_client
        self.equity = equity_client
        self.macro = macro_client
        self.bunker = bunker_client
    
    def ingest_freight_indices(self, as_of_date: Optional[date] = None) -> int:
        """
        Ingest freight index data.
        
        Args:
            as_of_date: Date for indices (default: today)
            
        Returns:
            Number of records inserted
        """
        target_date = as_of_date or date.today()
        count = 0
        
        try:
            indices = self.baltic.get_all_indices(target_date)
            
            for index_code, data in indices.items():
                # Check if already exists
                existing = self.session.query(FreightIndex).filter(
                    FreightIndex.date == target_date,
                    FreightIndex.index_code == index_code
                ).first()
                
                if existing:
                    # Update existing
                    existing.value = data.get("value", 0)
                    existing.change = data.get("change")
                    existing.change_pct = data.get("change_pct")
                    existing.tce_equivalent = data.get("tce_equivalent")
                else:
                    # Insert new
                    record = FreightIndex(
                        date=target_date,
                        index_code=index_code,
                        value=data.get("value", 0),
                        change=data.get("change"),
                        change_pct=data.get("change_pct"),
                        tce_equivalent=data.get("tce_equivalent"),
                    )
                    self.session.add(record)
                    count += 1
            
            self.session.commit()
            logger.info(f"Ingested {count} freight index records for {target_date}")
            
        except Exception as e:
            self.session.rollback()
            logger.error(f"Error ingesting freight indices: {e}")
            raise
        
        return count
    
    def ingest_ffa_curves(
        self,
        route_codes: Optional[List[str]] = None,
        as_of_date: Optional[date] = None,
    ) -> int:
        """
        Ingest FFA forward curve data.
        
        Args:
            route_codes: Specific routes to fetch
            as_of_date: Date for curves
            
        Returns:
            Number of records inserted
        """
        target_date = as_of_date or date.today()
        count = 0
        
        try:
            if route_codes:
                curves = {code: self.ffa.get_forward_curve(code, target_date) 
                         for code in route_codes}
            else:
                curves = self.ffa.get_all_curves(as_of_date=target_date)
            
            for route_code, curve_data in curves.items():
                if "curve" not in curve_data:
                    continue
                
                for point in curve_data["curve"]:
                    contract_month = datetime.strptime(
                        point["contract_month"], "%Y-%m"
                    ).date()
                    
                    existing = self.session.query(FFAPrice).filter(
                        FFAPrice.date == target_date,
                        FFAPrice.route_code == route_code,
                        FFAPrice.contract_month == contract_month
                    ).first()
                    
                    if existing:
                        existing.bid = point.get("bid")
                        existing.ask = point.get("ask")
                        existing.settlement = point.get("settlement")
                    else:
                        record = FFAPrice(
                            date=target_date,
                            route_code=route_code,
                            contract_month=contract_month,
                            bid=point.get("bid"),
                            ask=point.get("ask"),
                            settlement=point.get("settlement"),
                        )
                        self.session.add(record)
                        count += 1
            
            self.session.commit()
            logger.info(f"Ingested {count} FFA records for {target_date}")
            
        except Exception as e:
            self.session.rollback()
            logger.error(f"Error ingesting FFA curves: {e}")
            raise
        
        return count
    
    def ingest_equity_prices(
        self,
        tickers: List[str],
        as_of_date: Optional[date] = None,
    ) -> int:
        """
        Ingest equity price data.
        
        Args:
            tickers: List of tickers to fetch
            as_of_date: Date for prices
            
        Returns:
            Number of records inserted
        """
        target_date = as_of_date or date.today()
        count = 0
        
        try:
            prices = self.equity.get_bulk_prices(tickers, target_date)
            
            for ticker, data in prices.items():
                if "error" in data:
                    logger.warning(f"Skipping {ticker}: {data['error']}")
                    continue
                
                price_date = datetime.fromisoformat(data["date"]).date() \
                    if isinstance(data["date"], str) else data["date"]
                
                existing = self.session.query(EquityPrice).filter(
                    EquityPrice.date == price_date,
                    EquityPrice.ticker == ticker
                ).first()
                
                if existing:
                    existing.open = data.get("open")
                    existing.high = data.get("high")
                    existing.low = data.get("low")
                    existing.close = data.get("close")
                    existing.volume = data.get("volume")
                else:
                    record = EquityPrice(
                        date=price_date,
                        ticker=ticker,
                        open=data.get("open"),
                        high=data.get("high"),
                        low=data.get("low"),
                        close=data.get("close"),
                        adjusted_close=data.get("adjusted_close"),
                        volume=data.get("volume"),
                    )
                    self.session.add(record)
                    count += 1
            
            self.session.commit()
            logger.info(f"Ingested {count} equity price records")
            
        except Exception as e:
            self.session.rollback()
            logger.error(f"Error ingesting equity prices: {e}")
            raise
        
        return count
    
    def ingest_macro_indicators(self, as_of_date: Optional[date] = None) -> int:
        """
        Ingest macro indicator data.
        
        Args:
            as_of_date: Date for indicators
            
        Returns:
            Number of records inserted
        """
        target_date = as_of_date or date.today()
        count = 0
        
        try:
            indicators = self.macro.get_all_indicators(target_date)
            
            for indicator, data in indicators.items():
                indicator_date = datetime.fromisoformat(data["date"]).date() \
                    if isinstance(data["date"], str) else data["date"]
                
                existing = self.session.query(MacroIndicator).filter(
                    MacroIndicator.date == indicator_date,
                    MacroIndicator.indicator_code == indicator
                ).first()
                
                if existing:
                    existing.value = data.get("value", 0)
                else:
                    record = MacroIndicator(
                        date=indicator_date,
                        indicator_code=indicator,
                        value=data.get("value", 0),
                    )
                    self.session.add(record)
                    count += 1
            
            self.session.commit()
            logger.info(f"Ingested {count} macro indicator records")
            
        except Exception as e:
            self.session.rollback()
            logger.error(f"Error ingesting macro indicators: {e}")
            raise
        
        return count
    
    def ingest_bunker_prices(
        self,
        fuel_types: List[str] = None,
        as_of_date: Optional[date] = None,
    ) -> int:
        """
        Ingest bunker price data.
        
        Args:
            fuel_types: Fuel types to fetch
            as_of_date: Date for prices
            
        Returns:
            Number of records inserted
        """
        target_date = as_of_date or date.today()
        fuel_types = fuel_types or ["VLSFO", "MGO", "HSFO"]
        count = 0
        
        try:
            for fuel_type in fuel_types:
                prices = self.bunker.get_all_prices(fuel_type, target_date)
                
                for port, data in prices.items():
                    existing = self.session.query(BunkerPrice).filter(
                        BunkerPrice.date == target_date,
                        BunkerPrice.port == port,
                        BunkerPrice.fuel_type == fuel_type
                    ).first()
                    
                    if existing:
                        existing.price = data.get("price", 0)
                    else:
                        record = BunkerPrice(
                            date=target_date,
                            port=port,
                            fuel_type=fuel_type,
                            price=data.get("price", 0),
                        )
                        self.session.add(record)
                        count += 1
            
            self.session.commit()
            logger.info(f"Ingested {count} bunker price records")
            
        except Exception as e:
            self.session.rollback()
            logger.error(f"Error ingesting bunker prices: {e}")
            raise
        
        return count
    
    def ingest_all_daily(self, tickers: List[str], as_of_date: Optional[date] = None) -> Dict[str, int]:
        """
        Run all daily ingestion tasks.
        
        Args:
            tickers: List of equity tickers
            as_of_date: Date to ingest
            
        Returns:
            Dict of counts by data type
        """
        results = {}
        
        logger.info(f"Starting daily data ingestion for {as_of_date or date.today()}")
        
        results["freight_indices"] = self.ingest_freight_indices(as_of_date)
        results["ffa_curves"] = self.ingest_ffa_curves(as_of_date=as_of_date)
        results["equity_prices"] = self.ingest_equity_prices(tickers, as_of_date)
        results["macro_indicators"] = self.ingest_macro_indicators(as_of_date)
        results["bunker_prices"] = self.ingest_bunker_prices(as_of_date=as_of_date)
        
        logger.info(f"Daily ingestion complete: {results}")
        
        return results
    
    def backfill_history(
        self,
        tickers: List[str],
        start_date: date,
        end_date: Optional[date] = None,
    ) -> Dict[str, int]:
        """
        Backfill historical data.
        
        Args:
            tickers: List of tickers
            start_date: Start date
            end_date: End date
            
        Returns:
            Dict of counts
        """
        end_date = end_date or date.today()
        results = {"equity": 0, "freight": 0}
        
        logger.info(f"Starting historical backfill from {start_date} to {end_date}")
        
        # Backfill equity prices
        for ticker in tickers:
            try:
                history = self.equity.get_price_history(ticker, start_date, end_date)
                
                for data in history:
                    price_date = data["date"] if isinstance(data["date"], date) \
                        else datetime.fromisoformat(str(data["date"])).date()
                    
                    existing = self.session.query(EquityPrice).filter(
                        EquityPrice.date == price_date,
                        EquityPrice.ticker == ticker
                    ).first()
                    
                    if not existing:
                        record = EquityPrice(
                            date=price_date,
                            ticker=ticker,
                            open=data.get("open"),
                            high=data.get("high"),
                            low=data.get("low"),
                            close=data.get("close"),
                            volume=data.get("volume"),
                        )
                        self.session.add(record)
                        results["equity"] += 1
                
            except Exception as e:
                logger.warning(f"Failed to backfill {ticker}: {e}")
        
        # Backfill freight indices
        for index_code in ["BDI", "BCI", "BPI", "BDTI", "BCTI"]:
            try:
                history = self.baltic.get_index_history(index_code, start_date, end_date)
                
                for data in history:
                    index_date = datetime.fromisoformat(data["date"]).date() \
                        if isinstance(data["date"], str) else data["date"]
                    
                    existing = self.session.query(FreightIndex).filter(
                        FreightIndex.date == index_date,
                        FreightIndex.index_code == index_code
                    ).first()
                    
                    if not existing:
                        record = FreightIndex(
                            date=index_date,
                            index_code=index_code,
                            value=data.get("value", 0),
                            tce_equivalent=data.get("tce_equivalent"),
                        )
                        self.session.add(record)
                        results["freight"] += 1
                
            except Exception as e:
                logger.warning(f"Failed to backfill {index_code}: {e}")
        
        self.session.commit()
        logger.info(f"Historical backfill complete: {results}")
        
        return results


class CompanyDataService:
    """
    Service for managing company, vessel, and charter data.
    """
    
    def __init__(self, session: Session):
        self.session = session
    
    def get_or_create_company(self, ticker: str, **kwargs) -> Company:
        """Get existing company or create new one."""
        company = self.session.query(Company).filter(
            Company.ticker == ticker
        ).first()
        
        if not company:
            company = Company(ticker=ticker, **kwargs)
            self.session.add(company)
            self.session.commit()
        
        return company
    
    def update_company(self, ticker: str, **kwargs) -> Company:
        """Update company data."""
        company = self.session.query(Company).filter(
            Company.ticker == ticker
        ).first()
        
        if not company:
            raise ValueError(f"Company {ticker} not found")
        
        for key, value in kwargs.items():
            if hasattr(company, key):
                setattr(company, key, value)
        
        self.session.commit()
        return company
    
    def add_vessel(
        self,
        company_id: int,
        vessel_type: str,
        **kwargs
    ) -> Vessel:
        """Add vessel to company fleet."""
        vessel = Vessel(
            company_id=company_id,
            vessel_type=vessel_type,
            **kwargs
        )
        self.session.add(vessel)
        self.session.commit()
        return vessel
    
    def add_charter(
        self,
        company_id: int,
        charter_type: str,
        daily_rate: float,
        start_date: date,
        **kwargs
    ) -> Charter:
        """Add charter contract."""
        charter = Charter(
            company_id=company_id,
            charter_type=charter_type,
            daily_rate=daily_rate,
            start_date=start_date,
            **kwargs
        )
        self.session.add(charter)
        self.session.commit()
        return charter
    
    def get_active_fleet(self, company_id: int) -> List[Vessel]:
        """Get active vessels for company."""
        return self.session.query(Vessel).filter(
            Vessel.company_id == company_id,
            Vessel.active == True
        ).all()
    
    def get_active_charters(
        self,
        company_id: int,
        as_of_date: Optional[date] = None
    ) -> List[Charter]:
        """Get active charter contracts."""
        as_of = as_of_date or date.today()
        
        return self.session.query(Charter).filter(
            Charter.company_id == company_id,
            Charter.start_date <= as_of,
            (Charter.end_date == None) | (Charter.end_date >= as_of)
        ).all()
    
    def import_fleet_from_json(self, company_id: int, fleet_data: List[Dict]) -> int:
        """
        Import fleet data from JSON.
        
        Args:
            company_id: Company ID
            fleet_data: List of vessel dicts
            
        Returns:
            Number of vessels imported
        """
        count = 0
        for vessel_data in fleet_data:
            vessel = Vessel(
                company_id=company_id,
                imo_number=vessel_data.get("imo"),
                name=vessel_data.get("name"),
                vessel_type=vessel_data.get("type"),
                dwt=vessel_data.get("dwt"),
                teu=vessel_data.get("teu"),
                built_year=vessel_data.get("built"),
                daily_opex=vessel_data.get("daily_opex", 5000),
                active=True,
            )
            self.session.add(vessel)
            count += 1
        
        self.session.commit()
        return count
    
    def import_charters_from_json(self, company_id: int, charter_data: List[Dict]) -> int:
        """
        Import charter data from JSON.
        
        Args:
            company_id: Company ID
            charter_data: List of charter dicts
            
        Returns:
            Number of charters imported
        """
        count = 0
        for charter in charter_data:
            # Find vessel if IMO provided
            vessel_id = None
            if "imo" in charter:
                vessel = self.session.query(Vessel).filter(
                    Vessel.imo_number == charter["imo"]
                ).first()
                if vessel:
                    vessel_id = vessel.id
            
            record = Charter(
                company_id=company_id,
                vessel_id=vessel_id,
                charter_type=charter.get("type", "time_charter"),
                daily_rate=charter["rate"],
                start_date=datetime.fromisoformat(charter["start"]).date(),
                end_date=datetime.fromisoformat(charter["end"]).date() if charter.get("end") else None,
            )
            self.session.add(record)
            count += 1
        
        self.session.commit()
        return count
