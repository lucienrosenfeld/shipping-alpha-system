"""
Charter Book Ingestion Pipeline

Parses and extracts fleet/charter data from:
1. SEC filings (10-Q, 10-K, 20-F, 6-K)
2. Investor presentations
3. Fleet status reports
4. Press releases

Outputs normalized vessel + charter tables for the signal engine.
"""

import re
import json
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from enum import Enum
import hashlib

from loguru import logger


class FilingType(Enum):
    """SEC filing types."""
    FORM_10Q = "10-Q"
    FORM_10K = "10-K"
    FORM_20F = "20-F"
    FORM_6K = "6-K"
    PRESS_RELEASE = "8-K"
    INVESTOR_PRESENTATION = "presentation"


class EventType(Enum):
    """Fleet/charter event types."""
    NEW_CHARTER = "new_charter"
    CHARTER_EXTENSION = "charter_extension"
    CHARTER_TERMINATION = "charter_termination"
    VESSEL_ACQUISITION = "vessel_acquisition"
    VESSEL_SALE = "vessel_sale"
    VESSEL_DELIVERY = "vessel_delivery"
    DRYDOCK_START = "drydock_start"
    DRYDOCK_END = "drydock_end"
    SCRAPPING = "scrapping"


@dataclass
class ParsedVessel:
    """Extracted vessel information."""
    name: str
    vessel_type: str
    imo_number: Optional[str] = None
    dwt: Optional[float] = None
    teu: Optional[float] = None
    built_year: Optional[int] = None
    flag: Optional[str] = None
    
    # Extracted from filing
    source_filing: Optional[str] = None
    extraction_date: Optional[date] = None
    confidence: float = 1.0  # 0-1 confidence in extraction
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "vessel_type": self.vessel_type,
            "imo_number": self.imo_number,
            "dwt": self.dwt,
            "teu": self.teu,
            "built_year": self.built_year,
            "flag": self.flag,
            "source": self.source_filing,
            "confidence": self.confidence,
        }


@dataclass
class ParsedCharter:
    """Extracted charter contract information."""
    vessel_name: str
    charter_type: str  # "time_charter", "spot", "bareboat", "coa"
    daily_rate: Optional[float] = None
    rate_type: str = "gross"  # "gross" or "net"
    
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    duration_description: Optional[str] = None  # e.g., "12 months +/- 30 days"
    
    charterer: Optional[str] = None
    has_extension_option: bool = False
    extension_terms: Optional[str] = None
    
    profit_share: bool = False
    profit_share_pct: Optional[float] = None
    index_linked: bool = False
    index_link_description: Optional[str] = None
    
    # Extraction metadata
    source_filing: Optional[str] = None
    source_text: Optional[str] = None
    extraction_date: Optional[date] = None
    confidence: float = 1.0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "vessel_name": self.vessel_name,
            "charter_type": self.charter_type,
            "daily_rate": self.daily_rate,
            "rate_type": self.rate_type,
            "start_date": self.start_date.isoformat() if self.start_date else None,
            "end_date": self.end_date.isoformat() if self.end_date else None,
            "duration": self.duration_description,
            "charterer": self.charterer,
            "has_extension": self.has_extension_option,
            "profit_share": self.profit_share,
            "index_linked": self.index_linked,
            "confidence": self.confidence,
        }


@dataclass
class FleetEvent:
    """Fleet or charter event extracted from filing."""
    event_type: EventType
    event_date: date
    vessel_name: str
    
    # Event-specific details
    details: Dict[str, Any] = field(default_factory=dict)
    
    # Source
    source_filing: Optional[str] = None
    source_text: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "event_type": self.event_type.value,
            "date": self.event_date.isoformat(),
            "vessel": self.vessel_name,
            "details": self.details,
            "source": self.source_filing,
        }


@dataclass
class IngestionResult:
    """Result of parsing a filing."""
    ticker: str
    filing_type: FilingType
    filing_date: date
    
    vessels: List[ParsedVessel] = field(default_factory=list)
    charters: List[ParsedCharter] = field(default_factory=list)
    events: List[FleetEvent] = field(default_factory=list)
    
    # Metrics
    total_fleet_count: int = 0
    vessels_on_charter: int = 0
    vessels_on_spot: int = 0
    avg_charter_rate: Optional[float] = None
    
    # Quality
    parsing_confidence: float = 1.0
    warnings: List[str] = field(default_factory=list)


class FilingParser:
    """
    Base class for SEC filing parsers.
    
    Extracts fleet and charter information from various filing formats.
    """
    
    # Common vessel type patterns
    VESSEL_TYPES = {
        r"capesize": "capesize",
        r"cape\s*size": "capesize",
        r"newcastlemax": "capesize",
        r"panamax": "panamax",
        r"kamsarmax": "panamax",
        r"post.?panamax": "panamax",
        r"supramax": "supramax",
        r"ultramax": "supramax",
        r"handysize": "handysize",
        r"handymax": "handysize",
        r"vlcc": "vlcc",
        r"suezmax": "suezmax",
        r"aframax": "aframax",
        r"lr2": "lr2",
        r"lr1": "lr1",
        r"mr\s*tanker": "mr_tanker",
        r"mr2": "mr_tanker",
        r"container": "container",
        r"lng": "lng_carrier",
        r"lpg": "lpg_carrier",
    }
    
    # Charter rate patterns
    RATE_PATTERNS = [
        r"\$\s*([\d,]+)\s*(?:per day|/day|daily)",
        r"([\d,]+)\s*(?:USD|US\$)\s*(?:per day|/day|daily)",
        r"(?:rate of|charter rate|tce of)\s*\$?\s*([\d,]+)",
        r"\$\s*([\d,]+)\s*(?:gross|net)",
    ]
    
    # Date patterns
    DATE_PATTERNS = [
        r"(\w+\s+\d{1,2},?\s+\d{4})",  # January 15, 2024
        r"(\d{1,2}/\d{1,2}/\d{4})",     # 1/15/2024
        r"(\d{4}-\d{2}-\d{2})",          # 2024-01-15
        r"(Q[1-4]\s+\d{4})",             # Q1 2024
    ]
    
    def __init__(self):
        self.vessel_type_regex = {
            k: re.compile(k, re.IGNORECASE) 
            for k in self.VESSEL_TYPES.keys()
        }
    
    def parse(self, text: str, filing_info: Dict[str, Any]) -> IngestionResult:
        """
        Parse filing text and extract fleet/charter data.
        
        Args:
            text: Filing text content
            filing_info: Metadata (ticker, filing_type, date, etc.)
            
        Returns:
            IngestionResult with extracted data
        """
        result = IngestionResult(
            ticker=filing_info.get("ticker", ""),
            filing_type=filing_info.get("filing_type", FilingType.FORM_10Q),
            filing_date=filing_info.get("filing_date", date.today()),
        )
        
        # Extract fleet table
        result.vessels = self._extract_fleet_table(text, filing_info)
        
        # Extract charter information
        result.charters = self._extract_charters(text, filing_info)
        
        # Extract events
        result.events = self._extract_events(text, filing_info)
        
        # Calculate summary metrics
        self._calculate_metrics(result)
        
        return result
    
    def _extract_fleet_table(
        self,
        text: str,
        filing_info: Dict[str, Any],
    ) -> List[ParsedVessel]:
        """Extract fleet list from filing."""
        vessels = []
        
        # Look for fleet table sections
        fleet_section = self._find_section(text, [
            r"fleet\s*list",
            r"our\s*fleet",
            r"vessel\s*schedule",
            r"owned\s*vessels",
        ])
        
        if not fleet_section:
            fleet_section = text
        
        # Extract vessel names and types
        # Pattern: vessel name followed by vessel type or DWT
        vessel_patterns = [
            # "M/V Star Polaris, a 2016-built Capesize"
            r"(?:M/V|MV|MT|)\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s*,?\s*(?:a\s+)?(\d{4})[- ]built\s+(\w+)",
            # "Star Polaris (Capesize, 181,000 DWT)"
            r"([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s*\((\w+),?\s*([\d,]+)\s*DWT\)",
            # Table row: "Star Polaris | Capesize | 181,000 | 2016"
            r"([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s*[|\t]\s*(\w+)\s*[|\t]\s*([\d,]+)",
        ]
        
        for pattern in vessel_patterns:
            matches = re.finditer(pattern, fleet_section, re.IGNORECASE)
            for match in matches:
                groups = match.groups()
                
                vessel = ParsedVessel(
                    name=groups[0].strip(),
                    vessel_type=self._normalize_vessel_type(groups[1] if len(groups) > 1 else ""),
                    source_filing=filing_info.get("filing_id"),
                    extraction_date=date.today(),
                )
                
                # Try to extract DWT
                if len(groups) > 2:
                    try:
                        vessel.dwt = float(groups[2].replace(",", ""))
                    except ValueError:
                        pass
                
                # Try to extract built year
                year_match = re.search(r"\b(19|20)\d{2}\b", match.group())
                if year_match:
                    vessel.built_year = int(year_match.group())
                
                vessels.append(vessel)
        
        # Deduplicate by name
        seen = set()
        unique_vessels = []
        for v in vessels:
            if v.name not in seen:
                seen.add(v.name)
                unique_vessels.append(v)
        
        return unique_vessels
    
    def _extract_charters(
        self,
        text: str,
        filing_info: Dict[str, Any],
    ) -> List[ParsedCharter]:
        """Extract charter contract information."""
        charters = []
        
        # Look for charter sections
        charter_section = self._find_section(text, [
            r"charter\s*(?:employment|arrangements|contracts)",
            r"time\s*charter",
            r"employment\s*of\s*(?:our\s*)?fleet",
        ])
        
        if not charter_section:
            charter_section = text
        
        # Pattern: "Vessel Name is employed on a time charter at $X per day until Date"
        charter_patterns = [
            # "Star Polaris is on time charter to ABC Corp at $25,000/day until March 2025"
            r"([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s+(?:is\s+)?(?:on|employed\s+on)\s+(time\s*charter|spot|bareboat)\s+(?:to\s+)?([A-Za-z\s]+)?\s*(?:at\s+)?\$?([\d,]+)\s*(?:per\s*day|/day)?\s*(?:until|through|expiring)?\s*(\w+\s+\d{4})?",
            
            # Table format: "Star Polaris | Time Charter | $25,000 | ABC Corp | Mar 2025"
            r"([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s*[|\t]\s*(Time Charter|TC|Spot|BB)\s*[|\t]\s*\$?([\d,]+)\s*[|\t]\s*([^|\t]+)\s*[|\t]\s*(\w+\s+\d{4})?",
        ]
        
        for pattern in charter_patterns:
            matches = re.finditer(pattern, charter_section, re.IGNORECASE)
            for match in matches:
                groups = match.groups()
                
                charter = ParsedCharter(
                    vessel_name=groups[0].strip(),
                    charter_type=self._normalize_charter_type(groups[1] if len(groups) > 1 else ""),
                    source_filing=filing_info.get("filing_id"),
                    source_text=match.group()[:200],
                    extraction_date=date.today(),
                )
                
                # Extract rate
                if len(groups) > 3 and groups[3]:
                    try:
                        charter.daily_rate = float(groups[3].replace(",", ""))
                    except ValueError:
                        pass
                
                # Extract charterer
                if len(groups) > 2 and groups[2]:
                    charterer = groups[2].strip()
                    if charterer.lower() not in ["at", "to", "with"]:
                        charter.charterer = charterer
                
                # Extract end date
                if len(groups) > 4 and groups[4]:
                    charter.end_date = self._parse_date(groups[4])
                
                charters.append(charter)
        
        # Also look for index-linked charters
        index_pattern = r"([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s+(?:is\s+)?(?:on|employed\s+on)\s+(?:an?\s+)?index[- ]linked"
        for match in re.finditer(index_pattern, charter_section, re.IGNORECASE):
            charter = ParsedCharter(
                vessel_name=match.group(1).strip(),
                charter_type="index_linked",
                index_linked=True,
                source_filing=filing_info.get("filing_id"),
                source_text=match.group()[:200],
            )
            charters.append(charter)
        
        return charters
    
    def _extract_events(
        self,
        text: str,
        filing_info: Dict[str, Any],
    ) -> List[FleetEvent]:
        """Extract fleet events (acquisitions, sales, new charters, etc.)."""
        events = []
        filing_date = filing_info.get("filing_date", date.today())
        
        # New charter events
        new_charter_pattern = r"(?:entered into|signed|concluded|agreed)\s+(?:a\s+)?(?:new\s+)?(?:time\s*)?charter\s+(?:for|with|agreement)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)"
        for match in re.finditer(new_charter_pattern, text, re.IGNORECASE):
            events.append(FleetEvent(
                event_type=EventType.NEW_CHARTER,
                event_date=filing_date,
                vessel_name=match.group(1).strip(),
                source_filing=filing_info.get("filing_id"),
                source_text=match.group()[:200],
            ))
        
        # Vessel acquisitions
        acquisition_pattern = r"(?:acquired|purchased|took delivery of)\s+(?:the\s+)?(?:M/V\s+)?([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)"
        for match in re.finditer(acquisition_pattern, text, re.IGNORECASE):
            events.append(FleetEvent(
                event_type=EventType.VESSEL_ACQUISITION,
                event_date=filing_date,
                vessel_name=match.group(1).strip(),
                source_filing=filing_info.get("filing_id"),
                source_text=match.group()[:200],
            ))
        
        # Vessel sales
        sale_pattern = r"(?:sold|disposed of|agreed to sell)\s+(?:the\s+)?(?:M/V\s+)?([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)"
        for match in re.finditer(sale_pattern, text, re.IGNORECASE):
            events.append(FleetEvent(
                event_type=EventType.VESSEL_SALE,
                event_date=filing_date,
                vessel_name=match.group(1).strip(),
                source_filing=filing_info.get("filing_id"),
                source_text=match.group()[:200],
            ))
        
        # Drydock events
        drydock_pattern = r"([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s+(?:entered|completed|scheduled for)\s+(?:its\s+)?(?:scheduled\s+)?dry\s*dock"
        for match in re.finditer(drydock_pattern, text, re.IGNORECASE):
            event_type = EventType.DRYDOCK_END if "completed" in match.group().lower() else EventType.DRYDOCK_START
            events.append(FleetEvent(
                event_type=event_type,
                event_date=filing_date,
                vessel_name=match.group(1).strip(),
                source_filing=filing_info.get("filing_id"),
                source_text=match.group()[:200],
            ))
        
        return events
    
    def _find_section(self, text: str, patterns: List[str]) -> Optional[str]:
        """Find a section of text matching one of the patterns."""
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                # Extract ~5000 chars after the match
                start = match.start()
                return text[start:start + 5000]
        return None
    
    def _normalize_vessel_type(self, text: str) -> str:
        """Normalize vessel type string."""
        text_lower = text.lower().strip()
        for pattern, normalized in self.VESSEL_TYPES.items():
            if re.search(pattern, text_lower):
                return normalized
        return text_lower or "unknown"
    
    def _normalize_charter_type(self, text: str) -> str:
        """Normalize charter type string."""
        text_lower = text.lower().strip()
        if "time" in text_lower or text_lower == "tc":
            return "time_charter"
        elif "spot" in text_lower:
            return "spot"
        elif "bare" in text_lower or text_lower == "bb":
            return "bareboat"
        elif "coa" in text_lower or "affreightment" in text_lower:
            return "coa"
        return "time_charter"  # Default
    
    def _parse_date(self, text: str) -> Optional[date]:
        """Parse date from various formats."""
        if not text:
            return None
        
        text = text.strip()
        
        # Try various formats
        formats = [
            "%B %Y",      # March 2025
            "%b %Y",      # Mar 2025
            "%B %d, %Y",  # March 15, 2025
            "%m/%d/%Y",   # 3/15/2025
            "%Y-%m-%d",   # 2025-03-15
        ]
        
        for fmt in formats:
            try:
                return datetime.strptime(text, fmt).date()
            except ValueError:
                continue
        
        # Handle Q1 2025 format
        q_match = re.match(r"Q(\d)\s+(\d{4})", text)
        if q_match:
            quarter = int(q_match.group(1))
            year = int(q_match.group(2))
            month = (quarter - 1) * 3 + 3  # End of quarter
            return date(year, month, 28)
        
        return None
    
    def _calculate_metrics(self, result: IngestionResult):
        """Calculate summary metrics."""
        result.total_fleet_count = len(result.vessels)
        
        charter_rates = []
        for charter in result.charters:
            if charter.charter_type == "time_charter":
                result.vessels_on_charter += 1
                if charter.daily_rate:
                    charter_rates.append(charter.daily_rate)
            elif charter.charter_type == "spot":
                result.vessels_on_spot += 1
        
        if charter_rates:
            result.avg_charter_rate = sum(charter_rates) / len(charter_rates)


class SECEdgarClient:
    """
    Client for SEC EDGAR API to fetch company filings.
    
    API docs: https://www.sec.gov/developer
    """
    
    BASE_URL = "https://data.sec.gov"
    SUBMISSIONS_URL = "https://data.sec.gov/submissions"
    
    def __init__(self, user_agent: str = "ShippingAlpha research@example.com"):
        self.user_agent = user_agent
        self.headers = {
            "User-Agent": user_agent,
            "Accept": "application/json",
        }
    
    def get_company_filings(
        self,
        cik: str,
        filing_types: Optional[List[str]] = None,
        limit: int = 10,
    ) -> List[Dict[str, Any]]:
        """
        Get recent filings for a company.
        
        Args:
            cik: Company CIK number (padded to 10 digits)
            filing_types: Filter by form types (e.g., ["10-Q", "10-K"])
            limit: Maximum filings to return
            
        Returns:
            List of filing metadata
        """
        # This is a placeholder - actual implementation would use requests
        # to call the SEC EDGAR API
        
        logger.info(f"Fetching filings for CIK {cik}")
        
        # In production:
        # url = f"{self.SUBMISSIONS_URL}/CIK{cik.zfill(10)}.json"
        # response = requests.get(url, headers=self.headers)
        # data = response.json()
        
        # Return placeholder
        return []
    
    def get_filing_text(self, filing_url: str) -> str:
        """
        Fetch the full text of a filing.
        
        Args:
            filing_url: URL to the filing document
            
        Returns:
            Filing text content
        """
        # Placeholder - would use requests to fetch
        logger.info(f"Fetching filing from {filing_url}")
        return ""


class CharterBookIngestionService:
    """
    Service to orchestrate charter book data ingestion.
    
    Workflow:
    1. Fetch latest filings from SEC EDGAR
    2. Parse filings to extract fleet/charter data
    3. Reconcile with existing database records
    4. Update vessel and charter tables
    5. Generate change events
    """
    
    def __init__(
        self,
        db_session,
        edgar_client: Optional[SECEdgarClient] = None,
        parser: Optional[FilingParser] = None,
    ):
        self.db = db_session
        self.edgar = edgar_client or SECEdgarClient()
        self.parser = parser or FilingParser()
    
    def ingest_company(
        self,
        ticker: str,
        cik: str,
        filing_types: List[str] = None,
    ) -> Dict[str, Any]:
        """
        Ingest latest charter book data for a company.
        
        Args:
            ticker: Stock ticker
            cik: SEC CIK number
            filing_types: Filing types to process
            
        Returns:
            Ingestion summary
        """
        filing_types = filing_types or ["10-Q", "10-K", "20-F", "6-K"]
        
        # Fetch recent filings
        filings = self.edgar.get_company_filings(cik, filing_types, limit=5)
        
        results = {
            "ticker": ticker,
            "filings_processed": 0,
            "vessels_found": 0,
            "charters_found": 0,
            "events_found": 0,
            "errors": [],
        }
        
        for filing in filings:
            try:
                # Get filing text
                text = self.edgar.get_filing_text(filing.get("url", ""))
                
                if not text:
                    continue
                
                # Parse filing
                filing_info = {
                    "ticker": ticker,
                    "filing_type": FilingType(filing.get("form", "10-Q")),
                    "filing_date": filing.get("date", date.today()),
                    "filing_id": filing.get("accession_number"),
                }
                
                parsed = self.parser.parse(text, filing_info)
                
                # Update database
                self._update_database(ticker, parsed)
                
                results["filings_processed"] += 1
                results["vessels_found"] += len(parsed.vessels)
                results["charters_found"] += len(parsed.charters)
                results["events_found"] += len(parsed.events)
                
            except Exception as e:
                logger.error(f"Error processing filing: {e}")
                results["errors"].append(str(e))
        
        return results
    
    def _update_database(self, ticker: str, parsed: IngestionResult):
        """Update database with parsed data."""
        # This would update the vessels and charters tables
        # with proper deduplication and change tracking
        
        logger.info(
            f"Updating {ticker}: {len(parsed.vessels)} vessels, "
            f"{len(parsed.charters)} charters, {len(parsed.events)} events"
        )
        
        # In production:
        # - Upsert vessels by name
        # - Update/create charter records
        # - Log events to event table
        # - Commit transaction
        pass
    
    def manual_charter_update(
        self,
        ticker: str,
        vessel_name: str,
        charter_data: Dict[str, Any],
    ) -> bool:
        """
        Manually update a charter record.
        
        For when automated parsing misses something or needs correction.
        """
        logger.info(f"Manual update for {ticker}/{vessel_name}: {charter_data}")
        
        # Validate and update
        # ...
        
        return True
    
    def get_fleet_snapshot(self, ticker: str) -> Dict[str, Any]:
        """
        Get current fleet and charter snapshot for a company.
        
        Returns:
            Dict with vessels, charters, and summary metrics
        """
        # Query database for current state
        # ...
        
        return {
            "ticker": ticker,
            "as_of": date.today().isoformat(),
            "vessels": [],
            "charters": [],
            "metrics": {
                "total_vessels": 0,
                "on_charter": 0,
                "on_spot": 0,
                "avg_charter_rate": 0,
            },
        }
