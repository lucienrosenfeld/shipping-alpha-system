"""
Backtesting and validation module.

Provides:
- Historical backtesting engine
- Forecast validation (LEP/FEP vs actual)
- Convergence time analysis
- DIS/INF calibration
"""

from .engine import (
    BacktestConfig,
    Trade,
    DailySnapshot,
    ValidationMetrics,
    BacktestResult,
    BacktestEngine,
    ForecastValidator,
    ConvergenceAnalyzer,
)

__all__ = [
    "BacktestConfig",
    "Trade",
    "DailySnapshot",
    "ValidationMetrics",
    "BacktestResult",
    "BacktestEngine",
    "ForecastValidator",
    "ConvergenceAnalyzer",
]
