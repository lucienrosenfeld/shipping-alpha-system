"""
Backtesting and Validation Suite

Implements:
1. Historical backtests with realistic execution
2. Forecast error tracking (LEP/FEP vs reported EPS)
3. Convergence time metrics (signal → price realization)
4. Belief calibration (DIS deciles → forward returns)
5. Performance attribution
"""

from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple, Callable
from enum import Enum
import statistics
import json

from loguru import logger


@dataclass
class BacktestConfig:
    """Backtest configuration parameters."""
    start_date: date
    end_date: date
    initial_capital: float = 1_000_000
    
    # Position sizing
    max_position_pct: float = 0.10  # 10% max per position
    max_positions: int = 5
    min_position_value: float = 10_000
    
    # Trading costs
    commission_per_share: float = 0.005
    slippage_pct: float = 0.001  # 10 bps
    
    # Signal thresholds
    dis_buy_threshold: float = 0.30
    inf_buy_threshold: float = 60.0
    dis_sell_threshold: float = 0.0
    
    # Risk management
    stop_loss_pct: float = 0.15
    trailing_stop_activation: float = 0.15
    trailing_stop_distance: float = 0.10
    
    # Execution
    execution_delay_days: int = 1  # Trade next day
    only_trade_on_liquidity: bool = True
    min_daily_volume: float = 500_000


@dataclass
class Trade:
    """Individual trade record."""
    trade_id: int
    ticker: str
    trade_type: str  # "earnings_surprise" or "re_rating"
    
    # Entry
    entry_date: date
    entry_price: float
    shares: int
    entry_value: float
    
    # Entry signals
    entry_lep: float
    entry_fep: float
    entry_eiep: float
    entry_inf: float
    entry_dis: float
    
    # Exit
    exit_date: Optional[date] = None
    exit_price: Optional[float] = None
    exit_reason: Optional[str] = None
    
    # Performance
    realized_pnl: float = 0
    realized_return: float = 0
    holding_days: int = 0
    
    # Costs
    commission_paid: float = 0
    slippage_cost: float = 0
    
    # Validation
    forecast_error: Optional[float] = None  # FEP vs actual EPS
    convergence_days: Optional[int] = None  # Days to reach target


@dataclass
class DailySnapshot:
    """Daily portfolio snapshot."""
    date: date
    
    # Values
    portfolio_value: float
    cash: float
    invested: float
    
    # Positions
    position_count: int
    positions: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    
    # Performance
    daily_return: float = 0
    cumulative_return: float = 0
    
    # Risk metrics
    drawdown: float = 0
    
    # Exposure
    dry_bulk_exposure: float = 0
    tanker_exposure: float = 0
    container_exposure: float = 0


@dataclass
class ValidationMetrics:
    """Signal validation metrics."""
    # Forecast accuracy
    lep_forecast_errors: List[float] = field(default_factory=list)
    fep_forecast_errors: List[float] = field(default_factory=list)
    avg_lep_error: float = 0
    avg_fep_error: float = 0
    
    # Convergence
    convergence_times: List[int] = field(default_factory=list)
    avg_convergence_days: float = 0
    median_convergence_days: float = 0
    
    # DIS calibration (decile buckets)
    dis_buckets: Dict[str, Dict[str, float]] = field(default_factory=dict)
    
    # INF calibration
    inf_buckets: Dict[str, Dict[str, float]] = field(default_factory=dict)
    
    # Hit rates
    buy_hit_rate: float = 0
    sell_hit_rate: float = 0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "forecast_accuracy": {
                "avg_lep_error": self.avg_lep_error,
                "avg_fep_error": self.avg_fep_error,
            },
            "convergence": {
                "avg_days": self.avg_convergence_days,
                "median_days": self.median_convergence_days,
            },
            "calibration": {
                "dis_buckets": self.dis_buckets,
                "inf_buckets": self.inf_buckets,
            },
            "hit_rates": {
                "buy": self.buy_hit_rate,
                "sell": self.sell_hit_rate,
            },
        }


@dataclass
class BacktestResult:
    """Complete backtest results."""
    config: BacktestConfig
    
    # Performance
    initial_capital: float
    final_value: float
    total_return: float
    cagr: float
    
    # Risk metrics
    sharpe_ratio: float
    sortino_ratio: float
    max_drawdown: float
    max_drawdown_duration_days: int
    volatility: float
    
    # Trade stats
    total_trades: int
    winning_trades: int
    losing_trades: int
    win_rate: float
    avg_win: float
    avg_loss: float
    profit_factor: float
    avg_holding_days: float
    
    # By trade type
    earnings_surprise_stats: Dict[str, float] = field(default_factory=dict)
    re_rating_stats: Dict[str, float] = field(default_factory=dict)
    
    # Costs
    total_commissions: float = 0
    total_slippage: float = 0
    
    # Validation
    validation: ValidationMetrics = field(default_factory=ValidationMetrics)
    
    # Detailed records
    trades: List[Trade] = field(default_factory=list)
    daily_snapshots: List[DailySnapshot] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "performance": {
                "initial_capital": self.initial_capital,
                "final_value": self.final_value,
                "total_return": self.total_return,
                "cagr": self.cagr,
            },
            "risk": {
                "sharpe_ratio": self.sharpe_ratio,
                "sortino_ratio": self.sortino_ratio,
                "max_drawdown": self.max_drawdown,
                "volatility": self.volatility,
            },
            "trades": {
                "total": self.total_trades,
                "win_rate": self.win_rate,
                "avg_win": self.avg_win,
                "avg_loss": self.avg_loss,
                "profit_factor": self.profit_factor,
            },
            "validation": self.validation.to_dict(),
        }


class BacktestEngine:
    """
    Production-grade backtesting engine.
    
    Features:
    - Realistic execution (slippage, commissions, delay)
    - Position lifecycle management
    - Stop loss and trailing stops
    - Detailed trade attribution
    - Signal validation metrics
    """
    
    def __init__(
        self,
        signal_engine,
        data_provider,
        config: BacktestConfig,
    ):
        self.signal_engine = signal_engine
        self.data = data_provider
        self.config = config
        
        # State
        self.cash = config.initial_capital
        self.positions: Dict[str, Dict[str, Any]] = {}
        self.trades: List[Trade] = []
        self.daily_snapshots: List[DailySnapshot] = []
        self.trade_counter = 0
        
        # Tracking
        self.high_water_mark = config.initial_capital
        self.max_drawdown = 0
        self.drawdown_start: Optional[date] = None
    
    def run(self) -> BacktestResult:
        """
        Execute the backtest.
        
        Returns:
            BacktestResult with full performance and validation metrics
        """
        logger.info(f"Starting backtest: {self.config.start_date} to {self.config.end_date}")
        
        current_date = self.config.start_date
        
        while current_date <= self.config.end_date:
            # Skip weekends
            if current_date.weekday() >= 5:
                current_date += timedelta(days=1)
                continue
            
            # Get prices and signals for today
            prices = self.data.get_prices(current_date)
            signals = self.signal_engine.calculate_universe_signals(
                calculation_date=current_date
            )
            
            # Update position values
            self._update_positions(prices, current_date)
            
            # Check stops
            self._check_stops(prices, current_date)
            
            # Process exits
            self._process_exits(signals, prices, current_date)
            
            # Process entries (with delay)
            self._process_entries(signals, prices, current_date)
            
            # Record daily snapshot
            self._record_snapshot(current_date, prices)
            
            current_date += timedelta(days=1)
        
        # Close any remaining positions
        self._close_all_positions(prices, current_date)
        
        # Calculate results
        return self._calculate_results()
    
    def _update_positions(self, prices: Dict[str, float], current_date: date):
        """Update position values with current prices."""
        for ticker, pos in self.positions.items():
            if ticker in prices:
                pos["current_price"] = prices[ticker]
                pos["market_value"] = pos["shares"] * prices[ticker]
                pos["unrealized_pnl"] = pos["market_value"] - pos["cost_basis"]
                pos["unrealized_return"] = pos["unrealized_pnl"] / pos["cost_basis"]
                
                # Update high water mark for trailing stop
                if prices[ticker] > pos.get("high_price", 0):
                    pos["high_price"] = prices[ticker]
    
    def _check_stops(self, prices: Dict[str, float], current_date: date):
        """Check and execute stop losses."""
        to_close = []
        
        for ticker, pos in self.positions.items():
            if ticker not in prices:
                continue
            
            price = prices[ticker]
            entry_price = pos["entry_price"]
            gain_pct = (price - entry_price) / entry_price
            
            # Check initial stop loss
            if gain_pct <= -self.config.stop_loss_pct:
                to_close.append((ticker, "stop_loss"))
                continue
            
            # Check trailing stop
            if gain_pct >= self.config.trailing_stop_activation:
                high_price = pos.get("high_price", entry_price)
                trailing_stop = high_price * (1 - self.config.trailing_stop_distance)
                
                if price <= trailing_stop:
                    to_close.append((ticker, "trailing_stop"))
        
        # Execute stops
        for ticker, reason in to_close:
            self._close_position(ticker, prices[ticker], current_date, reason)
    
    def _process_exits(
        self,
        signals: List[Any],
        prices: Dict[str, float],
        current_date: date,
    ):
        """Process exit signals."""
        signal_map = {s.ticker: s for s in signals}
        
        for ticker in list(self.positions.keys()):
            if ticker not in signal_map:
                continue
            
            signal = signal_map[ticker]
            pos = self.positions[ticker]
            
            # Exit on sell signal
            if signal.signal == "SELL":
                self._close_position(ticker, prices[ticker], current_date, "sell_signal")
                continue
            
            # Exit on DIS going negative (overvalued)
            if signal.dis_score < self.config.dis_sell_threshold:
                self._close_position(ticker, prices[ticker], current_date, "dis_negative")
                continue
            
            # Exit earnings surprise trades after catalyst
            if pos.get("trade_type") == "earnings_surprise":
                holding_days = (current_date - pos["entry_date"]).days
                if holding_days > 90:  # Past typical catalyst window
                    self._close_position(ticker, prices[ticker], current_date, "time_exit")
    
    def _process_entries(
        self,
        signals: List[Any],
        prices: Dict[str, float],
        current_date: date,
    ):
        """Process entry signals."""
        # Get buy candidates
        candidates = [
            s for s in signals
            if s.signal == "BUY"
            and s.ticker not in self.positions
            and s.dis_score >= self.config.dis_buy_threshold
        ]
        
        # Sort by signal strength
        candidates.sort(key=lambda x: x.signal_strength, reverse=True)
        
        # Check position limits
        available_slots = self.config.max_positions - len(self.positions)
        if available_slots <= 0:
            return
        
        # Process top candidates
        for signal in candidates[:available_slots]:
            ticker = signal.ticker
            
            if ticker not in prices:
                continue
            
            # Check liquidity
            if self.config.only_trade_on_liquidity:
                volume = self.data.get_volume(ticker, current_date)
                if volume < self.config.min_daily_volume:
                    continue
            
            # Calculate position size
            position_value = min(
                self.cash * self.config.max_position_pct,
                self._get_portfolio_value(prices) * self.config.max_position_pct,
            )
            
            if position_value < self.config.min_position_value:
                continue
            
            # Execute trade (with slippage)
            execution_price = prices[ticker] * (1 + self.config.slippage_pct)
            shares = int(position_value / execution_price)
            
            if shares <= 0:
                continue
            
            actual_value = shares * execution_price
            commission = shares * self.config.commission_per_share
            
            if actual_value + commission > self.cash:
                continue
            
            # Open position
            self._open_position(
                ticker=ticker,
                shares=shares,
                price=execution_price,
                date=current_date,
                signal=signal,
                commission=commission,
            )
    
    def _open_position(
        self,
        ticker: str,
        shares: int,
        price: float,
        date: date,
        signal: Any,
        commission: float,
    ):
        """Open a new position."""
        self.trade_counter += 1
        
        cost_basis = shares * price + commission
        self.cash -= cost_basis
        
        self.positions[ticker] = {
            "trade_id": self.trade_counter,
            "ticker": ticker,
            "shares": shares,
            "entry_price": price,
            "entry_date": date,
            "cost_basis": cost_basis,
            "current_price": price,
            "market_value": shares * price,
            "high_price": price,
            "trade_type": signal.trade_type,
            "entry_lep": signal.lep_eps,
            "entry_fep": signal.fep_eps,
            "entry_eiep": signal.eiep_eps,
            "entry_inf": signal.inf_score,
            "entry_dis": signal.dis_score,
            "commission_paid": commission,
        }
        
        logger.debug(f"Opened {ticker}: {shares} shares @ ${price:.2f}")
    
    def _close_position(
        self,
        ticker: str,
        price: float,
        date: date,
        reason: str,
    ):
        """Close a position and record the trade."""
        if ticker not in self.positions:
            return
        
        pos = self.positions[ticker]
        
        # Apply slippage on exit
        execution_price = price * (1 - self.config.slippage_pct)
        proceeds = pos["shares"] * execution_price
        commission = pos["shares"] * self.config.commission_per_share
        
        net_proceeds = proceeds - commission
        self.cash += net_proceeds
        
        # Calculate PnL
        realized_pnl = net_proceeds - pos["cost_basis"]
        realized_return = realized_pnl / pos["cost_basis"]
        holding_days = (date - pos["entry_date"]).days
        
        # Record trade
        trade = Trade(
            trade_id=pos["trade_id"],
            ticker=ticker,
            trade_type=pos.get("trade_type", "unknown"),
            entry_date=pos["entry_date"],
            entry_price=pos["entry_price"],
            shares=pos["shares"],
            entry_value=pos["cost_basis"],
            entry_lep=pos.get("entry_lep", 0),
            entry_fep=pos.get("entry_fep", 0),
            entry_eiep=pos.get("entry_eiep", 0),
            entry_inf=pos.get("entry_inf", 0),
            entry_dis=pos.get("entry_dis", 0),
            exit_date=date,
            exit_price=execution_price,
            exit_reason=reason,
            realized_pnl=realized_pnl,
            realized_return=realized_return,
            holding_days=holding_days,
            commission_paid=pos.get("commission_paid", 0) + commission,
            slippage_cost=pos["shares"] * price * self.config.slippage_pct * 2,
        )
        
        self.trades.append(trade)
        del self.positions[ticker]
        
        logger.debug(f"Closed {ticker}: PnL ${realized_pnl:.2f} ({realized_return:.1%})")
    
    def _close_all_positions(self, prices: Dict[str, float], date: date):
        """Close all remaining positions at end of backtest."""
        for ticker in list(self.positions.keys()):
            price = prices.get(ticker, self.positions[ticker]["current_price"])
            self._close_position(ticker, price, date, "backtest_end")
    
    def _get_portfolio_value(self, prices: Dict[str, float]) -> float:
        """Calculate total portfolio value."""
        position_value = sum(
            pos["shares"] * prices.get(pos["ticker"], pos["current_price"])
            for pos in self.positions.values()
        )
        return self.cash + position_value
    
    def _record_snapshot(self, date: date, prices: Dict[str, float]):
        """Record daily portfolio snapshot."""
        portfolio_value = self._get_portfolio_value(prices)
        invested = sum(pos["market_value"] for pos in self.positions.values())
        
        # Calculate daily return
        if self.daily_snapshots:
            prev_value = self.daily_snapshots[-1].portfolio_value
            daily_return = (portfolio_value - prev_value) / prev_value
        else:
            daily_return = 0
        
        # Calculate cumulative return
        cumulative_return = (portfolio_value - self.config.initial_capital) / self.config.initial_capital
        
        # Update drawdown tracking
        if portfolio_value > self.high_water_mark:
            self.high_water_mark = portfolio_value
            self.drawdown_start = None
        
        drawdown = (self.high_water_mark - portfolio_value) / self.high_water_mark
        self.max_drawdown = max(self.max_drawdown, drawdown)
        
        # Exposure by segment
        segment_exposure = {"dry_bulk": 0, "tanker": 0, "container": 0}
        # Would calculate based on position segments
        
        snapshot = DailySnapshot(
            date=date,
            portfolio_value=portfolio_value,
            cash=self.cash,
            invested=invested,
            position_count=len(self.positions),
            positions={k: v.copy() for k, v in self.positions.items()},
            daily_return=daily_return,
            cumulative_return=cumulative_return,
            drawdown=drawdown,
        )
        
        self.daily_snapshots.append(snapshot)
    
    def _calculate_results(self) -> BacktestResult:
        """Calculate final backtest results and validation metrics."""
        # Performance metrics
        final_value = self.daily_snapshots[-1].portfolio_value if self.daily_snapshots else self.config.initial_capital
        total_return = (final_value - self.config.initial_capital) / self.config.initial_capital
        
        # Calculate CAGR
        days = (self.config.end_date - self.config.start_date).days
        years = days / 365
        cagr = (final_value / self.config.initial_capital) ** (1 / years) - 1 if years > 0 else 0
        
        # Daily returns for risk metrics
        daily_returns = [s.daily_return for s in self.daily_snapshots if s.daily_return != 0]
        
        # Volatility
        volatility = statistics.stdev(daily_returns) * (252 ** 0.5) if len(daily_returns) > 1 else 0
        
        # Sharpe ratio (assuming 5% risk-free rate)
        excess_return = cagr - 0.05
        sharpe = excess_return / volatility if volatility > 0 else 0
        
        # Sortino ratio (downside deviation)
        negative_returns = [r for r in daily_returns if r < 0]
        downside_vol = statistics.stdev(negative_returns) * (252 ** 0.5) if len(negative_returns) > 1 else 0
        sortino = excess_return / downside_vol if downside_vol > 0 else 0
        
        # Trade statistics
        winning_trades = [t for t in self.trades if t.realized_pnl > 0]
        losing_trades = [t for t in self.trades if t.realized_pnl <= 0]
        
        win_rate = len(winning_trades) / len(self.trades) if self.trades else 0
        avg_win = statistics.mean([t.realized_return for t in winning_trades]) if winning_trades else 0
        avg_loss = statistics.mean([t.realized_return for t in losing_trades]) if losing_trades else 0
        
        gross_profit = sum(t.realized_pnl for t in winning_trades)
        gross_loss = abs(sum(t.realized_pnl for t in losing_trades))
        profit_factor = gross_profit / gross_loss if gross_loss > 0 else float('inf')
        
        avg_holding = statistics.mean([t.holding_days for t in self.trades]) if self.trades else 0
        
        # Costs
        total_commissions = sum(t.commission_paid for t in self.trades)
        total_slippage = sum(t.slippage_cost for t in self.trades)
        
        # Stats by trade type
        earnings_trades = [t for t in self.trades if t.trade_type == "earnings_surprise"]
        rerating_trades = [t for t in self.trades if t.trade_type == "re_rating"]
        
        earnings_stats = self._calculate_trade_type_stats(earnings_trades)
        rerating_stats = self._calculate_trade_type_stats(rerating_trades)
        
        # Validation metrics
        validation = self._calculate_validation_metrics()
        
        # Max drawdown duration
        max_dd_duration = self._calculate_max_dd_duration()
        
        return BacktestResult(
            config=self.config,
            initial_capital=self.config.initial_capital,
            final_value=final_value,
            total_return=total_return,
            cagr=cagr,
            sharpe_ratio=sharpe,
            sortino_ratio=sortino,
            max_drawdown=self.max_drawdown,
            max_drawdown_duration_days=max_dd_duration,
            volatility=volatility,
            total_trades=len(self.trades),
            winning_trades=len(winning_trades),
            losing_trades=len(losing_trades),
            win_rate=win_rate,
            avg_win=avg_win,
            avg_loss=avg_loss,
            profit_factor=profit_factor,
            avg_holding_days=avg_holding,
            earnings_surprise_stats=earnings_stats,
            re_rating_stats=rerating_stats,
            total_commissions=total_commissions,
            total_slippage=total_slippage,
            validation=validation,
            trades=self.trades,
            daily_snapshots=self.daily_snapshots,
        )
    
    def _calculate_trade_type_stats(self, trades: List[Trade]) -> Dict[str, float]:
        """Calculate statistics for a trade type."""
        if not trades:
            return {"count": 0, "win_rate": 0, "avg_return": 0}
        
        winning = [t for t in trades if t.realized_pnl > 0]
        returns = [t.realized_return for t in trades]
        
        return {
            "count": len(trades),
            "win_rate": len(winning) / len(trades),
            "avg_return": statistics.mean(returns),
            "avg_holding_days": statistics.mean([t.holding_days for t in trades]),
        }
    
    def _calculate_validation_metrics(self) -> ValidationMetrics:
        """Calculate signal validation metrics."""
        validation = ValidationMetrics()
        
        # DIS bucket calibration
        dis_buckets = {
            "0-10%": [], "10-20%": [], "20-30%": [], "30-40%": [],
            "40-50%": [], "50%+": []
        }
        
        for trade in self.trades:
            dis = trade.entry_dis
            return_val = trade.realized_return
            
            if dis < 0.1:
                dis_buckets["0-10%"].append(return_val)
            elif dis < 0.2:
                dis_buckets["10-20%"].append(return_val)
            elif dis < 0.3:
                dis_buckets["20-30%"].append(return_val)
            elif dis < 0.4:
                dis_buckets["30-40%"].append(return_val)
            elif dis < 0.5:
                dis_buckets["40-50%"].append(return_val)
            else:
                dis_buckets["50%+"].append(return_val)
        
        for bucket, returns in dis_buckets.items():
            if returns:
                validation.dis_buckets[bucket] = {
                    "count": len(returns),
                    "avg_return": statistics.mean(returns),
                    "win_rate": len([r for r in returns if r > 0]) / len(returns),
                }
        
        # INF bucket calibration
        inf_buckets = {"<40": [], "40-60": [], "60-80": [], "80+": []}
        
        for trade in self.trades:
            inf = trade.entry_inf
            return_val = trade.realized_return
            
            if inf < 40:
                inf_buckets["<40"].append(return_val)
            elif inf < 60:
                inf_buckets["40-60"].append(return_val)
            elif inf < 80:
                inf_buckets["60-80"].append(return_val)
            else:
                inf_buckets["80+"].append(return_val)
        
        for bucket, returns in inf_buckets.items():
            if returns:
                validation.inf_buckets[bucket] = {
                    "count": len(returns),
                    "avg_return": statistics.mean(returns),
                    "win_rate": len([r for r in returns if r > 0]) / len(returns),
                }
        
        # Hit rates
        buy_trades = [t for t in self.trades if t.entry_dis > 0]
        validation.buy_hit_rate = (
            len([t for t in buy_trades if t.realized_pnl > 0]) / len(buy_trades)
            if buy_trades else 0
        )
        
        return validation
    
    def _calculate_max_dd_duration(self) -> int:
        """Calculate maximum drawdown duration in days."""
        max_duration = 0
        current_duration = 0
        in_drawdown = False
        
        for snapshot in self.daily_snapshots:
            if snapshot.drawdown > 0:
                if not in_drawdown:
                    in_drawdown = True
                    current_duration = 1
                else:
                    current_duration += 1
                max_duration = max(max_duration, current_duration)
            else:
                in_drawdown = False
                current_duration = 0
        
        return max_duration


class ForecastValidator:
    """
    Validates LEP/FEP forecasts against actual reported earnings.
    
    Tracks:
    - Forecast error (FEP - Actual) / Actual
    - Direction accuracy (did we predict up/down correctly)
    - Error by company, segment, time period
    """
    
    def __init__(self, data_provider):
        self.data = data_provider
        self.forecast_records: List[Dict[str, Any]] = []
    
    def record_forecast(
        self,
        ticker: str,
        forecast_date: date,
        forecast_period: str,  # e.g., "Q1 2024"
        lep_eps: float,
        fep_eps: float,
    ):
        """Record a forecast for later validation."""
        self.forecast_records.append({
            "ticker": ticker,
            "forecast_date": forecast_date,
            "period": forecast_period,
            "lep_eps": lep_eps,
            "fep_eps": fep_eps,
            "actual_eps": None,
            "validated": False,
        })
    
    def validate_forecasts(self) -> Dict[str, Any]:
        """
        Validate all pending forecasts against actual results.
        
        Returns:
            Validation summary with error metrics
        """
        lep_errors = []
        fep_errors = []
        direction_correct = 0
        total_validated = 0
        
        for record in self.forecast_records:
            if record["validated"]:
                continue
            
            # Try to get actual EPS
            actual = self.data.get_actual_eps(
                record["ticker"],
                record["period"],
            )
            
            if actual is not None:
                record["actual_eps"] = actual
                record["validated"] = True
                
                # Calculate errors
                if actual != 0:
                    lep_error = (record["lep_eps"] - actual) / abs(actual)
                    fep_error = (record["fep_eps"] - actual) / abs(actual)
                    
                    lep_errors.append(lep_error)
                    fep_errors.append(fep_error)
                    
                    record["lep_error"] = lep_error
                    record["fep_error"] = fep_error
                
                total_validated += 1
        
        return {
            "total_forecasts": len(self.forecast_records),
            "validated": total_validated,
            "lep_mae": statistics.mean([abs(e) for e in lep_errors]) if lep_errors else None,
            "fep_mae": statistics.mean([abs(e) for e in fep_errors]) if fep_errors else None,
            "lep_bias": statistics.mean(lep_errors) if lep_errors else None,
            "fep_bias": statistics.mean(fep_errors) if fep_errors else None,
        }


class ConvergenceAnalyzer:
    """
    Analyzes how quickly mispricings correct.
    
    Tracks:
    - Days from signal to 50% convergence
    - Days from signal to 90% convergence
    - Convergence by signal strength bucket
    """
    
    def analyze_trade(
        self,
        trade: Trade,
        price_history: List[Tuple[date, float]],
    ) -> Dict[str, Any]:
        """
        Analyze convergence for a completed trade.
        
        Args:
            trade: Completed trade record
            price_history: Daily prices during holding period
            
        Returns:
            Convergence metrics
        """
        if not price_history or trade.entry_dis <= 0:
            return {"convergence_50": None, "convergence_90": None}
        
        entry_price = trade.entry_price
        # Target price based on DIS (if 40% undervalued, target is ~67% higher)
        target_price = entry_price / (1 - trade.entry_dis)
        gap = target_price - entry_price
        
        convergence_50 = None
        convergence_90 = None
        
        for i, (dt, price) in enumerate(price_history):
            price_move = price - entry_price
            convergence_pct = price_move / gap if gap > 0 else 0
            
            if convergence_pct >= 0.5 and convergence_50 is None:
                convergence_50 = i + 1
            if convergence_pct >= 0.9 and convergence_90 is None:
                convergence_90 = i + 1
                break
        
        return {
            "convergence_50_days": convergence_50,
            "convergence_90_days": convergence_90,
            "final_convergence_pct": (trade.exit_price - entry_price) / gap if gap > 0 else 0,
            "entry_dis": trade.entry_dis,
            "entry_inf": trade.entry_inf,
        }
