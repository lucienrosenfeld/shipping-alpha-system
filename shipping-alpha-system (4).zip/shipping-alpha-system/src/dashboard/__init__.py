"""Dashboard module for the Shipping Equity Alpha System."""

from .app import create_app

__all__ = ["create_app"]
