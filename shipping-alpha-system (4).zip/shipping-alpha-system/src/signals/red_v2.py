"""
RED v2 - Realized Earnings Delay Model

Full earnings transmission model that:
1. Decomposes charter book by vessel
2. Projects quarter-by-quarter revenue blending (fixed + spot/FFA)
3. Outputs explicit quarterly EPS projections for next 8 quarters
4. Maps when freight rate changes transmit to reported earnings
"""

from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from enum import Enum
import calendar

from loguru import logger


@dataclass
class CharterContract:
    """Individual charter contract."""
    vessel_id: int
    vessel_name: str
    vessel_type: str
    charter_type: str  # "spot", "time_charter", "index_linked"
    daily_rate: float  # $/day (fixed rate or current spot)
    start_date: date
    end_date: Optional[date]  # None = open-ended or spot
    counterparty: Optional[str] = None
    has_profit_share: bool = False
    profit_share_pct: float = 0
    index_link: Optional[str] = None  # e.g., "BCI" for index-linked
    
    def days_in_period(self, period_start: date, period_end: date) -> int:
        """Calculate charter days within a period."""
        if self.charter_type == "spot":
            return (period_end - period_start).days
        
        charter_start = max(self.start_date, period_start)
        charter_end = min(self.end_date, period_end) if self.end_date else period_end
        
        if charter_start >= charter_end:
            return 0
        return (charter_end - charter_start).days


@dataclass
class VesselCosts:
    """Operating costs for a vessel."""
    vessel_id: int
    daily_opex: float  # Crew, maintenance, insurance, etc.
    daily_depreciation: float
    financing_cost_daily: float  # Debt service allocated


@dataclass
class QuarterlyProjection:
    """Earnings projection for a single quarter."""
    quarter: int  # 1-8 (next 8 quarters)
    year: int
    quarter_num: int  # 1-4
    start_date: date
    end_date: date
    days_in_quarter: int
    
    # Revenue breakdown
    fixed_charter_revenue: float = 0
    spot_revenue: float = 0
    index_linked_revenue: float = 0
    total_revenue: float = 0
    
    # Days breakdown
    fixed_charter_days: int = 0
    spot_days: int = 0
    index_linked_days: int = 0
    total_vessel_days: int = 0
    
    # Costs
    total_opex: float = 0
    total_depreciation: float = 0
    total_financing: float = 0
    ga_expense: float = 0
    
    # Earnings
    gross_profit: float = 0
    ebitda: float = 0
    ebit: float = 0
    net_income: float = 0
    eps: float = 0
    
    # Rates used
    avg_fixed_rate: float = 0
    avg_spot_rate: float = 0
    blended_tce: float = 0
    
    # Exposure metrics
    spot_exposure_pct: float = 0
    rate_sensitivity: float = 0  # EPS change per $1000 TCE change
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "quarter": self.quarter,
            "period": f"Q{self.quarter_num} {self.year}",
            "start_date": self.start_date.isoformat(),
            "end_date": self.end_date.isoformat(),
            "revenue": {
                "fixed_charter": self.fixed_charter_revenue,
                "spot": self.spot_revenue,
                "index_linked": self.index_linked_revenue,
                "total": self.total_revenue,
            },
            "days": {
                "fixed": self.fixed_charter_days,
                "spot": self.spot_days,
                "index_linked": self.index_linked_days,
                "total": self.total_vessel_days,
            },
            "earnings": {
                "gross_profit": self.gross_profit,
                "ebitda": self.ebitda,
                "ebit": self.ebit,
                "net_income": self.net_income,
                "eps": self.eps,
            },
            "rates": {
                "avg_fixed": self.avg_fixed_rate,
                "avg_spot": self.avg_spot_rate,
                "blended_tce": self.blended_tce,
            },
            "exposure": {
                "spot_pct": self.spot_exposure_pct,
                "rate_sensitivity": self.rate_sensitivity,
            },
        }


@dataclass
class EarningsTransmissionResult:
    """Complete RED v2 output."""
    company_id: int
    ticker: str
    calculation_date: date
    
    # Quarterly projections
    quarterly_projections: List[QuarterlyProjection] = field(default_factory=list)
    
    # Summary metrics
    next_4q_eps: float = 0  # Sum of next 4 quarters
    next_4q_ebitda: float = 0
    
    # Transmission timing
    time_to_50pct_reset_months: float = 0
    time_to_90pct_reset_months: float = 0
    earnings_weighted_lag_months: float = 0
    
    # Current exposure
    current_spot_pct: float = 0
    current_fixed_pct: float = 0
    
    # Sensitivity
    eps_per_1000_tce: float = 0  # EPS impact of $1000 TCE change
    
    # Charter roll schedule
    charter_expirations: List[Dict[str, Any]] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "company_id": self.company_id,
            "ticker": self.ticker,
            "calculation_date": self.calculation_date.isoformat(),
            "summary": {
                "next_4q_eps": self.next_4q_eps,
                "next_4q_ebitda": self.next_4q_ebitda,
                "time_to_50pct_reset": self.time_to_50pct_reset_months,
                "time_to_90pct_reset": self.time_to_90pct_reset_months,
                "earnings_weighted_lag": self.earnings_weighted_lag_months,
                "current_spot_pct": self.current_spot_pct,
                "eps_per_1000_tce": self.eps_per_1000_tce,
            },
            "quarterly_projections": [q.to_dict() for q in self.quarterly_projections],
            "charter_expirations": self.charter_expirations,
        }


class REDv2Calculator:
    """
    Realized Earnings Delay v2 - Full Earnings Transmission Model.
    
    Maps freight market changes to reported earnings with quarter-by-quarter
    granularity, accounting for:
    - Fixed charter contracts (locked rates)
    - Spot exposure (immediate rate sensitivity)
    - Index-linked charters (partial exposure)
    - Charter roll-off schedule
    """
    
    def __init__(
        self,
        utilization_rate: float = 0.95,
        projection_quarters: int = 8,
    ):
        self.utilization_rate = utilization_rate
        self.projection_quarters = projection_quarters
    
    def calculate(
        self,
        company_data: Dict[str, Any],
        vessels: List[Dict[str, Any]],
        vessel_costs: List[VesselCosts],
        charters: List[CharterContract],
        spot_rates: Dict[str, float],  # vessel_type -> current spot $/day
        forward_curves: Dict[str, List[Dict[str, float]]],  # vessel_type -> quarterly forwards
        calculation_date: date,
    ) -> EarningsTransmissionResult:
        """
        Calculate full earnings transmission model.
        
        Args:
            company_data: Company financials (G&A, shares, etc.)
            vessels: Fleet vessel list
            vessel_costs: Operating costs per vessel
            charters: Active charter contracts
            spot_rates: Current spot TCE rates by vessel type
            forward_curves: FFA forward curves by vessel type
            calculation_date: As-of date
            
        Returns:
            EarningsTransmissionResult with 8-quarter projections
        """
        result = EarningsTransmissionResult(
            company_id=company_data.get("id", 0),
            ticker=company_data.get("ticker", ""),
            calculation_date=calculation_date,
        )
        
        # Build vessel lookup
        vessel_map = {v["id"]: v for v in vessels}
        cost_map = {c.vessel_id: c for c in vessel_costs}
        
        # Build charter lookup by vessel
        charter_map: Dict[int, List[CharterContract]] = {}
        for charter in charters:
            if charter.vessel_id not in charter_map:
                charter_map[charter.vessel_id] = []
            charter_map[charter.vessel_id].append(charter)
        
        # Get company overhead
        quarterly_ga = company_data.get("annual_ga_expense", 0) / 4
        shares = company_data.get("shares_outstanding", 1)
        tax_rate = company_data.get("tax_rate", 0)  # Most shipping cos pay minimal tax
        
        # Generate quarter dates
        quarters = self._generate_quarters(calculation_date, self.projection_quarters)
        
        # Track cumulative spot exposure for transmission timing
        cumulative_spot_days = 0
        total_possible_days = 0
        
        # Calculate each quarter
        for q_idx, (q_start, q_end, year, q_num) in enumerate(quarters):
            days_in_quarter = (q_end - q_start).days
            
            projection = QuarterlyProjection(
                quarter=q_idx + 1,
                year=year,
                quarter_num=q_num,
                start_date=q_start,
                end_date=q_end,
                days_in_quarter=days_in_quarter,
            )
            
            # Process each vessel
            for vessel in vessels:
                if not vessel.get("active", True):
                    continue
                
                vessel_id = vessel["id"]
                vessel_type = vessel.get("vessel_type", "unknown")
                costs = cost_map.get(vessel_id)
                vessel_charters = charter_map.get(vessel_id, [])
                
                # Get rates for this quarter
                spot_rate = self._get_rate_for_quarter(
                    vessel_type, q_idx, spot_rates, forward_curves
                )
                
                # Calculate days and revenue by charter type
                vessel_result = self._calculate_vessel_quarter(
                    vessel=vessel,
                    charters=vessel_charters,
                    costs=costs,
                    q_start=q_start,
                    q_end=q_end,
                    spot_rate=spot_rate,
                    utilization=self.utilization_rate,
                )
                
                # Aggregate
                projection.fixed_charter_revenue += vessel_result["fixed_revenue"]
                projection.spot_revenue += vessel_result["spot_revenue"]
                projection.index_linked_revenue += vessel_result["index_revenue"]
                
                projection.fixed_charter_days += vessel_result["fixed_days"]
                projection.spot_days += vessel_result["spot_days"]
                projection.index_linked_days += vessel_result["index_days"]
                
                projection.total_opex += vessel_result["opex"]
                projection.total_depreciation += vessel_result["depreciation"]
                projection.total_financing += vessel_result["financing"]
            
            # Calculate totals
            projection.total_revenue = (
                projection.fixed_charter_revenue +
                projection.spot_revenue +
                projection.index_linked_revenue
            )
            projection.total_vessel_days = (
                projection.fixed_charter_days +
                projection.spot_days +
                projection.index_linked_days
            )
            
            # G&A expense
            projection.ga_expense = quarterly_ga
            
            # Earnings calculations
            projection.gross_profit = projection.total_revenue - projection.total_opex
            projection.ebitda = projection.gross_profit - projection.ga_expense
            projection.ebit = projection.ebitda - projection.total_depreciation
            projection.net_income = (projection.ebit - projection.total_financing) * (1 - tax_rate)
            projection.eps = projection.net_income / shares if shares > 0 else 0
            
            # Rate metrics
            if projection.fixed_charter_days > 0:
                projection.avg_fixed_rate = (
                    projection.fixed_charter_revenue / projection.fixed_charter_days
                )
            if projection.spot_days > 0:
                projection.avg_spot_rate = (
                    projection.spot_revenue / projection.spot_days
                )
            if projection.total_vessel_days > 0:
                projection.blended_tce = (
                    projection.total_revenue / projection.total_vessel_days
                )
                projection.spot_exposure_pct = (
                    (projection.spot_days + projection.index_linked_days * 0.5) /
                    projection.total_vessel_days
                )
            
            # Rate sensitivity: EPS change per $1000/day TCE change on spot days
            spot_sensitive_days = projection.spot_days + projection.index_linked_days * 0.5
            if spot_sensitive_days > 0 and shares > 0:
                projection.rate_sensitivity = (
                    spot_sensitive_days * 1000 * (1 - tax_rate) / shares
                )
            
            result.quarterly_projections.append(projection)
            
            # Track for transmission timing
            cumulative_spot_days += projection.spot_days + projection.index_linked_days
            total_possible_days += projection.total_vessel_days
        
        # Calculate summary metrics
        self._calculate_summary_metrics(result, total_possible_days)
        
        # Build charter expiration schedule
        result.charter_expirations = self._build_expiration_schedule(
            charters, calculation_date
        )
        
        return result
    
    def _generate_quarters(
        self,
        start_date: date,
        num_quarters: int,
    ) -> List[Tuple[date, date, int, int]]:
        """Generate list of (start, end, year, quarter_num) tuples."""
        quarters = []
        
        # Find current quarter start
        current_q = (start_date.month - 1) // 3 + 1
        q_start_month = (current_q - 1) * 3 + 1
        q_start = date(start_date.year, q_start_month, 1)
        
        for _ in range(num_quarters):
            year = q_start.year
            q_num = (q_start.month - 1) // 3 + 1
            
            # Quarter end
            if q_num == 4:
                q_end = date(year + 1, 1, 1)
            else:
                q_end = date(year, q_start.month + 3, 1)
            
            quarters.append((q_start, q_end, year, q_num))
            
            # Move to next quarter
            q_start = q_end
        
        return quarters
    
    def _get_rate_for_quarter(
        self,
        vessel_type: str,
        quarter_idx: int,
        spot_rates: Dict[str, float],
        forward_curves: Dict[str, List[Dict[str, float]]],
    ) -> float:
        """Get appropriate rate for a quarter (spot for Q1, forwards thereafter)."""
        if quarter_idx == 0:
            return spot_rates.get(vessel_type, 15000)
        
        curve = forward_curves.get(vessel_type, [])
        if quarter_idx - 1 < len(curve):
            return curve[quarter_idx - 1].get("settlement", spot_rates.get(vessel_type, 15000))
        
        # Fallback to spot if no forward data
        return spot_rates.get(vessel_type, 15000)
    
    def _calculate_vessel_quarter(
        self,
        vessel: Dict[str, Any],
        charters: List[CharterContract],
        costs: Optional[VesselCosts],
        q_start: date,
        q_end: date,
        spot_rate: float,
        utilization: float,
    ) -> Dict[str, float]:
        """Calculate a single vessel's contribution to a quarter."""
        days_in_quarter = (q_end - q_start).days
        available_days = int(days_in_quarter * utilization)
        
        fixed_days = 0
        fixed_revenue = 0
        index_days = 0
        index_revenue = 0
        
        # Process charters
        for charter in charters:
            charter_days = charter.days_in_period(q_start, q_end)
            charter_days = int(charter_days * utilization)
            
            if charter.charter_type == "time_charter":
                fixed_days += charter_days
                fixed_revenue += charter_days * charter.daily_rate
            elif charter.charter_type == "index_linked":
                index_days += charter_days
                # Index-linked uses spot rate (simplified)
                index_revenue += charter_days * spot_rate
        
        # Remaining days are spot
        spot_days = max(0, available_days - fixed_days - index_days)
        spot_revenue = spot_days * spot_rate
        
        # Costs
        opex = 0
        depreciation = 0
        financing = 0
        if costs:
            total_days = fixed_days + spot_days + index_days
            opex = total_days * costs.daily_opex
            depreciation = total_days * costs.daily_depreciation
            financing = total_days * costs.financing_cost_daily
        else:
            # Default costs if not specified
            total_days = fixed_days + spot_days + index_days
            opex = total_days * vessel.get("daily_opex", 6000)
        
        return {
            "fixed_days": fixed_days,
            "fixed_revenue": fixed_revenue,
            "spot_days": spot_days,
            "spot_revenue": spot_revenue,
            "index_days": index_days,
            "index_revenue": index_revenue,
            "opex": opex,
            "depreciation": depreciation,
            "financing": financing,
        }
    
    def _calculate_summary_metrics(
        self,
        result: EarningsTransmissionResult,
        total_possible_days: int,
    ):
        """Calculate summary metrics from quarterly projections."""
        # Next 4Q totals
        for q in result.quarterly_projections[:4]:
            result.next_4q_eps += q.eps
            result.next_4q_ebitda += q.ebitda
        
        # Current exposure (Q1)
        if result.quarterly_projections:
            q1 = result.quarterly_projections[0]
            result.current_spot_pct = q1.spot_exposure_pct
            result.current_fixed_pct = 1 - q1.spot_exposure_pct
        
        # Time to 50% and 90% reset
        cumulative_spot_days = 0
        for q in result.quarterly_projections:
            cumulative_spot_days += q.spot_days + q.index_linked_days
            spot_pct = cumulative_spot_days / max(total_possible_days, 1)
            
            if spot_pct >= 0.5 and result.time_to_50pct_reset_months == 0:
                result.time_to_50pct_reset_months = q.quarter * 3
            if spot_pct >= 0.9 and result.time_to_90pct_reset_months == 0:
                result.time_to_90pct_reset_months = q.quarter * 3
        
        # Earnings-weighted lag
        total_weighted = 0
        total_earnings = 0
        for q in result.quarterly_projections:
            if q.net_income > 0:
                weight = q.spot_exposure_pct * q.net_income
                total_weighted += weight * q.quarter * 3  # months
                total_earnings += weight
        
        if total_earnings > 0:
            result.earnings_weighted_lag_months = total_weighted / total_earnings
        
        # EPS sensitivity to $1000 TCE change
        if result.quarterly_projections:
            result.eps_per_1000_tce = sum(
                q.rate_sensitivity for q in result.quarterly_projections[:4]
            )
    
    def _build_expiration_schedule(
        self,
        charters: List[CharterContract],
        calculation_date: date,
    ) -> List[Dict[str, Any]]:
        """Build schedule of upcoming charter expirations."""
        expirations = []
        
        for charter in charters:
            if charter.end_date and charter.end_date > calculation_date:
                months_to_expiry = (
                    (charter.end_date.year - calculation_date.year) * 12 +
                    (charter.end_date.month - calculation_date.month)
                )
                
                expirations.append({
                    "vessel_id": charter.vessel_id,
                    "vessel_name": charter.vessel_name,
                    "vessel_type": charter.vessel_type,
                    "expiry_date": charter.end_date.isoformat(),
                    "months_to_expiry": months_to_expiry,
                    "current_rate": charter.daily_rate,
                    "counterparty": charter.counterparty,
                })
        
        # Sort by expiry date
        expirations.sort(key=lambda x: x["expiry_date"])
        
        return expirations


def calculate_rate_scenario(
    result: EarningsTransmissionResult,
    rate_change_pct: float,
) -> Dict[str, float]:
    """
    Calculate impact of rate change scenario on projected earnings.
    
    Args:
        result: Base RED calculation result
        rate_change_pct: Rate change (e.g., 0.20 for +20%)
        
    Returns:
        Scenario impact metrics
    """
    base_4q_eps = result.next_4q_eps
    
    # Impact = sensitivity * rate change
    # Sensitivity is per $1000, so adjust
    avg_spot_rate = 20000  # Rough average
    rate_change_dollars = avg_spot_rate * rate_change_pct
    rate_change_thousands = rate_change_dollars / 1000
    
    eps_impact = result.eps_per_1000_tce * rate_change_thousands
    new_4q_eps = base_4q_eps + eps_impact
    
    return {
        "base_eps": base_4q_eps,
        "rate_change_pct": rate_change_pct,
        "eps_impact": eps_impact,
        "new_eps": new_4q_eps,
        "eps_change_pct": eps_impact / base_4q_eps if base_4q_eps else 0,
    }
