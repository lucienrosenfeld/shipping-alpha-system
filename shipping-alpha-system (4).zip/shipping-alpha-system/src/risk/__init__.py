"""
Risk management module.

Components:
- MacroFilter: Market regime detection
- CorrelationRegimeDetector: Freight-equity correlation analysis
- PositionSizer: Position sizing calculations
- StopLossManager: Stop loss management
- RiskManager: Unified interface
"""

from .risk_manager import (
    RiskRegime,
    MacroSnapshot,
    CorrelationMetrics,
    MacroFilter,
    CorrelationRegimeDetector,
    PositionSizer,
    StopLossManager,
    RiskAssessment,
    RiskManager,
)

__all__ = [
    "RiskRegime",
    "MacroSnapshot",
    "CorrelationMetrics",
    "MacroFilter",
    "CorrelationRegimeDetector",
    "PositionSizer",
    "StopLossManager",
    "RiskAssessment",
    "RiskManager",
]
