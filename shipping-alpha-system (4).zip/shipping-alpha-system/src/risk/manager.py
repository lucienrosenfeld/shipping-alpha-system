"""
Risk Management Module.

Handles:
- Macro regime detection (VIX, credit spreads, etc.)
- Correlation regime tracking (freight-equity correlation)
- Position sizing
- Stop loss management
- Portfolio exposure limits
"""

from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from enum import Enum
import statistics

from loguru import logger


class RiskRegime(Enum):
    """Risk regime classification."""
    NORMAL = "normal"
    CAUTION = "caution"
    RISK_OFF = "risk_off"


class CorrelationRegime(Enum):
    """Correlation regime classification."""
    HIGH_FREIGHT = "high_freight"  # Stock follows freight
    HIGH_MARKET = "high_market"  # Stock follows broad market
    DECORRELATED = "decorrelated"  # Neither - idiosyncratic
    COLLAPSED = "collapsed"  # Correlation breakdown


@dataclass
class MacroSnapshot:
    """Snapshot of macro indicators."""
    date: date
    vix: float
    sp500_price: float
    sp500_1w_return: float
    credit_spread: float  # HY spread
    treasury_10y: float
    dxy: float  # Dollar index
    oil_price: float


@dataclass
class RiskAssessment:
    """Complete risk assessment output."""
    date: date
    
    # Regime
    risk_regime: RiskRegime
    correlation_regime: CorrelationRegime
    
    # Macro flags
    vix_elevated: bool
    market_stressed: bool
    credit_stressed: bool
    
    # Correlation metrics
    freight_correlation: float
    market_correlation: float
    correlation_spread: float  # freight - market
    
    # Position sizing adjustments
    position_size_multiplier: float
    max_position_pct: float
    
    # Override
    manual_override: bool = False
    override_reason: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "date": self.date.isoformat(),
            "risk_regime": self.risk_regime.value,
            "correlation_regime": self.correlation_regime.value,
            "vix_elevated": self.vix_elevated,
            "market_stressed": self.market_stressed,
            "credit_stressed": self.credit_stressed,
            "freight_correlation": self.freight_correlation,
            "market_correlation": self.market_correlation,
            "position_size_multiplier": self.position_size_multiplier,
            "max_position_pct": self.max_position_pct,
        }


class MacroFilter:
    """
    Macro filter for risk regime detection.
    
    Monitors:
    - VIX levels
    - S&P 500 drawdowns
    - Credit spreads
    - Dollar strength
    """
    
    def __init__(
        self,
        vix_warning: float = 25.0,
        vix_critical: float = 35.0,
        market_drawdown_warning: float = -0.05,  # -5% weekly
        market_drawdown_critical: float = -0.10,  # -10% weekly
        credit_spread_warning: float = 4.0,  # 400 bps
        credit_spread_critical: float = 6.0,  # 600 bps
    ):
        self.vix_warning = vix_warning
        self.vix_critical = vix_critical
        self.market_drawdown_warning = market_drawdown_warning
        self.market_drawdown_critical = market_drawdown_critical
        self.credit_spread_warning = credit_spread_warning
        self.credit_spread_critical = credit_spread_critical
    
    def assess(self, macro: MacroSnapshot) -> Dict[str, Any]:
        """
        Assess macro conditions.
        
        Args:
            macro: Current macro snapshot
            
        Returns:
            Dict with regime and flags
        """
        # VIX assessment
        vix_elevated = macro.vix >= self.vix_warning
        vix_critical = macro.vix >= self.vix_critical
        
        # Market stress
        market_warning = macro.sp500_1w_return <= self.market_drawdown_warning
        market_critical = macro.sp500_1w_return <= self.market_drawdown_critical
        
        # Credit stress
        credit_warning = macro.credit_spread >= self.credit_spread_warning
        credit_critical = macro.credit_spread >= self.credit_spread_critical
        
        # Determine regime
        critical_count = sum([vix_critical, market_critical, credit_critical])
        warning_count = sum([vix_elevated, market_warning, credit_warning])
        
        if critical_count >= 2:
            regime = RiskRegime.RISK_OFF
        elif critical_count >= 1 or warning_count >= 2:
            regime = RiskRegime.CAUTION
        else:
            regime = RiskRegime.NORMAL
        
        # Position sizing multiplier
        if regime == RiskRegime.RISK_OFF:
            multiplier = 0.0  # No new positions
        elif regime == RiskRegime.CAUTION:
            multiplier = 0.5  # Half size
        else:
            multiplier = 1.0  # Full size
        
        return {
            "regime": regime,
            "vix_elevated": vix_elevated,
            "market_stressed": market_warning or market_critical,
            "credit_stressed": credit_warning or credit_critical,
            "position_multiplier": multiplier,
            "flags": {
                "vix": "critical" if vix_critical else ("warning" if vix_elevated else "normal"),
                "market": "critical" if market_critical else ("warning" if market_warning else "normal"),
                "credit": "critical" if credit_critical else ("warning" if credit_warning else "normal"),
            },
        }


class CorrelationTracker:
    """
    Tracks rolling correlations between:
    - Individual stocks and freight indices
    - Individual stocks and broad market (S&P 500)
    
    Used to detect regime changes where fundamental signals may be less effective.
    """
    
    def __init__(
        self,
        window_days: int = 60,
        low_correlation_threshold: float = 0.2,
        high_correlation_threshold: float = 0.6,
    ):
        self.window_days = window_days
        self.low_threshold = low_correlation_threshold
        self.high_threshold = high_correlation_threshold
    
    def calculate_correlation(
        self,
        series_a: List[float],
        series_b: List[float],
    ) -> float:
        """Calculate Pearson correlation between two series."""
        if len(series_a) != len(series_b) or len(series_a) < 3:
            return 0.0
        
        n = len(series_a)
        mean_a = sum(series_a) / n
        mean_b = sum(series_b) / n
        
        numerator = sum((a - mean_a) * (b - mean_b) for a, b in zip(series_a, series_b))
        
        var_a = sum((a - mean_a) ** 2 for a in series_a)
        var_b = sum((b - mean_b) ** 2 for b in series_b)
        
        denominator = (var_a * var_b) ** 0.5
        
        if denominator == 0:
            return 0.0
        
        return numerator / denominator
    
    def calculate_returns(self, prices: List[float]) -> List[float]:
        """Calculate daily returns from price series."""
        if len(prices) < 2:
            return []
        return [(prices[i] - prices[i-1]) / prices[i-1] for i in range(1, len(prices))]
    
    def assess_correlation_regime(
        self,
        stock_returns: List[float],
        freight_returns: List[float],
        market_returns: List[float],
    ) -> Dict[str, Any]:
        """
        Assess correlation regime for a stock.
        
        Args:
            stock_returns: Stock daily returns
            freight_returns: Freight index daily returns
            market_returns: S&P 500 daily returns
            
        Returns:
            Correlation regime assessment
        """
        # Calculate correlations
        freight_corr = self.calculate_correlation(stock_returns, freight_returns)
        market_corr = self.calculate_correlation(stock_returns, market_returns)
        
        # Classify regime
        if freight_corr >= self.high_threshold:
            regime = CorrelationRegime.HIGH_FREIGHT
        elif market_corr >= self.high_threshold:
            regime = CorrelationRegime.HIGH_MARKET
        elif freight_corr < self.low_threshold and market_corr < self.low_threshold:
            regime = CorrelationRegime.DECORRELATED
        else:
            # Check for correlation collapse
            if abs(freight_corr) < 0.1:
                regime = CorrelationRegime.COLLAPSED
            else:
                regime = CorrelationRegime.DECORRELATED
        
        # Signal effectiveness factor
        # Fundamental signals work best when stock follows freight
        if regime == CorrelationRegime.HIGH_FREIGHT:
            signal_effectiveness = 1.0
        elif regime == CorrelationRegime.DECORRELATED:
            signal_effectiveness = 0.8
        elif regime == CorrelationRegime.HIGH_MARKET:
            signal_effectiveness = 0.6  # Macro dominates
        else:  # COLLAPSED
            signal_effectiveness = 0.4  # Unclear relationship
        
        return {
            "regime": regime,
            "freight_correlation": round(freight_corr, 3),
            "market_correlation": round(market_corr, 3),
            "correlation_spread": round(freight_corr - market_corr, 3),
            "signal_effectiveness": signal_effectiveness,
        }


class PositionSizer:
    """
    Position sizing calculator.
    
    Considers:
    - Base position size (% of portfolio)
    - Signal strength adjustment
    - Risk regime adjustment
    - Volatility adjustment
    - Existing exposure limits
    """
    
    def __init__(
        self,
        base_position_pct: float = 0.10,  # 10% base
        max_position_pct: float = 0.15,  # 15% max
        max_sector_pct: float = 0.40,  # 40% sector max
        max_total_exposure_pct: float = 1.0,  # 100% invested max
        min_position_pct: float = 0.03,  # 3% minimum
    ):
        self.base_position_pct = base_position_pct
        self.max_position_pct = max_position_pct
        self.max_sector_pct = max_sector_pct
        self.max_total_exposure_pct = max_total_exposure_pct
        self.min_position_pct = min_position_pct
    
    def calculate_position_size(
        self,
        portfolio_value: float,
        signal_strength: float,
        risk_multiplier: float,
        stock_volatility: float = 0.30,
        current_exposure: float = 0,
        sector_exposure: float = 0,
        sector: str = None,
    ) -> Dict[str, Any]:
        """
        Calculate position size.
        
        Args:
            portfolio_value: Total portfolio value
            signal_strength: Signal strength (0-1)
            risk_multiplier: From risk regime (0-1)
            stock_volatility: Annualized volatility
            current_exposure: Current total exposure (%)
            sector_exposure: Current sector exposure (%)
            sector: Stock sector
            
        Returns:
            Position sizing details
        """
        # Base size adjusted by signal strength
        # Strong signal (1.0) = full base, weak signal (0.5) = half base
        adjusted_base = self.base_position_pct * max(0.5, signal_strength)
        
        # Risk regime adjustment
        adjusted_for_risk = adjusted_base * risk_multiplier
        
        # Volatility adjustment
        # Target constant volatility contribution
        target_vol = 0.30  # Baseline volatility assumption
        vol_factor = min(1.5, target_vol / max(stock_volatility, 0.1))
        adjusted_for_vol = adjusted_for_risk * vol_factor
        
        # Apply caps
        position_pct = min(adjusted_for_vol, self.max_position_pct)
        
        # Check sector limit
        remaining_sector = self.max_sector_pct - sector_exposure
        if remaining_sector < position_pct:
            position_pct = max(0, remaining_sector)
        
        # Check total exposure limit
        remaining_total = self.max_total_exposure_pct - current_exposure
        if remaining_total < position_pct:
            position_pct = max(0, remaining_total)
        
        # Apply minimum threshold
        if position_pct < self.min_position_pct:
            position_pct = 0  # Too small, don't bother
        
        position_value = portfolio_value * position_pct
        
        return {
            "position_pct": round(position_pct, 4),
            "position_value": round(position_value, 2),
            "adjustments": {
                "base": self.base_position_pct,
                "signal_adjusted": adjusted_base,
                "risk_adjusted": adjusted_for_risk,
                "vol_adjusted": adjusted_for_vol,
                "final": position_pct,
            },
            "constraints": {
                "max_position": self.max_position_pct,
                "sector_remaining": remaining_sector,
                "total_remaining": remaining_total,
            },
            "viable": position_pct >= self.min_position_pct,
        }


class StopLossManager:
    """
    Stop loss and trailing stop management.
    """
    
    def __init__(
        self,
        default_stop_pct: float = 0.15,  # 15% stop
        trailing_activation_pct: float = 0.15,  # Activate after 15% gain
        trailing_distance_pct: float = 0.10,  # Trail 10% from high
    ):
        self.default_stop_pct = default_stop_pct
        self.trailing_activation_pct = trailing_activation_pct
        self.trailing_distance_pct = trailing_distance_pct
    
    def calculate_initial_stop(
        self,
        entry_price: float,
        volatility: float = None,
    ) -> float:
        """Calculate initial stop loss price."""
        # Could adjust stop based on volatility
        stop_pct = self.default_stop_pct
        if volatility:
            # Wider stop for more volatile stocks
            stop_pct = min(0.25, self.default_stop_pct * (volatility / 0.30))
        
        return entry_price * (1 - stop_pct)
    
    def update_trailing_stop(
        self,
        entry_price: float,
        current_price: float,
        highest_price: float,
        current_stop: float,
    ) -> Dict[str, Any]:
        """
        Update trailing stop.
        
        Args:
            entry_price: Original entry price
            current_price: Current price
            highest_price: Highest price since entry
            current_stop: Current stop price
            
        Returns:
            Updated stop info
        """
        gain_pct = (current_price - entry_price) / entry_price
        
        # Check if trailing stop should be activated
        trailing_active = gain_pct >= self.trailing_activation_pct
        
        if trailing_active:
            # Calculate trailing stop level
            trailing_stop = highest_price * (1 - self.trailing_distance_pct)
            new_stop = max(current_stop, trailing_stop)
        else:
            new_stop = current_stop
        
        # Check if stop is hit
        stop_triggered = current_price <= new_stop
        
        return {
            "stop_price": round(new_stop, 2),
            "trailing_active": trailing_active,
            "stop_triggered": stop_triggered,
            "gain_pct": round(gain_pct, 4),
            "stop_distance_pct": round((current_price - new_stop) / current_price, 4),
        }


class RiskManager:
    """
    Main risk management coordinator.
    
    Combines:
    - Macro filter
    - Correlation tracking
    - Position sizing
    - Stop management
    """
    
    def __init__(
        self,
        macro_filter: Optional[MacroFilter] = None,
        correlation_tracker: Optional[CorrelationTracker] = None,
        position_sizer: Optional[PositionSizer] = None,
        stop_manager: Optional[StopLossManager] = None,
    ):
        self.macro_filter = macro_filter or MacroFilter()
        self.correlation_tracker = correlation_tracker or CorrelationTracker()
        self.position_sizer = position_sizer or PositionSizer()
        self.stop_manager = stop_manager or StopLossManager()
        
        # Manual override
        self._override_active = False
        self._override_reason = None
        self._override_regime = None
    
    def set_manual_override(
        self,
        regime: RiskRegime,
        reason: str,
    ):
        """Set manual risk regime override."""
        self._override_active = True
        self._override_regime = regime
        self._override_reason = reason
        logger.warning(f"Manual override set: {regime.value} - {reason}")
    
    def clear_manual_override(self):
        """Clear manual override."""
        self._override_active = False
        self._override_regime = None
        self._override_reason = None
        logger.info("Manual override cleared")
    
    def assess_risk(
        self,
        macro: MacroSnapshot,
        stock_returns: Optional[List[float]] = None,
        freight_returns: Optional[List[float]] = None,
        market_returns: Optional[List[float]] = None,
    ) -> RiskAssessment:
        """
        Complete risk assessment.
        
        Args:
            macro: Current macro snapshot
            stock_returns: Stock return series (optional)
            freight_returns: Freight index return series (optional)
            market_returns: Market return series (optional)
            
        Returns:
            Complete risk assessment
        """
        # Macro assessment
        macro_result = self.macro_filter.assess(macro)
        
        # Correlation assessment (if data available)
        if stock_returns and freight_returns and market_returns:
            corr_result = self.correlation_tracker.assess_correlation_regime(
                stock_returns, freight_returns, market_returns
            )
            freight_correlation = corr_result["freight_correlation"]
            market_correlation = corr_result["market_correlation"]
            correlation_regime = corr_result["regime"]
        else:
            freight_correlation = 0.5
            market_correlation = 0.3
            correlation_regime = CorrelationRegime.DECORRELATED
        
        # Determine final regime
        if self._override_active:
            risk_regime = self._override_regime
        else:
            risk_regime = macro_result["regime"]
        
        # Position sizing
        if risk_regime == RiskRegime.RISK_OFF:
            pos_multiplier = 0.0
            max_pos = 0.0
        elif risk_regime == RiskRegime.CAUTION:
            pos_multiplier = 0.5
            max_pos = 0.10
        else:
            pos_multiplier = 1.0
            max_pos = 0.15
        
        return RiskAssessment(
            date=macro.date,
            risk_regime=risk_regime,
            correlation_regime=correlation_regime,
            vix_elevated=macro_result["vix_elevated"],
            market_stressed=macro_result["market_stressed"],
            credit_stressed=macro_result["credit_stressed"],
            freight_correlation=freight_correlation,
            market_correlation=market_correlation,
            correlation_spread=freight_correlation - market_correlation,
            position_size_multiplier=pos_multiplier,
            max_position_pct=max_pos,
            manual_override=self._override_active,
            override_reason=self._override_reason,
        )
    
    def size_position(
        self,
        portfolio_value: float,
        signal_strength: float,
        risk_assessment: RiskAssessment,
        stock_volatility: float = 0.30,
        current_exposure: float = 0,
        sector_exposure: float = 0,
    ) -> Dict[str, Any]:
        """
        Size a position given risk assessment.
        """
        return self.position_sizer.calculate_position_size(
            portfolio_value=portfolio_value,
            signal_strength=signal_strength,
            risk_multiplier=risk_assessment.position_size_multiplier,
            stock_volatility=stock_volatility,
            current_exposure=current_exposure,
            sector_exposure=sector_exposure,
        )
