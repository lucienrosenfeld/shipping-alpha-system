"""
Database models for the Shipping Equity Alpha System.
Uses SQLAlchemy ORM.
"""

from datetime import datetime, date
from typing import Optional, List
from decimal import Decimal

from sqlalchemy import (
    create_engine, Column, Integer, String, Float, Date, DateTime,
    Boolean, ForeignKey, Text, Enum, UniqueConstraint, Index
)
from sqlalchemy.orm import declarative_base, relationship, sessionmaker
from sqlalchemy.dialects.postgresql import JSONB
import enum

Base = declarative_base()


# ============================================================================
# Enums
# ============================================================================

class ShippingSegment(enum.Enum):
    DRY_BULK = "dry_bulk"
    TANKER = "tanker"
    CONTAINER = "container"
    LNG = "lng"
    LPG = "lpg"
    MIXED = "mixed"


class VesselType(enum.Enum):
    # Dry Bulk
    CAPESIZE = "capesize"
    PANAMAX = "panamax"
    SUPRAMAX = "supramax"
    HANDYSIZE = "handysize"
    
    # Tanker
    VLCC = "vlcc"
    SUEZMAX = "suezmax"
    AFRAMAX = "aframax"
    MR_TANKER = "mr_tanker"
    LR1 = "lr1"
    LR2 = "lr2"
    
    # Container
    CONTAINER_SMALL = "container_small"
    CONTAINER_MID = "container_mid"
    CONTAINER_LARGE = "container_large"
    
    # Gas
    LNG_CARRIER = "lng_carrier"
    LPG_CARRIER = "lpg_carrier"


class CharterType(enum.Enum):
    SPOT = "spot"
    TIME_CHARTER = "time_charter"
    BAREBOAT = "bareboat"
    COA = "contract_of_affreightment"


class TradeType(enum.Enum):
    EARNINGS_SURPRISE = "earnings_surprise"
    RE_RATING = "re_rating"


class TradeStatus(enum.Enum):
    PENDING = "pending"
    OPEN = "open"
    CLOSED = "closed"
    CANCELLED = "cancelled"


class RiskRegime(enum.Enum):
    NORMAL = "normal"
    CAUTION = "caution"
    RISK_OFF = "risk_off"


# ============================================================================
# Company Models
# ============================================================================

class Company(Base):
    """Shipping company master data."""
    __tablename__ = "companies"
    
    id = Column(Integer, primary_key=True)
    ticker = Column(String(10), unique=True, nullable=False, index=True)
    name = Column(String(200), nullable=False)
    segment = Column(Enum(ShippingSegment), nullable=False)
    
    # Company details
    shares_outstanding = Column(Float)
    market_cap = Column(Float)
    enterprise_value = Column(Float)
    total_debt = Column(Float)
    cash = Column(Float)
    
    # Operating metrics
    annual_opex_per_vessel = Column(Float)  # Daily operating cost
    annual_ga_expense = Column(Float)  # G&A expense
    annual_interest_expense = Column(Float)
    depreciation = Column(Float)
    
    # Valuation defaults
    typical_pe_multiple = Column(Float, default=5.0)
    typical_ev_ebitda = Column(Float, default=4.0)
    
    # Metadata
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    vessels = relationship("Vessel", back_populates="company")
    charters = relationship("Charter", back_populates="company")
    signals = relationship("Signal", back_populates="company")
    trades = relationship("Trade", back_populates="company")
    financials = relationship("Financial", back_populates="company")


class Vessel(Base):
    """Individual vessel in company fleet."""
    __tablename__ = "vessels"
    
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=False)
    
    # Vessel identification
    imo_number = Column(String(20), unique=True)
    name = Column(String(200))
    vessel_type = Column(Enum(VesselType), nullable=False)
    
    # Vessel specifications
    dwt = Column(Float)  # Deadweight tonnage
    teu = Column(Float)  # Container capacity (TEU) if applicable
    built_year = Column(Integer)
    
    # Cost parameters
    daily_opex = Column(Float)  # Daily operating cost for this vessel
    
    # Status
    active = Column(Boolean, default=True)
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    company = relationship("Company", back_populates="vessels")
    charters = relationship("Charter", back_populates="vessel")


class Charter(Base):
    """Charter contract for a vessel."""
    __tablename__ = "charters"
    
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=False)
    vessel_id = Column(Integer, ForeignKey("vessels.id"))
    
    # Charter details
    charter_type = Column(Enum(CharterType), nullable=False)
    daily_rate = Column(Float, nullable=False)  # $/day
    
    # Duration
    start_date = Column(Date, nullable=False)
    end_date = Column(Date)  # Null for spot
    
    # Options
    has_extension_option = Column(Boolean, default=False)
    extension_rate = Column(Float)
    
    # Notes
    notes = Column(Text)
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    company = relationship("Company", back_populates="charters")
    vessel = relationship("Vessel", back_populates="charters")
    
    __table_args__ = (
        Index("ix_charters_dates", "start_date", "end_date"),
    )


class Financial(Base):
    """Quarterly/annual financial data."""
    __tablename__ = "financials"
    
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=False)
    
    # Period
    fiscal_year = Column(Integer, nullable=False)
    fiscal_quarter = Column(Integer)  # Null for annual
    period_end_date = Column(Date, nullable=False)
    
    # Income Statement
    revenue = Column(Float)
    voyage_expenses = Column(Float)
    vessel_operating_expenses = Column(Float)
    charter_hire_expenses = Column(Float)
    depreciation = Column(Float)
    general_admin = Column(Float)
    ebitda = Column(Float)
    operating_income = Column(Float)
    interest_expense = Column(Float)
    net_income = Column(Float)
    eps = Column(Float)
    
    # Balance Sheet
    total_assets = Column(Float)
    total_debt = Column(Float)
    cash_and_equivalents = Column(Float)
    shareholders_equity = Column(Float)
    
    # Cash Flow
    operating_cash_flow = Column(Float)
    capex = Column(Float)
    free_cash_flow = Column(Float)
    dividends_paid = Column(Float)
    
    # Shipping metrics
    tce_rate = Column(Float)  # Time Charter Equivalent rate achieved
    utilization = Column(Float)  # Fleet utilization %
    fleet_days = Column(Float)  # Available days
    
    # Metadata
    source = Column(String(50))  # e.g., "10-Q", "20-F"
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    company = relationship("Company", back_populates="financials")
    
    __table_args__ = (
        UniqueConstraint("company_id", "fiscal_year", "fiscal_quarter", name="uq_financial_period"),
        Index("ix_financials_period", "fiscal_year", "fiscal_quarter"),
    )


# ============================================================================
# Market Data Models
# ============================================================================

class FreightIndex(Base):
    """Daily freight index values."""
    __tablename__ = "freight_indices"
    
    id = Column(Integer, primary_key=True)
    date = Column(Date, nullable=False, index=True)
    
    # Index identifier
    index_code = Column(String(20), nullable=False)  # e.g., "BDI", "BDTI"
    
    # Values
    value = Column(Float, nullable=False)
    change = Column(Float)
    change_pct = Column(Float)
    
    # TCE conversion (if applicable)
    tce_equivalent = Column(Float)  # $/day equivalent
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    
    __table_args__ = (
        UniqueConstraint("date", "index_code", name="uq_freight_index_day"),
        Index("ix_freight_date_code", "date", "index_code"),
    )


class FFAPrice(Base):
    """Forward Freight Agreement prices."""
    __tablename__ = "ffa_prices"
    
    id = Column(Integer, primary_key=True)
    date = Column(Date, nullable=False, index=True)
    
    # Contract identification
    route_code = Column(String(20), nullable=False)  # e.g., "C5TC", "TD3C"
    contract_month = Column(Date, nullable=False)  # Settlement month
    
    # Prices
    bid = Column(Float)
    ask = Column(Float)
    settlement = Column(Float)  # Official settlement
    
    # TCE equivalent
    tce_equivalent = Column(Float)
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    
    __table_args__ = (
        UniqueConstraint("date", "route_code", "contract_month", name="uq_ffa_contract"),
        Index("ix_ffa_date_route", "date", "route_code"),
    )


class BunkerPrice(Base):
    """Bunker fuel prices."""
    __tablename__ = "bunker_prices"
    
    id = Column(Integer, primary_key=True)
    date = Column(Date, nullable=False, index=True)
    
    # Location
    port = Column(String(50), nullable=False)  # e.g., "Singapore", "Rotterdam"
    
    # Fuel types
    fuel_type = Column(String(20), nullable=False)  # "VLSFO", "MGO", "HSFO"
    
    # Price ($/mt)
    price = Column(Float, nullable=False)
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    
    __table_args__ = (
        UniqueConstraint("date", "port", "fuel_type", name="uq_bunker_price"),
    )


class EquityPrice(Base):
    """Daily equity prices."""
    __tablename__ = "equity_prices"
    
    id = Column(Integer, primary_key=True)
    date = Column(Date, nullable=False, index=True)
    ticker = Column(String(10), nullable=False, index=True)
    
    # OHLCV
    open = Column(Float)
    high = Column(Float)
    low = Column(Float)
    close = Column(Float, nullable=False)
    adjusted_close = Column(Float)
    volume = Column(Float)
    
    # Derived
    daily_return = Column(Float)
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    
    __table_args__ = (
        UniqueConstraint("date", "ticker", name="uq_equity_price"),
        Index("ix_equity_date_ticker", "date", "ticker"),
    )


class MacroIndicator(Base):
    """Macro economic indicators."""
    __tablename__ = "macro_indicators"
    
    id = Column(Integer, primary_key=True)
    date = Column(Date, nullable=False, index=True)
    
    # Indicator
    indicator_code = Column(String(30), nullable=False)  # e.g., "VIX", "SPX", "PMI"
    value = Column(Float, nullable=False)
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    
    __table_args__ = (
        UniqueConstraint("date", "indicator_code", name="uq_macro_indicator"),
    )


# ============================================================================
# Signal Models
# ============================================================================

class Signal(Base):
    """Calculated trading signals."""
    __tablename__ = "signals"
    
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=False)
    date = Column(Date, nullable=False, index=True)
    
    # Core signals
    lep = Column(Float)  # Live Earnings Power (EPS)
    lep_ebitda = Column(Float)  # LEP as EBITDA
    
    fep = Column(Float)  # Forward Earnings Power (EPS)
    fep_ebitda = Column(Float)  # FEP as EBITDA
    
    eiep = Column(Float)  # Equity-Implied Earnings Power
    
    inf_score = Column(Float)  # Inflection Score (0-100)
    dis_score = Column(Float)  # Disbelief Score (ratio)
    
    # Signal components
    inf_components = Column(Text)  # JSON breakdown of INF components
    
    # RED metrics
    red_months = Column(Float)  # Realized Earnings Delay in months
    fleet_spot_pct = Column(Float)  # % of fleet on spot
    
    # Correlations
    freight_correlation = Column(Float)  # Rolling correlation to freight
    market_correlation = Column(Float)  # Rolling correlation to S&P
    
    # Trade signals
    buy_signal = Column(Boolean, default=False)
    sell_signal = Column(Boolean, default=False)
    signal_strength = Column(Float)  # 0-1 confidence
    trade_type = Column(Enum(TradeType))
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    company = relationship("Company", back_populates="signals")
    
    __table_args__ = (
        UniqueConstraint("company_id", "date", name="uq_signal_company_date"),
        Index("ix_signals_date", "date"),
    )


class RiskRegimeHistory(Base):
    """Risk regime history tracking."""
    __tablename__ = "risk_regime_history"
    
    id = Column(Integer, primary_key=True)
    date = Column(Date, nullable=False, index=True)
    
    # Regime
    regime = Column(Enum(RiskRegime), nullable=False)
    
    # Components
    vix_level = Column(Float)
    credit_spread = Column(Float)
    market_drawdown = Column(Float)
    freight_equity_correlation = Column(Float)
    
    # Flags
    macro_override_active = Column(Boolean, default=False)
    override_reason = Column(Text)
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)


# ============================================================================
# Trading Models
# ============================================================================

class Trade(Base):
    """Trade records."""
    __tablename__ = "trades"
    
    id = Column(Integer, primary_key=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=False)
    
    # Trade identification
    trade_type = Column(Enum(TradeType), nullable=False)
    status = Column(Enum(TradeStatus), default=TradeStatus.PENDING)
    
    # Entry
    entry_date = Column(Date)
    entry_price = Column(Float)
    shares = Column(Float)
    position_value = Column(Float)
    position_pct = Column(Float)  # % of portfolio
    
    # Exit
    exit_date = Column(Date)
    exit_price = Column(Float)
    exit_reason = Column(String(100))
    
    # Risk management
    stop_loss = Column(Float)
    target_price = Column(Float)
    trailing_stop = Column(Float)
    
    # Performance
    realized_pnl = Column(Float)
    realized_pnl_pct = Column(Float)
    holding_days = Column(Integer)
    
    # Signal at entry
    entry_lep = Column(Float)
    entry_fep = Column(Float)
    entry_eiep = Column(Float)
    entry_inf = Column(Float)
    entry_dis = Column(Float)
    
    # Thesis
    thesis = Column(Text)
    notes = Column(Text)
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    company = relationship("Company", back_populates="trades")


class Portfolio(Base):
    """Portfolio snapshot."""
    __tablename__ = "portfolio"
    
    id = Column(Integer, primary_key=True)
    date = Column(Date, nullable=False, index=True)
    
    # Portfolio metrics
    total_value = Column(Float)
    cash = Column(Float)
    invested = Column(Float)
    
    # Positions (JSON array of position details)
    positions = Column(Text)
    
    # Performance
    daily_return = Column(Float)
    mtd_return = Column(Float)
    ytd_return = Column(Float)
    total_return = Column(Float)
    
    # Risk metrics
    portfolio_volatility = Column(Float)
    sharpe_ratio = Column(Float)
    max_drawdown = Column(Float)
    
    # Exposures
    dry_bulk_exposure = Column(Float)
    tanker_exposure = Column(Float)
    container_exposure = Column(Float)
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)


class Alert(Base):
    """System alerts and notifications."""
    __tablename__ = "alerts"
    
    id = Column(Integer, primary_key=True)
    
    # Alert details
    alert_type = Column(String(50), nullable=False)  # "signal", "risk", "trade", etc.
    severity = Column(String(20), default="info")  # "info", "warning", "critical"
    
    # Content
    title = Column(String(200), nullable=False)
    message = Column(Text)
    
    # Related entities
    company_id = Column(Integer, ForeignKey("companies.id"))
    trade_id = Column(Integer, ForeignKey("trades.id"))
    
    # Status
    acknowledged = Column(Boolean, default=False)
    acknowledged_at = Column(DateTime)
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)


# ============================================================================
# Backtesting Models
# ============================================================================

class BacktestRun(Base):
    """Backtest run configuration and results."""
    __tablename__ = "backtest_runs"
    
    id = Column(Integer, primary_key=True)
    
    # Configuration
    name = Column(String(100))
    start_date = Column(Date, nullable=False)
    end_date = Column(Date, nullable=False)
    initial_capital = Column(Float, default=1000000)
    
    # Parameters (JSON)
    parameters = Column(Text)
    
    # Results
    final_value = Column(Float)
    total_return = Column(Float)
    cagr = Column(Float)
    sharpe_ratio = Column(Float)
    sortino_ratio = Column(Float)
    max_drawdown = Column(Float)
    win_rate = Column(Float)
    profit_factor = Column(Float)
    total_trades = Column(Integer)
    
    # Trade breakdown
    trades_summary = Column(Text)  # JSON
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    completed_at = Column(DateTime)


# ============================================================================
# Database Session Management
# ============================================================================

def get_engine(database_url: str):
    """Create database engine."""
    return create_engine(database_url, echo=False)


def get_session_factory(engine):
    """Create session factory."""
    return sessionmaker(bind=engine)


def init_db(database_url: str):
    """Initialize database and create all tables."""
    engine = get_engine(database_url)
    Base.metadata.create_all(engine)
    return engine
